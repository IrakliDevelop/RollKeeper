repo: IrakliDevelop/RollKeeper
branch: master

## Last sync

date: 2026-08-24T15:53:09Z

### Updated in this project

- Recreated the DM dashboard shell (`/dm`) from source, including the migration launcher and the hardened controls for cloud-owned campaigns.
- Designed the guided cloud migration wizard for Slice 11G (`/dm/migrate/[code]`): account discovery, one safety copy, six family steps, live result.
- Copied the app's Geist and Geist Mono font files for typographic parity.

## Screen map

| Project screen | Repo files it was built from |
|---|---|
| DM Dashboard.dc.html | src/app/dm/page.tsx, src/components/ui/campaign/DmCloudWorkspaceControls.tsx, src/components/ui/campaign/BannerUpload.tsx, src/components/ui/forms/button.tsx, src/components/ui/layout/badge.tsx, src/components/ui/layout/card.tsx, src/components/ui/primitives/variants.ts, src/app/globals.css, src/app/layout.tsx |
| Cloud Migration Wizard.dc.html | uploads/2026-08-24-slice-11g-migration-wizard.md (plan), src/components/ui/feedback/dialog.tsx, src/components/ui/primitives/variants.ts, src/components/ui/character/CharacterCloudBackupControls.tsx, src/components/ui/character/CharacterAutomaticSyncControls.tsx, src/components/ui/feedback/CharacterStorageMigrationControls.tsx, src/components/ui/feedback/DataSafetyBanner.tsx, src/app/globals.css |
