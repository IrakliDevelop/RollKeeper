# Player Backup Wizard implementation plan

Date: 2026-08-26  
Status: implementation-ready product and engineering plan  
Scope: player character safety, online backup, recovery, and backup management  
Base: merged `master` at `0db4717b57fff293b6ac6f3feda32964c0dbce7c`

## Evidence and planning constraints

- PR [#250](https://github.com/IrakliDevelop/RollKeeper/pull/250), manual character backup and restore, merged as `25340631`.
- PR [#252](https://github.com/IrakliDevelop/RollKeeper/pull/252), character IndexedDB cutover, merged as `ba8b00a4`.
- PR [#255](https://github.com/IrakliDevelop/RollKeeper/pull/255), automatic character sync, merged as `168bec08`.
- PR [#270](https://github.com/IrakliDevelop/RollKeeper/pull/270), DM migration wizard, merged as `0db4717b` on 2026-08-26.
- The local canonical roadmap, `SUPABASE_CLOUD_SYNC_PLAN.md`, explicitly identifies a separately flagged player variant over the Slice 8 character family and Slice 9 automatic behavior. Its execution snapshot is historical, so current code and merged PR state take precedence.
- The current GitHub token cannot read GitHub Projects because it lacks `read:project`. No external Projects commitment is assumed or recorded here.
- This plan does not include code, database changes, a branch, or a PR.

The product decision is to present one goal, **Back up my characters online**, while preserving the current independent safety contracts underneath it. Storage engines, version counters, and queue mechanics remain implementation details.

## 1. Current-state audit

### Existing player surfaces and contracts

| Surface | Current action and actual behavior | Underlying contract | Product problem |
| --- | --- | --- | --- |
| `/player` header `Export All` | Downloads a character-roster JSON through `exportAllCharactersToFile`. It is not the full RollKeeper recovery bundle and has no receipt or reselect verification. | `src/utils/fileOperations.ts`, `playerStore` character roster | It looks like the primary backup action but has different recovery guarantees from the required safety file. |
| `DataSafetyBanner` | One-time dismissible warning. Calls the same character-only export. Dismissal is stored under `rollkeeper-data-warning-dismissed`. | `DataSafetyBanner.tsx`, `exportAllCharactersToFile` | It can claim characters exist only in this browser even when they are protected online. It duplicates the header export and can be permanently dismissed. |
| `DeviceRecoveryControls` | Captures recognized RollKeeper `localStorage` entries, exact raw values, UTF-8 byte counts, per-entry SHA-256 values, and an aggregate hash. Download initiation records a receipt. Import validates hashes, stages an inactive recovery generation, previews collisions/future data, and restores only missing selected values. Existing different values are preserved. | `deviceRecovery.ts`, `browserRecoveryRepository.ts` | The capability is valuable but the UI exposes implementation concepts, internal keys, counts, bytes, versions, and activation mechanics. Download initiation alone is not proof the file was retained. |
| `CharacterStorageMigrationControls` | When `NEXT_PUBLIC_CHARACTER_INDEXEDDB_CUTOVER_ENABLED` is exactly `true`, previews the full browser bundle, initiates a download, records a guest character-family selection, reloads, waits for preparation, and separately activates the prepared character generation. Rollback is parity, reopen, and empty-journal gated. | `characterCutoverSelection.ts`, `characterPersistenceBootstrap.ts`, `characterCutoverControl.ts`, `characterAuthority.ts`, Slice 7 migration modules | This is a technical setup panel for an internal prerequisite. Its current gate accepts an initiated receipt via `hasDownloadReceipt`; it does not require the wizard-style reselect and verified receipt demanded by this plan. |
| `CharacterRecoveryExportControls` | Exports either the current character-family state, including active data, mirrors, journal and recovery artifacts, or an immutable capture. It stays usable in recovery-required state. | `characterRecoveryExport.ts`, `migrationRecovery.ts` | Necessary recovery capability, but its current labels expose implementation details. It belongs in recovery management, not setup. |
| `CharacterCloudBackupControls` | Hidden unless auth and `NEXT_PUBLIC_SUPABASE_CHARACTER_BACKUP_ENABLED` are enabled. Each character is uploaded only after an explicit account confirmation. Success requires RPC success, refetch, decode, and fingerprint equality. Cloud rows load only on request. It supports verify, soft archive, restore, restore as copy, and recovery download. | `useCharacterCloudBackup.ts`, `characterCloud.ts`, `ManualCharacterCloudService`, gateway, codec, links, recovery download | It is per-character, repetitive, and technical. Raw service errors can reach the UI. It does not provide the automatic-conflict resolver for a differing pre-existing online copy. |
| `CharacterAutomaticSyncControls` | Hidden unless `NEXT_PUBLIC_SUPABASE_CHARACTER_AUTOMATIC_SYNC_ENABLED` is exactly `true`. Existing characters default off. Per-character enable requires active character cutover and target-account confirmation. Account preview is read-only; confirmation enables eligible current characters and a future-character default, while explicit off overrides win. | `useCharacterAutomaticSync.ts`, `AutomaticCharacterSyncService`, preferences, repository, worker, puller, coordinator | It duplicates manual backup and storage setup, exposes internal distinctions, and maps a paused aggregate to `local-only`, so the current UI cannot distinguish never protected from paused after an acknowledged online copy. |
| `PersistenceBootstrap` recovery screen | If an activated character generation cannot be verified, the app refuses fallback and exposes current/capture downloads. | `PersistenceBootstrap.tsx`, character bootstrap and recovery export modules | The fail-closed behavior is correct, but the rendered copy exposes forbidden implementation terms. The wizard flag needs a friendly recovery shell over the same exports. |
| Global account UI | `/account` performs email-code sign-in and sign-out without touching local data. `/player` has a global account indicator, but backup controls discover the account only when used. | `AuthForm`, `AccountControls`, `authService`, server claims | The wizard needs a deliberate return path after sign-in and must reset all account-scoped status immediately on account change. |

### Verified safety invariants

The following are established by current code and tests and must remain true:

- Feature flags use exact string equality and are inert when absent or false. Manual cloud construction makes zero Supabase character calls while disabled. Automatic browser setup makes zero auth, IndexedDB, or cloud calls for a non-participating character profile.
- Sign-in and sign-out touch only the account session. They do not claim guest data, select character cutover, or upload a character.
- Character-family activation is scoped to namespace plus family and atomically commits the active pointer and epoch only after readiness gates pass. Failure before that commit leaves the legacy path primary.
- After activation, an edit is acknowledged only after an IndexedDB commit or durable journal outcome. A failed compatibility mirror is retried and does not invalidate an already durable edit. An active transaction failure is not reported as saved.
- Immutable source captures, numbered captures, current mirrors, journals, conflicts, recovery bundles, and tombstones are retained. Rollback refuses unless parity, reopen, and journal checks succeed.
- Manual upload is explicit and account-targeted. It reuses a mutation ID after response loss and does not claim success until the exact refetched online payload matches.
- The character table is isolated by authenticated owner. Browser cloud links are keyed by account plus legacy character ID. Automatic documents, preferences, pending work, conflicts, and held-aside data use `user:<account-id>` namespaces.
- Automatic work is opt-in. Turning it off writes an explicit off preference and pauses retained work; it does not delete the local character, online row, link, pending work, conflict, or recovery data.
- Automatic upload and pull preserve both sides of a version conflict. `keep-mine`, `use-cloud`, and `keep-both` snapshot or retain the losing candidate before resolution. `keep-both` creates a new local character that starts with online backup off.
- Offline, expired-auth, response-loss, retry, and worker-restart states are durable. One conflicted character does not stop unrelated characters.
- Future-format or malformed online candidates are held aside and exportable. They are never activated as current character data.
- Online deletion is a recoverable soft archive/tombstone path. Ordinary updates cannot resurrect it.

One wording clarification is necessary for acceptance tests: merely viewing, signing in, signing out, or navigating must never enroll a character, select cutover, enqueue a first upload, or change local ownership. After the player has explicitly enabled ongoing backup, the already-authorized durable worker may resume previously queued work on startup, focus, or reconnect. Treating that authorized retry as a new implicit opt-in would make ongoing backup impossible and would contradict the merged Slice 9 contract.

### Duplication and contradiction to remove under the wizard flag

- `Export All`, the safety banner, and the full recovery download appear to be three versions of the same action but produce two different file types and three different guarantees.
- Manual backup and automatic backup each list every character and use different status vocabularies.
- The storage transition appears as a separate decision even though it is only a prerequisite for durable ongoing backup.
- `Cloud: local only` conflates never selected, explicitly paused, and an acknowledged one-time online copy.
- Current recovery and error strings expose implementation terms and sometimes raw exceptions.
- The full browser recovery import can restore `localStorage` entries, but after character cutover the active character data must instead be imported through `importCharacterRecoveryGeneration`; restoring only a compatibility mirror would not restore the active character state.

## 2. Recommended product model

### Single goal and entry points

Place one compact backup card directly below the `/player` dashboard heading and above character statistics.

- Before setup: primary button **Back up my characters online**.
- While setup is safely resumable: primary button **Continue character backup**.
- After at least one character has an acknowledged online copy: a compact summary headed **Online backup is on** or **Online copies saved**, with counts for protected, backing up, paused, and needs attention.
- Completed-state actions: **Manage backups** and **Restore characters**.

All entry buttons go to the dedicated, flag-checked `/player/backup` route. A dedicated route is preferable to an always-mounted dashboard dialog because it survives reloads, gives sign-in a deterministic return target, and can remount after the local character transition before any editor/dashboard owner resumes.

The route chooses its initial view from durable facts, not a stored `wizardCompleted` boolean:

- no acknowledged current-account online copy and no confirmed setup intent: setup;
- confirmed setup intent with unfinished cutover or selected characters lacking a terminal result: resume;
- at least one acknowledged copy or a retained paused/attention state: management summary, with an explicit **Protect more characters** action to re-enter selection.

### Minimum visible flow

Use three actionable screens plus the result. Steps 3 and 4 from the hypothesis are combined because the choices and their consequence fit in one reviewable confirmation without weakening consent.

1. **Protect your characters**
   - Explain the single outcome.
   - Check account status without writing anything.
   - If signed out, link to `/account?returnTo=/player/backup`; validate the return path against an internal allowlist.
2. **Save a safety file**
   - Capture the existing full RollKeeper browser bundle.
   - Initiate the download.
   - Require the player to choose the downloaded file again.
   - Validate its shape, every entry hash, aggregate hash, run ID, and exact identity before marking this step complete.
3. **Choose characters**
   - Select all eligible active and archived characters by default.
   - Show a single account-level switch, on by default: **Keep these backups up to date**.
   - Show one explicit confirmation panel naming the account, selected count, what will be copied, what will remain local, and that nothing is deleted.
   - The confirmation button is the only operation that records setup intent, prepares the safer browser storage path, or starts an online write.
4. **Finished**
   - Verify and summarize each selected character independently.
   - Never turn partial success into a whole-run success claim.
   - Give the next safe action for conflicts, offline work, held-aside data, or retryable failure.

The account screen and safety-file screen may share the first route render, as the DM wizard does, but the progress rail and accessible step headings must continue to present them as separate obligations. On narrow screens, use a compact `Step n of 3` label instead of a side rail.

### Safety file recommendation

Use the existing broad browser safety bundle, not a new character-only file.

In user terms, the file includes the characters and any other RollKeeper data currently saved in this browser. Only the selected characters are sent to the account. The file must be described as private because it can also contain local campaign material.

In recovery terms, the current bundle preserves exact raw bytes for recognized RollKeeper browser keys, including the character roster and character envelopes, DM families, canvases, and retained RollKeeper keys. Before character cutover, that is the independent copy needed to restore the complete character source and to prove it did not change. A character-only file would require a parallel receipt and gate, would not protect unrelated local data touched by the same setup session, and would weaken reuse of the existing cutover contract.

Do not overclaim that this file contains every internal IndexedDB journal or recovery record. After cutover, current character exports and immutable-capture exports remain the recovery tools for those records. The setup copy deck should say what the player receives, not “all browser storage.”

### Character selection and ongoing behavior

- Default: all eligible active and archived characters selected.
- Provide **Select all** and **Clear all** plus individual checkboxes.
- Require at least one selected character before confirmation.
- Explain an unavailable character beside its name and leave it unselected. Do not expose payload-size, encoding, or format-version details in the normal flow.
- The account-level **Keep these backups up to date** switch defaults on. When on, selected current characters are enabled and new eligible characters default on; any cleared current character receives an explicit off override. This uses the existing account-default policy instead of making the player repeat setup for each character.
- When off, the selected characters receive one verified online copy through the manual backup contract and later edits remain only in this browser until the player chooses **Back up now** or turns ongoing backup on.

The internal character storage transition is not a visible step. In the full rollout, after the verified safety file and the final confirmation, the coordinator selects, prepares, validates, and activates the character family using existing Slice 7 and 8 services. It runs once for the character family, not once per character. The final confirmation is meaningful consent for this preparation because it explicitly says character saving in this browser will be prepared, local characters remain available, and nothing is deleted. In a partial rollout where the cutover capability is off, an uncontested one-time manual copy may still use the existing manual contract without changing local ownership; ongoing backup and durable three-way conflict resolution remain unavailable and must fail closed with friendly status.

### Existing online copies

Before confirmation, list only the signed-in account’s rows and compare by legacy character ID with validated payloads:

- Identical active row: label **Already protected**. Do not upload it again. Attach or refresh the account-scoped link only after validation.
- Active row with a greater validated character revision: label **Online copy has newer changes**.
- Active row with different content but no trustworthy revision ordering: label **Different online copy**.
- Soft-archived row: label **Online copy was removed** and require an explicit restore or keep-both choice. Never silently resurrect it.
- Missing/unavailable response: leave the character local and show **Could not check online backup** with retry.
- Future-format or unsafe row: keep it held aside, offer a recovery download, and do not activate or overwrite it.

For a differing row, do not let the manual service’s generic conflict error become the product behavior. Create the local document and conflict using the existing automatic repository/conflict service after the safe local transition, then present the existing three semantics in friendly language. This reuses the durable snapshots and prevents a one-time backup choice from becoming last-write-wins. For one-time mode, turn ongoing backup back off only after the selected resolution reaches a verified terminal result.

Rows belonging to another account are not discoverable through RLS and must not be inferred from a prior account’s UI cache. An account-scoped local link for a different account is ignored. The character appears **Not backed up to this account**. Switching back to the original account may reveal its status again after a fresh account-scoped read.

### Completed management surface

The setup wizard collapses into management after completion. Keep these actions:

- **Check now**: refresh current-account online rows and durable local status. It is read-only unless already-authorized work is waiting.
- **Back up now**: explicit one-time copy for a paused or one-time character.
- **Pause updates** and **Keep up to date**: per character. Pausing never removes either copy.
- **Protect new characters automatically**: account-level future default, with a corresponding off operation added to the existing preference service.
- **Restore here**, **Restore as another character**, and **Download recovery copy** for current-account online rows.
- **Remove online copy**: soft archive only, behind a confirmation that local data remains and the online copy can still be recovered. It is separate from pausing.
- **Save a new safety file** and **Restore from a safety file**.
- Recovery-only disclosure: **Download current character data**, **Download original recovery copy**, and **Use the earlier browser saving method**. Keep these reachable but outside routine setup.

Do not expose a hard-delete action. Do not automatically archive an online row when the player pauses updates.

## 3. State and transition model

Completion and status are derived from the account session, verified safety receipt, character-family selection and authority, account-scoped preferences/documents/work, current cloud rows, conflicts, and held-aside records. A wizard step index is ephemeral. Confirmed choices use the existing account-scoped preference records; do not introduce a second authoritative wizard store.

| State | Durable/read source | What the player sees | Allowed transition and write boundary |
| --- | --- | --- | --- |
| Signed out | Server claims plus browser auth client | Sign-in call to action; local play and safety-file restore remain available | Sign-in changes session only. Return to `/player/backup`; re-run account discovery. |
| No characters | Hydrated `playerStore` roster | Empty state with create and restore actions | No upload or local transition. |
| Eligible local characters | Roster plus cloud codec preflight | Names, active/archived label, selection checkboxes | Selection is ephemeral until final confirmation. |
| Safety file required | No matching verified receipt for current capture hash | Save and choose-back controls | Download records initiation only. Reselect validation records verified receipt. No cutover or upload. |
| Safety file ready | `readVerifiedDownloadReceipt` with matching entry vector and a fresh identical capture | Checked status | Continue to selection. Any captured-key drift invalidates readiness and requires a fresh file. |
| Ready | Signed-in account, verified unchanged file, at least one selected eligible character | Final consequence/account confirmation | Confirmation records account-scoped choices. Recheck account ID and source hash immediately before every local-ownership or cloud write. |
| Preparing this browser | Character selection exists, local authority not active | Neutral progress; characters remain usable if the pre-commit path fails | Run existing capture, prepare, reopen, parity, journal, and activation gates. No online write yet. |
| Backing up | Manual operation in flight or automatic queued/inflight work | Per-character progress | Success only after refetch, decode, identity/version checks, and fingerprint equality. |
| Protected, ongoing | Preference on, validated document, no blocking work, server version greater than zero | Online backup on | Future acknowledged local edits enqueue durable work. |
| Protected, one-time | Preference off, validated acknowledged document/link, no pending initial work | Online copy saved; later changes stay here | Back up now or enable ongoing backup. |
| Paused | Explicit off preference plus retained acknowledged document and possibly paused work | Backup paused | Resume preserves work identity; remove online copy is separate. |
| Offline | Durable work marked offline, or account read failed due network | Waiting for internet; local character stays usable | Reconnect or explicit retry. Do not claim online completion. |
| Sign-in required | Durable work marked auth-required or session absent | Sign in again | Reauthenticate same account, resume its work, never switch namespaces implicitly. |
| Conflict | Unresolved account-scoped conflict with both candidates retained | Needs attention plus three choices | Each explicit resolution snapshots/retains the losing candidate before apply or upload. |
| Recovery required | Character bootstrap or recovery import cannot prove safe activation | Friendly fail-closed recovery screen | Export current/capture data, inspect candidates, retry repair, or parity-gated rollback. Never fall back silently. |
| Unsupported future data | Held-aside record plus raw recovery content | This copy needs a newer RollKeeper version | Download recovery copy. Never parse into active character or overwrite it. |
| Account changed | Auth subscription reports a different account ID | Checking this account; no prior-account names or rows | Close the old context, clear ephemeral rows/statuses, stop old worker, and rebuild under the new namespace. Stale async results are discarded by account token. |
| Partial success | Mixed per-character terminal states | Exact protected and attention counts | Retry only failed characters. Do not roll back successes or start unselected characters. |
| Retry | Retained mutation identity/pending manual link | Try again | Reuse the same mutation ID for response-loss retry; revalidate the acknowledgement. |
| Closed or reloaded before confirmation | Verified receipt may exist; no setup choices written | Resume at the safety or selection step | No automatic continuation and no upload. |
| Closed or reloaded after confirmation | Existing preferences, selection, authority, documents, pending work, and cloud links | Continue setup with already-finished work skipped | Require an explicit **Continue setup** click before an unfinished local transition. Already-authorized pending online work may resume under Slice 9 rules. |

The status projector must explicitly distinguish these cases. Do not reuse the current `paused -> local-only` display mapping.

## 4. User-facing copy deck

Everything between the following markers is proposed rendered copy. It contains no forbidden storage vocabulary, no em dash, and no raw service text.

<!-- PLAYER_BACKUP_COPY_START -->

### Dashboard

| State | Copy |
| --- | --- |
| Not started | Title: **Protect your characters**. Description: **Save a safety file, choose your characters, and protect them with your account.** Button: **Back up my characters online**. |
| Resumable | Title: **Character backup is not finished**. Description: **Your completed steps are still safe. Continue when you are ready.** Button: **Continue character backup**. |
| Ongoing complete | Title: **Online backup is on**. Description: **{protected} characters are protected. {attention} need attention.** Buttons: **Manage backups**, **Restore characters**. |
| One-time complete | Title: **Online copies saved**. Description: **{protected} characters were saved online. Later changes stay in this browser until you back up again.** Buttons: **Manage backups**, **Restore characters**. |
| No characters | Title: **No characters to back up**. Description: **Create a character or restore one from a backup first.** Buttons: **Create a character**, **Restore characters**. |
| Service unavailable | Title: **Online backup is unavailable right now**. Description: **Your characters are still safe in this browser. You can save or restore a safety file.** Buttons: **Save a safety file**, **Restore characters**. |

### Step 1: account

- Eyebrow: **Step 1 of 3: Account**
- Title: **Protect your characters**
- Description: **Sign in to keep private online copies of the characters you choose. Signing in alone does not copy or change anything.**
- Signed out status: **Not signed in**
- Signed out button: **Sign in to continue**
- Signed in status: **Using {email}**
- Recheck button: **Check my account**
- Account error: **RollKeeper could not check your account. Nothing in this browser was changed. Try again.**

### Step 2: safety file

- Eyebrow: **Step 2 of 3: Safety file**
- Title: **Save a safety file**
- Description: **This file includes your characters and any campaign data saved in this browser. Keep it private and somewhere you can find later.**
- First instruction: **1. Save the file**
- Download button: **Save safety file**
- Second instruction: **2. Choose the file you just saved**
- File input accessible name: **Choose safety file**
- Preparing: **Preparing your safety file...**
- Download started: **Now choose the file you just saved so RollKeeper can check it.**
- Verified title: **Safety file checked**
- Verified description: **The file matches the current data in this browser. You can continue safely.**
- Existing verified receipt: **Your checked safety file still matches this browser, so you do not need to save another one.**
- Mismatch title: **That file does not match**
- Mismatch description: **The data in this browser changed, or the file came from somewhere else. Save a new safety file and choose that one instead.**
- Read failure: **This browser could not read that file. Save a new safety file and try again.**

### Step 3: selection and consent

- Eyebrow: **Step 3 of 3: Characters**
- Title: **Choose characters**
- Description: **All available characters are selected. Clear any character you do not want to protect with this account.**
- Buttons: **Select all**, **Clear all**
- Archived label: **Archived**
- Already protected: **Already protected**
- Not protected: **Not backed up**
- One-time protected: **Saved online once**
- Paused: **Backup paused**
- Different: **Different online copy**
- Newer: **Online copy has newer changes**
- Removed: **Online copy was removed**
- Unavailable: **Cannot be backed up yet**
- Unavailable description: **RollKeeper cannot safely read this character right now. Nothing will be changed.**
- Switch label: **Keep these backups up to date**
- Switch description: **Recommended. After a change is saved in this browser, RollKeeper will update the online backup for you.**
- Switch-off title: **Save one online copy now**
- Switch-off description: **Later changes will stay only in this browser until you choose Back up now.**
- Ongoing confirmation: **RollKeeper will prepare character saving in this browser, copy {count} selected characters to {email}, and keep their online backups up to date. New characters will also be protected unless you turn backup off for them. Your characters stay available here. Nothing is deleted.**
- One-time confirmation: **RollKeeper will prepare character saving in this browser and save one online copy of {count} selected characters to {email}. Later changes stay here until you back up again. Nothing is deleted.**
- Ongoing button: **Turn on online backup**
- One-time button: **Save online copies**
- No selection: **Choose at least one character to continue.**
- Account changed: **The signed-in account changed. Check the account and confirm again before anything is copied.**
- Data changed: **Your character data changed after the safety file was checked. Save a new safety file before continuing.**

### Progress and result

- Preparing: **Preparing safe character saving in this browser**
- Uploading: **Backing up {name}**
- Verified: **{name} is protected**
- Queued: **{name} will be backed up when the connection is ready**
- Partial title: **Some characters need attention**
- Partial description: **{protected} are protected. {attention} still need attention. Nothing was deleted.**
- Complete title: **Your characters are protected**
- Ongoing complete: **Online backup is on for {count} characters.**
- One-time complete: **Online copies were checked for {count} characters.**
- Buttons: **Manage backups**, **Try again**, **Done**
- Generic local failure: **RollKeeper could not finish preparing this browser. Your existing characters were not replaced. Try again, or open recovery options.**
- Generic online failure: **Online backup could not finish just now. Your characters are still safe in this browser. Try again.**
- Offline: **You appear to be offline. Your changes are safe in this browser and online backup will continue when the connection returns.**
- Sign-in expired: **Sign in again to continue online backup. Your local characters and waiting changes were kept.**

### Conflict

- Title: **Choose which copy to use**
- Description: **RollKeeper kept both versions. Nothing will be discarded until you choose.**
- Button: **Keep my changes**
- Keep-mine description: **Use the version in this browser for the online backup. The online version stays in recovery history.**
- Button: **Use online version**
- Use-online description: **Use the online version in this browser. Your current version stays in recovery history.**
- Button: **Keep both**
- Keep-both description: **Keep this browser's version and add the online version as another character. The added character will not be backed up until you choose it.**
- Future-data title: **This online copy needs a newer RollKeeper version**
- Future-data description: **Nothing was replaced. Download a recovery copy, then update RollKeeper before trying to use it.**
- Download button: **Download recovery copy**

### Management

- Page title: **Character backups**
- Summary: **{protected} protected, {paused} paused, {attention} need attention**
- Read-only refresh: **Check now**
- Per-character actions: **Back up now**, **Pause updates**, **Keep up to date**, **Restore here**, **Restore as another character**, **Download recovery copy**
- Future default on: **Protect new characters automatically**
- Future default description: **New characters will use online backup after they are first saved in this browser.**
- Remove action: **Remove online copy**
- Remove confirmation: **Remove the online copy of {name}? The character in this browser will stay. RollKeeper keeps the removed online copy available for recovery.**
- Remove success: **The online copy was removed. The character in this browser was not changed.**
- Pause success: **Online updates are paused. Existing local and online copies were kept.**
- Resume success: **Online backup is on again.**

### Safety-file recovery and rollback

- Section title: **Safety files and recovery**
- Description: **Save a fresh safety file, restore missing data, or open recovery options when something needs attention.**
- Buttons: **Save a new safety file**, **Restore from a safety file**, **Recovery options**
- Import title: **Review safety file**
- Import description: **Nothing has changed yet. RollKeeper will keep existing data and show different copies for review.**
- Safe restore button: **Restore missing data**
- Restore confirmation: **Restore data that is missing from this browser? Existing data will not be replaced.**
- Restore result: **Missing data was restored. Different copies were kept for review.**
- Current export: **Download current character data**
- Original export: **Download original recovery copy**
- Rollback action: **Use the earlier browser saving method**
- Rollback description: **RollKeeper can do this only after it checks that the current saved copies match and no changes are waiting.**
- Rollback confirmation: **Use the earlier saving method now? Your safety files and recovery copies will be kept.**
- Rollback refusal: **RollKeeper could not prove that every current copy matches, so nothing was changed. Open recovery options.**
- Recovery-required title: **Your characters need recovery**
- Recovery-required description: **RollKeeper could not safely open the current saved copy and did not fall back to an older one. Download the available recovery files before trying another action.**

<!-- PLAYER_BACKUP_COPY_END -->

### Vocabulary regression guard

Add a stricter `expectPlayerBackupVocabulary` helper beside `expectCloudProductVocabulary` in `src/test/helpers.ts`. It must collect separate visible text nodes and all accessible-name sources on the root and descendants: `aria-label`, resolved `aria-labelledby`, `title`, `placeholder`, and `alt`. Exercise every conditional state, including errors and dialogs.

The guard must reject case-insensitive whole-word variants of:

`IndexedDB`, `localStorage`, `manifest`, `schema`, `authority`, `epoch`, `cutover`, `migration`, `namespace`, `mutation`, `outbox`, `tombstone`, `quarantine`, `CAS`, `device`, `workflow`, `canary`, and `workspace`.

Also reject the Unicode em dash `\u2014`. Treat `sync`, `synchronization`, and `synchronized` as forbidden in the new player backup subtree even though the product brief classifies them as avoidable rather than absolutely forbidden. This keeps the new surface consistently goal-oriented.

Write mutation-resistant tests that first prove the helper fails for every forbidden word in visible text and in each accessible-name channel, including a phrase split across sibling nodes and a violation on the root element. Do not allowlist internal filenames because they should never be rendered. Scan mapped runtime failures too; raw `Error.message`, DOM exceptions, transport strings, and internal discriminants must be logged for diagnostics and replaced by channel-specific friendly copy before rendering.

## 5. Architecture and reuse map

### Reuse without semantic changes

| Capability | Reuse |
| --- | --- |
| Full pre-change safety capture | `captureDeviceBackup`, `initiateDeviceBackupDownload`, `verifyDownloadedDeviceBackup`, `browserRecoveryRepository` |
| Safety-file import before character cutover | `validateDeviceBackupJson`, `stageRecoveryBundle`, `previewRecoveryBundle`, `restoreRecoveryEntries` |
| Safety-file import after character cutover | `importCharacterRecoveryGeneration`, `activateImportedCharacterGeneration`; never restore only the compatibility mirror |
| Character preparation and activation | `selectCharacterCutover`, `bootstrapCharacterPersistence` or its existing migration primitive, `inspectCharacterCutoverReadiness`, `activatePreparedCharacterCutover`, `markCharacterCutoverActivated` |
| Character recovery and rollback | `exportCurrentCharacterData`, `exportMigrationRecovery`, `readCharacterAuthority`, `verifyCharacterRollbackGenerationAfterReopen`, `rollbackCharacterAuthority` |
| One-time online copy | `ManualCharacterCloudService`, gateway, codec, account-scoped link repository, recovery download |
| Ongoing backup | `AutomaticCharacterSyncService`, preferences, IndexedDB repository, worker, puller, coordinator, runtime |
| Conflict preservation | `IndexedDbAutomaticCharacterSyncRepository.preserveConflict`, `AutomaticCharacterConflictService` |
| Account lifecycle | Supabase browser client, `getUser`, `onAuthStateChange`, current `/account` form and controls |
| Character store application | `addCloudRecoveredCharacter`, `replaceCloudRecoveredCharacter`, `awaitCharacterPersistenceResult` |
| Interaction shell | DM wizard’s dedicated route, derived-state controller, progress rail, safety-file reselect pattern, error mapper, final live verification, and legacy-panel hiding pattern |

### New client orchestration

Add `src/lib/playerBackup/` with narrow modules rather than putting persistence calls in React components:

- `playerBackupFlags.ts`: umbrella flag and capability matrix.
- `playerBackupStatus.ts`: pure status projection that distinguishes never protected, one-time, ongoing, paused, queued, offline, sign-in required, conflict, failed, and held-aside.
- `playerBackupSafety.ts`: exact verified-receipt and fresh-source-hash gate used immediately before the local transition.
- `playerBackupCoordinator.ts`: account-token guarded orchestration for preview, confirmation, one-time backup, ongoing setup, partial results, and idempotent resume.
- `playerBackupConflictCoordinator.ts`: correlate validated existing rows and seed the existing durable conflict path without overwriting either candidate.
- `playerBackupCopy.ts`: the only mapping from internal failures/discriminants to rendered copy.

The coordinator must use an incrementing request/account token. Every async result checks the token and target account before applying UI state or writing. On account change it closes the old context, clears rows and statuses synchronously, and rebuilds from the new account. It must not derive completion from the last React state or a success toast.

Do not add a separate `wizardCompleted` record. Confirmed current-character and future-default choices belong in the existing account-scoped automatic preference records. Character selection, cutover selection, authority, documents, work, conflicts, links, and verified receipts are sufficient to derive resume. If a crash occurs before confirmed choices are durable, reopening returns to selection and requires confirmation again. If the implementation proves an additional checkpoint is unavoidable, it may be a non-authoritative record in the existing IndexedDB `meta` store, containing no character payload, and must be justified in review with a crash test. It must never become the source of completion truth.

### Required local contract hardening

The wizard must require `hasVerifiedDownloadReceipt`, not `hasDownloadReceipt`, before any character authority change. Prefer strengthening `inspectCharacterCutoverReadiness` and its `recoveryGate` interface so every caller gets the stronger guarantee. If legacy flag-off behavior must retain the old initiation-only contract for compatibility, add a distinct verified wizard gate and test that the wizard cannot call activation through the weaker path. The first option is recommended because it closes the real gap globally without a schema change.

The observable proof is:

1. the file was generated;
2. download initiation was recorded;
3. the player selected a file;
4. the selected bytes passed per-entry and aggregate validation;
5. run ID and aggregate hash matched the expected capture;
6. a verified receipt was durable;
7. a fresh capture still matched immediately before preparation and activation.

### Behavior that stays outside the wizard

- Campaign membership, invitations, deliveries, and the later player inbox.
- DM campaign-family setup and management.
- Locations, battle maps, S3 objects, Redis live play, and relay behavior.
- Character creation, editing, archive, ordinary import, and campaign joining.
- Physical online deletion or local cleanup.
- Account ownership recovery policy.
- General offline application-shell work.

No SQL, Supabase migration, new RPC, or server route is justified. The existing character RPC, RLS, receipt, soft-delete, and version contracts cover the plan. Any implementation that proposes a server change must first add a failing client-contract test proving why the current gateway cannot satisfy a specific acceptance criterion.

## 6. Feature-flag and compatibility plan

Add `NEXT_PUBLIC_PLAYER_BACKUP_WIZARD_VISIBLE=false`. It controls surface ownership only. Existing lower flags remain the enforcement boundary for each capability:

- `A`: valid auth configuration.
- `M`: `NEXT_PUBLIC_SUPABASE_CHARACTER_BACKUP_ENABLED` for one-time copy, listing, restore, verify, archive, and recovery download.
- `C`: `NEXT_PUBLIC_CHARACTER_INDEXEDDB_CUTOVER_ENABLED` for the safe local transition.
- `S`: `NEXT_PUBLIC_SUPABASE_CHARACTER_AUTOMATIC_SYNC_ENABLED` for ongoing backup.
- `W`: new wizard flag.

| Matrix | `/player` rendering | `/player/backup` behavior | Calls allowed |
| --- | --- | --- | --- |
| `W` absent or false | Exact current dashboard: header export, safety banner, full recovery section, and each legacy panel governed by its own lower flag | 404 | Exact existing behavior only |
| `W=true`, `A=false` | New compact surface; all old setup panels and header `Export All` hidden | Safety-file save/restore and friendly recovery available; online setup explains temporary unavailability | No auth client or character cloud calls |
| `W=true`, `A=true`, `M=true`, `C=false` or `S=false` | New compact surface only | One-time online copy available. Ongoing switch absent with a plain availability note. No hidden attempt to prepare local storage | Manual account/cloud calls only after confirmation |
| `W=true`, `A=true`, `C=true`, `S=true`, `M=false` | New compact surface only | Ongoing setup available. Manual list/restore/archive actions disabled; safety-file recovery remains | Automatic calls only after confirmation and participation gates |
| `W=true`, all lower capabilities true | Full recommended setup and management | Both one-time and ongoing choices, restore, and recovery | Each lower service still rechecks its own flag and account/local prerequisite |
| `W=true`, lower flag turned off after setup | Compact degraded management, never the old technical panels | Existing local and online evidence remains visible in friendly status; the disabled action is unavailable, recovery exports remain | No calls through the disabled capability |

When `W=true`, the new surface is always the owner of setup layout even if a lower capability is unavailable. This prevents a runtime flag rollback from bringing the scattered technical panels back. A lower flag disables behavior, not the surface shell.

Clean `.env.example` so every relevant flag appears once and defaults false. It currently repeats auth, cutover, automatic, and manual settings with conflicting later values. Code is default-off when variables are absent, but the sample configuration does not communicate one trustworthy default.

Under effective wizard rendering, hide:

- `DataSafetyBanner`;
- the header `Export All` action;
- the `Full browser recovery` section containing `DeviceRecoveryControls` and `CharacterStorageMigrationControls`;
- `CharacterCloudBackupControls`;
- `CharacterAutomaticSyncControls`.

Keep ordinary `Import`, new character, archive, duplicate, and play actions. Replace the hidden surfaces with `PlayerBackupSummaryCard`; route recovery and management capabilities through the new management view. When `W=false`, do not alter any existing rendering or storage behavior.

## 7. Implementation plan

Every task starts with a focused failing test and records the red result before implementation.

### Task 1: umbrella flag and non-vacuous routing

Files:

- `src/lib/playerBackup/playerBackupFlags.ts`
- `src/lib/playerBackup/__tests__/playerBackupFlags.test.ts`
- `src/app/player/backup/page.tsx`
- `src/app/player/backup/__tests__/page.test.tsx`
- `.env.example`

Red tests:

- absent, `false`, `TRUE`, and `1` do not enable the umbrella;
- exact `true` enables the route;
- direct navigation is 404 when off;
- each lower capability matrix makes zero calls through disabled services;
- repeated sample flags are rejected by a configuration test.

### Task 2: pure copy and status projection

Files:

- `src/lib/playerBackup/playerBackupStatus.ts`
- `src/lib/playerBackup/playerBackupCopy.ts`
- matching tests
- `src/test/helpers.ts`
- `src/test/__tests__/expectPlayerBackupVocabulary.test.ts`

Red tests:

- every state in Section 3 maps to exactly one plain status;
- paused and one-time never collapse to not-backed-up;
- a stale account token cannot project prior-account rows;
- every raw error/discriminant is mapped, not rendered;
- every forbidden term and em dash reddens visible and accessible-name channels.

This task is pure and should land before layout or persistence orchestration.

### Task 3: account-aware read-only preview

Files:

- `src/lib/playerBackup/playerBackupCoordinator.ts`
- `src/components/ui/character/PlayerBackupWizard/PlayerBackupWizard.hooks.ts`
- `src/app/account/page.tsx`
- `src/components/auth/AuthPageClient.tsx`
- account and coordinator tests

Red tests:

- opening the route lists the signed-in account only and makes no write;
- signed out makes no cloud call;
- account switch clears old rows synchronously, closes/stops the old context, discards stale responses, and performs no adoption;
- `returnTo` accepts only the exact internal backup route and cannot form an open redirect;
- sign-in, sign-out, view, and navigation create no cutover selection, preference, document, pending work, cloud write, or new local database for an untouched control profile.

### Task 4: verified safety-file gate

Files:

- `src/lib/playerBackup/playerBackupSafety.ts`
- `src/lib/indexeddb/characterCutoverControl.ts`
- `src/lib/browserRecoveryRepository.ts` only if its public interface needs narrowing
- current recovery/cutover tests plus new coordinator tests

Red tests:

- generated or initiated-only downloads cannot pass;
- wrong file, tampered entry, altered aggregate, wrong run, and source drift cannot pass;
- a matching reselected file creates a verified durable receipt;
- fresh hash is rechecked before selection and activation;
- no selection, preparation, active pointer, preference, document, or cloud write occurs on every failure;
- a previously verified matching entry vector resumes without another download.

### Task 5: local preparation orchestration

Files:

- `src/lib/playerBackup/playerBackupCoordinator.ts`
- existing character migration/cutover modules only where a reusable public orchestration primitive is missing
- focused Slice 7 and 8 tests

Red tests:

- one final confirmation drives one family-level preparation, never one per character;
- pre-commit failure leaves legacy primary and characters usable;
- activation happens only after verified receipt, unchanged source, reopen, parity, empty journal, and no character quarantine;
- response loss/reload resumes idempotently from real selection/authority;
- closing before confirmation writes nothing;
- interrupted confirmed setup presents **Continue setup** and does not advance merely by viewing;
- unrelated RollKeeper keys and all DM-family authority remain byte-identical.

### Task 6: one-time and ongoing online orchestration

Files:

- `src/lib/playerBackup/playerBackupCoordinator.ts`
- `src/lib/supabase/automaticCharacterSyncPreferences.ts` for an explicit future-default-off operation
- existing hooks/services only for small reusable API extractions
- coordinator, manual service, preference, and automatic service tests

Red tests:

- all eligible characters are selected by default; cleared characters get explicit off overrides;
- ongoing confirmation enables selected current characters and future default only for the confirmed account;
- one-time confirmation uses manual verified backup and leaves ongoing preferences off;
- per-character completion requires refetch and fingerprint/version validation;
- partial failure continues to other selected characters and reports exact results;
- response-loss retry reuses identity;
- pause retains acknowledged online data and pending work;
- turning the future default off does not alter existing per-character choices;
- no unselected or other-account character is uploaded or changed.

### Task 7: existing-copy and conflict orchestration

Files:

- `src/lib/playerBackup/playerBackupConflictCoordinator.ts`
- `src/lib/playerBackup/playerBackupCoordinator.ts`
- existing automatic repository/conflict service only for a narrowly required public helper
- focused codec, manual, automatic conflict, worker, and coordinator tests

Red tests:

- identical row attaches/verifies without duplicate upload;
- newer/different/archived/future/unavailable states map correctly;
- a differing manual candidate is preserved through the existing durable conflict path rather than overwritten;
- all three resolutions preserve the losing candidate and match current Slice 9 semantics;
- keep-both copy starts with ongoing backup off;
- one-time mode returns to off only after a verified terminal resolution;
- an archived online row is never resurrected by setup without explicit choice;
- another account’s links, rows, conflicts, and held-aside records are neither rendered nor modified.

### Task 8: wizard route and responsive UI

Files:

- `src/app/player/backup/PlayerBackupRoute.tsx`
- `src/components/ui/character/PlayerBackupWizard/index.tsx`
- `PlayerBackupWizard.types.ts`
- `steps/AccountStep.tsx`
- `steps/SafetyFileStep.tsx`
- `steps/CharacterSelectionStep.tsx`
- `steps/ResultStep.tsx`
- component and route tests

Red tests cover every state/copy item, back/close behavior, keyboard operation, focus on new alerts/headings, file-input accessible name, narrow layout without horizontal overflow, and light/dark semantic tokens. Use existing `Dialog`, `Button`, `Checkbox`, `Switch`, `Card`, and `Badge`; do not create new primitives.

### Task 9: dashboard replacement and compact management

Files:

- `src/app/player/page.tsx`
- `src/app/player/__tests__/page.test.tsx`
- `src/components/ui/character/PlayerBackupSummaryCard.tsx`
- `src/components/ui/character/PlayerBackupManager.tsx`
- their tests

Red tests:

- wizard on hides all five old backup/setup surfaces and header export in every lower-flag combination;
- wizard off keeps the exact existing surfaces and flags;
- summary is derived after reload and account change;
- status counts distinguish ongoing, one-time, paused, busy, and attention;
- completed setup is compact and does not leave the wizard expanded;
- manage/restore actions remain reachable.

### Task 10: friendly recovery integration

Files:

- `src/components/ui/character/PlayerBackupRecovery.tsx`
- `src/components/PersistenceBootstrap.tsx`
- adapters around `DeviceRecoveryControls` and `CharacterRecoveryExportControls`, or replacements that call the same services
- recovery component and character recovery tests

Red tests:

- before cutover, restore adds only missing values and preserves collisions;
- after cutover, character entries import into an inactive character generation and never merely update a stale mirror;
- divergent active/imported data enters recovery required with both candidates retained;
- rollback remains parity/reopen/journal gated;
- all current and original recovery downloads remain reachable in fail-closed state;
- wizard-on recovery copy passes the strict vocabulary guard;
- wizard-off legacy recovery rendering remains compatible.

### Task 11: regression gates and manual acceptance preparation

Files:

- `config/vitest/playerBackupWizard.config.ts`
- `package.json`
- `.github/workflows/ci.yml` if the focused gate belongs in CI
- `.agents/skills/rollkeeper-manual-browser/references/acceptance-checklist.md`
- fake seed script only if additional deterministic player conflict fixtures are required

Add focused coverage thresholds for destructive/account-routing branches. Update the manual checklist with a player-wizard section; do not replace the existing DM checklist.

## 8. Verification plan

### Focused automated checks

- New player wizard flag, route, pure status/copy, coordinator, conflict, component, dashboard, management, and recovery tests.
- Existing `DataSafetyBanner`, `DeviceRecoveryControls`, `CharacterStorageMigrationControls`, cloud controls, automatic controls, and both hooks under flag-off compatibility.
- `deviceRecovery`, `browserRecoveryRepository`, all character cutover/bootstrap/authority/recovery tests, manual cloud service/gateway/codec/link tests, automatic repository/preferences/service/worker/puller/coordinator/runtime/conflict tests, and `playerStore` recovery application tests.
- Mutation-resistant vocabulary-helper tests and rendered checks for every wizard/management/error state.
- Component checks at narrow and desktop sizes, light and dark themes, tab/shift-tab order, Enter/Space activation, Escape/close behavior, focus restoration, live-region roles, and complete accessible names.

### Existing Slice 7, 8, and 9 contracts

Run and record separately:

```text
npm test -- src/lib/indexeddb/__tests__/persistenceBootstrap.test.ts src/lib/indexeddb/__tests__/migrationEngine.test.ts src/lib/indexeddb/__tests__/migrationCapture.test.ts src/lib/indexeddb/__tests__/migrationValidation.test.ts
npm run test:slice8:coverage
npm run test:slice9:coverage
npm run test:indexeddb:e2e
npm run test:automatic-sync:e2e
```

The first command is the focused Slice 7 floor because the repository has no dedicated Slice 7 script. Do not call that path passed until it has actually run.

### Full regression gates

```text
npm test
npm run test:visual
npm run test:e2e
npm run test:auth:e2e
npm run type-check
npm run lint:ci
npm run format:ci
npm run build
npm run db:reset
npm run db:lint
npm run db:test
npm run db:types:check
npm run test:db:replay
npm run test:db:integration
npm run test:auth:integration
```

Run database gates because the wizard reuses security-sensitive character RPCs even though no SQL change is planned. Treat environment-blocked checks as blocked, not passed. Separate automated evidence from manual-browser evidence.

### Final interactive browser gate

After all automated checks pass, use `.agents/skills/rollkeeper-manual-browser/SKILL.md` through the Codex desktop in-app Browser only. If the desktop Browser is unavailable, the verdict is **blocked**. Standalone Playwright is supplemental and cannot satisfy this gate.

Use an ephemeral local server, local fake auth/cloud services, deterministic synthetic data, and new host-isolated origins. Suggested origins:

- `rk-player-control.localhost`: umbrella off, every lower flag on, proving a non-vacuous legacy control.
- `rk-player-a.localhost`: participating account A and the main setup.
- `rk-player-b.localhost`: identical starting profile and account B/account-switch isolation.
- `rk-player-conflict.localhost`: independent same-account changes for conflict paths.

Required scenarios:

1. Generate the skill seed, create the synthetic character through visible UI, add the emitted unrelated entries, and prove identical raw-pair counts, UTF-8 bytes, and hashes across starting origins.
2. On the control origin, prove no wizard launcher, direct route absence, legacy panels still present according to lower flags, no new player-wizard record, no cutover selection/database, and no character cloud write from view, sign-in, sign-out, reload, or navigation.
3. On A, open through the visible launcher; verify signed-out and sign-in return behavior. Prove sign-in itself writes no character/storage selection.
4. Download the safety file through visible controls, independently parse it, and verify format/version, every entry byte count/hash, aggregate hash, and expected character/unrelated entries. Prove download initiation alone cannot continue. Reselect it and prove the verified receipt before any local ownership change.
5. Cancel before final confirmation and prove zero selection, active pointer, preference, document, pending work, or cloud write. Reload and confirm safe resume.
6. Run the default all-character ongoing flow. Observe the exact confirmation, then prove local activation gates and a validated online acknowledgement. A success message is insufficient: refetch the row and compare identity, server version, and content fingerprint.
7. Reload, navigate away/back, open a second same-origin tab, and prove the compact dashboard summary derives from durable state and edits remain acknowledged before their online status changes.
8. Exercise one-time mode and prove later edits do not create new cloud work. Then use **Back up now** and verify the new acknowledged version.
9. Go offline after a confirmed edit. Prove local acknowledgement and retained pending work, reload offline, restore connectivity, retry/resume, and validate the eventual row. Inject committed-response loss and prove the same mutation identity is retried.
10. Use two same-account isolated origins to create a conflict. Exercise **Keep my changes**, **Use online version**, and **Keep both** from fresh deterministic resets. Prove neither candidate disappears, discarded candidates are retained, and the keep-both character starts with online backup off.
11. Inject future-format online data. Prove active local data remains, recovery download contains the exact raw candidate, and no forbidden implementation term appears.
12. Switch from account A to B. Prove A’s rows/statuses disappear immediately, B cannot see/adopt/modify them, and zero B write occurs until a new explicit confirmation. Switch back and verify A’s state returns.
13. Pause and resume one character, turn the future default off/on, and soft-remove an online copy. Prove pausing deletes nothing and soft removal changes no local character.
14. Restore an absent character, restore a collision as another character, import a safety file before and after cutover, and exercise recovery-required exports and a successful parity-gated rollback. Validate downloaded artifacts independently.
15. Compare unrelated DM, encounter, NPC, calendar, location, battle-map, combat-log, magic-item, canvas, theme, and sentinel raw hashes at the end. They must remain byte-identical except for an explicitly exercised recovery action targeting that key.
16. Check 390 px and desktop layouts, light and dark themes, keyboard-only completion, focus after step changes/errors, accessible names, live regions, and no horizontal overflow.

Report branch, commit, exact local flags, port, origin labels, seed version, counts/bytes/abbreviated hashes, visible actions, durable evidence, reload/multi-tab results, failure paths, artifact verification, automation, limitations, and an explicit pass/fail/blocked verdict. Do not print raw payloads or secrets.

## 9. Risks, unresolved decisions, and non-goals

### Material risks and mitigations

1. **Initiated is not verified.** Current character cutover accepts an initiated download receipt. The wizard must strengthen this before implementation can claim the required safety guarantee. This is the largest safety risk.
2. **Two online mechanisms can disagree in presentation.** Manual links and automatic documents can describe the same server row. A single status projector must correlate them by account and legacy character ID and must prefer validated durable/server facts over the last UI action.
3. **One-time conflict resolution has no current friendly orchestrator.** The manual service fails closed, but the durable three-way resolver lives in Slice 9. The proposed conflict coordinator must reuse that resolver; a bespoke last-write-wins path is unacceptable.
4. **Recovery differs before and after character cutover.** Generic safety-file restore writes browser values, while active character recovery must import an inactive character generation. The manager must route by actual authority and never treat a mirror write as active recovery.
5. **Account switches race asynchronous reads.** Token every request and recheck account identity immediately before writes. Clear old-account render state synchronously.
6. **The broad safety file contains more than characters.** State this plainly and tell the player to keep it private. Only selected characters go online.
7. **Current `.env.example` is contradictory.** Duplicate later values can undermine default-off rollout expectations. Normalize it as part of the flag task.
8. **Authorized retry can be mistaken for implicit upload.** Tests must distinguish a first enrollment caused by view/navigation, which is forbidden, from resuming work the player already confirmed, which is required for ongoing backup.
9. **Raw lower-layer errors contain forbidden language.** All error channels need closed mappings, including DOM exceptions, auth errors, gateway errors, recovery errors, and conflict reasons.

### Resolved defaults, not blockers

- Broad safety file, not character-only.
- All eligible active and archived characters selected by default.
- Ongoing backup recommended and on by default; one-time copy remains an explicit alternative.
- Selection and confirmation share one screen.
- Dedicated `/player/backup` route.
- Compact dashboard status after completion.
- Soft archive only for **Remove online copy**.
- No server or SQL work unless a failing test proves a gap.

There is no product decision that must block implementation. If the product owner wants one-time copy to be the default instead of ongoing backup, that is a deliberate policy reversal and should be decided before Task 6, but the recommendation is ongoing by default.

### Non-goals

- Player inbox, deliveries, campaign membership adoption, or guest-to-account linking.
- DM locations, battle maps, campaign sections, or DM wizard changes beyond reusable patterns/checklist additions.
- New cloud tables, RPCs, or hard deletion.
- Moving image data to another object store.
- General local cleanup or recovery-history deletion.
- Replacing current character creation/import/archive/play flows.

## 10. Acceptance criteria

### Product outcomes

- With the umbrella flag on, `/player` has one obvious setup action and none of the five old setup/backup surfaces or header `Export All` action.
- With the umbrella flag off, existing behavior and lower-flag rendering are unchanged.
- The player can sign in, return to the backup route, save and reselect a safety file, choose characters, choose ongoing or one-time behavior, explicitly confirm, and receive a verified per-character result.
- All eligible active and archived characters start selected; cleared characters remain untouched.
- Ongoing setup applies one account default for new characters and clear per-character off overrides.
- After completion, the dashboard shows compact, truthful counts and management/restore entry points rather than the expanded wizard.
- Every rendered wizard, summary, management, recovery, error, accessible name, placeholder, title, and alt string passes the strict vocabulary and no-em-dash guard.

### Consent and no-surprise outcomes

- Viewing, signing in, signing out, navigating, opening, closing, or reloading cannot enroll a new character, select character cutover, create first-upload work, or change local ownership.
- No online write begins until the final account/count/consequence confirmation.
- Download initiation cannot unlock local transition. The exact reselected file and fresh source capture must be verified first.
- Switching accounts invalidates the preview and confirmation. The new account requires a fresh account check and confirmation.
- No unselected character and no other-account row is read into the UI, adopted, or modified.

### Durability and recovery outcomes

- A character is labeled protected only after a refetched, decoded, identity/version-checked, fingerprint-matching online row exists.
- Local save success remains tied to the active durable write or journal outcome, not an HTTP response or toast.
- Failure before active-pointer commit leaves the old local path primary. Failure after commit never silently falls back.
- Existing local character data, compatibility mirrors, immutable captures, recovery files, conflicts, held-aside data, pending work, and tombstones remain recoverable.
- Safety-file import before and after cutover targets the correct recovery path and never silently overwrites a divergent active character.
- Rollback is reachable and succeeds only after parity, reopen, and empty-journal proof.

### Cloud and conflict outcomes

- Identical existing online copies are recognized without duplication.
- Newer, different, archived, unavailable, and future-format online copies produce distinct friendly states and never trigger silent overwrite or resurrection.
- All three conflict choices preserve the losing candidate and retain current Slice 9 semantics.
- One conflicted or failed character does not stop unrelated selected characters. Final results report partial success exactly.
- Offline work, expired auth, response loss, crash/reload, and retry retain their identity and recover without duplicate accepted writes.
- Pausing ongoing backup deletes neither local nor online data. Removing an online copy is a separate explicit soft archive.

### Isolation and regression outcomes

- Character setup changes no DM-family authority or unrelated RollKeeper raw value.
- Account A and B preferences, documents, pending work, conflicts, links, rows, and held-aside records remain isolated across switches.
- Slice 7, Slice 8, Slice 9, full unit, IndexedDB browser, automatic browser, auth browser, visual, production build, lint/format/type, and database regression gates pass or are reported honestly as blocked/failed.
- The final Codex desktop in-app Browser gate passes on isolated origins with deterministic fake data, or the PR remains blocked and is not called ready.
