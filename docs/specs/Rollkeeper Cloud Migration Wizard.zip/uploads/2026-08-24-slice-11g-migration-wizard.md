# Slice 11G — Guided whole-device migration wizard: Implementation Plan

> **For agentic workers:** Steps use checkbox (`- [ ]`) syntax for tracking. Where the `superpowers:*` skills are available, use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. They are not available in every harness — Codex in this workspace does not have them — so treat them as the preferred workflow, not a prerequisite. Without them, execute the tasks in order, one at a time, with a fresh review between tasks; the TDD steps and mutation checks in each task are the contract either way.

**Goal:** A registry-driven wizard that runs the hardened per-family migration chain once for a whole device, behind a default-off flag, wrapping the six shipped families without introducing new authority, manifest or RPC semantics.

**Architecture:** A `DurableFamilyAdapter` of plain async functions over `src/lib/durableDm/*`, `src/lib/indexeddb/*` and the existing `*Api` gateways — never over the React controllers. One verified whole-device recovery bundle per run, reused by every family. All wizard state is derived from existing markers, IndexedDB pointers and recovery receipts; the wizard persists nothing of its own. Cloud activation is response-loss-safe through deterministic mutation IDs that replay the server's existing mutation receipts.

**Tech Stack:** Next.js App Router (read `node_modules/next/dist/docs/` before writing route code), TypeScript, Zustand + `persist`, IndexedDB (`rollkeeper-local`, `rollkeeper-recovery`), Supabase Postgres RPC via existing per-family API routes, Vitest + Testing Library, Storybook/Playwright for the visual project.

**Spec:** `docs/superpowers/specs/2026-08-24-slice-11g-migration-wizard-design.md` — read it first. Every task below argues from a numbered ruling in it.

## Global Constraints

- Base branch `master` at `69ca53a6`. Work on `feat/slice-11g-migration-wizard`.
- Flag: `NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE`, default off. Client-only. Gate the launcher **and** the route independently.
- **Zero server change** (spec R9): no SQL, no migration, no new API route, no RPC, no server flag. If a task seems to need one, stop and escalate.
- **Never** `git add -A`, and **never** `git add -u`. Stage explicit paths only, by name.
- **Never** `npm run db:reset` — it destroys the local development database.
- **Never** repo-wide `npm run format`. Run `npx prettier --write` on touched paths only.
- Preserve, never edit or delete: `BACKPORT_EVIDENCE.md`, the **existing** `SLICE_*_EVIDENCE.md` files, `SUPABASE_CLOUD_SYNC_PLAN.md`, `CODEBASE_AUDIT.md`, `docs/superpowers/*` (other than adding this slice's own files). `SLICE_11G_EVIDENCE.md` is this slice's own evidence file and is written throughout — it is the one exception.
- No secrets, project identifiers, connector URLs, emails, OTPs, tokens or user payloads in code, tests, commits or evidence.
- Design system only: `Dialog` from `@/components/ui/feedback/dialog`, `Button`, `Card`, `Badge` etc. Never the legacy `Modal`. Never `window.confirm` (spec R12).
- Semantic colour tokens only — `bg-surface`, `text-body`, `border-divider`, `text-accent-*-text`. Never `bg-gray-800` or `text-white`.
- Strict TDD: write the failing test, run it, watch it fail with the quoted message, implement, watch it pass. Every guard gets a mutation check — delete or weaken the guard, observe the specific test go red, restore.
- Slice coverage configs live at `config/vitest/slice*.config.ts` and run via `test:slice*:coverage` (moved in #269). 11G follows that layout, **not** the repo root.
- Commit per task. Do not merge. Do not open a PR without explicit approval.

---

## File Structure

**New — library (all covered by the 11G coverage contract):**

| File | Responsibility |
|---|---|
| `src/lib/durableDm/slice11gFlags.ts` | `isMigrationWizardVisible()` |
| `src/lib/durableDm/migrationMutationIds.ts` | Deterministic UUID derivation (R7) |
| `src/lib/durableDm/familyAuthorityNormalizer.ts` | Marker + pointer reconciliation, `inconsistent` (R5) |
| `src/lib/durableDm/resumableCloudActivation.ts` | Response-loss-safe activation protocol (R7) |
| `src/lib/durableDm/durableFamilyAdapter.ts` | Interface, run context, shared types (R1) |
| `src/lib/durableDm/adapters/campaignSettingsAdapter.ts` … `combatLogArchiveAdapter.ts` | Six adapters |
| `src/lib/durableDm/familyRegistry.ts` | Fixed order, registered + planned entries |
| `src/lib/durableDm/migrationRunState.ts` | Derived step state (R6) |
| `src/lib/durableDm/authorityRepair.ts` | Evidence-backed repair of a partial transition (Task 13b) |

**New — UI:**

| File | Responsibility |
|---|---|
| `src/app/dm/migrate/[code]/page.tsx` | Flag-gated route outside the campaign layout (R2a) |
| `src/components/ui/campaign/MigrationWizard/index.tsx` | Dialog shell, step routing, progress |
| `src/components/ui/campaign/MigrationWizard/MigrationWizard.hooks.ts` | Run controller: discovery, recovery, per-family execution |
| `src/components/ui/campaign/MigrationWizard/MigrationWizard.types.ts` | Local view types |
| `src/components/ui/campaign/MigrationWizard/steps/WorkspaceStep.tsx` | Step 0 |
| `src/components/ui/campaign/MigrationWizard/steps/RecoveryStep.tsx` | Step 1 |
| `src/components/ui/campaign/MigrationWizard/steps/FamilyStep.tsx` | Steps 2..N |
| `src/components/ui/campaign/MigrationWizard/steps/ReportStep.tsx` | Final report |

**Modified:**

| File | Change |
|---|---|
| `src/lib/browserRecoveryRepository.ts` | `readVerifiedDownloadReceipt`, entry vector (R4, additive) |
| `src/lib/deviceRecovery.ts` | Pass the entry vector into the receipt (R4, additive) |
| `src/lib/durableDm/*AwareStorage.ts` | Only where Task 1's preflight proves a fixpoint defect (R3) |
| `src/app/dm/page.tsx` | Launcher + dashboard hardening (R2b) |
| `package.json` | `test:slice11g:coverage` |
| `.agents/skills/rollkeeper-manual-browser/{scripts,references}/` | Multi-family seed + §11G scenarios (shared by both harnesses; never its `SKILL.md`) |

---

## Task 0: Gate capability preflight (BLOCKING — requires the user)

**Spec:** R16 phase 1. This task has no code and no commit. Implementation does not begin until it passes.

**Why it blocks:** Slice 11F's gate and the controller backport's gate were both reported BLOCKED/PARTIAL because an agent cannot create an account. Every cloud-authoritative path in this program currently has zero manual evidence. Starting implementation before proving the capability repeats that for a third slice.

- [ ] **Step 1: Ask the user to create the synthetic owner**

Post exactly this request and stop:

**The agent starts the services; the user only signs in.** `docker-compose up -d` starts Redis and its HTTP proxy — it does **not** start local Supabase and cannot provide authentication. Bring up all three yourself first:

```bash
npm run db:start          # supabase start — this is what provides auth and Mailpit
docker-compose up -d      # Redis + serverless-redis-http on 8079
node scripts/start-guest-manual-server.mjs   # once per origin/port, MANUAL_GUEST_ENABLED=false
```

Origins, matching prior gates: `rk-pr-a.localhost:<portA>` and `rk-pr-b.localhost:<portB>`. Only one `next dev` can hold the port lock, so the servers run sequentially, not concurrently.

Then post exactly this and stop:

> The local stack is up on both origins. Please sign in with a synthetic
> `@example.test` address via local Mailpit on **both**. Do not use a real
> account. Tell me when both sessions exist.

- [ ] **Step 2: Verify both origins reach the same owner workspace**

Origin A: create or fork the workspace through the DM dashboard's cloud workspace controls.

Origin B: **do not** use the dashboard's "Load local cloud workspaces" — it reads this device's local IndexedDB and will not discover A's workspace. Open a family card on B and run its owner-workspace discovery, which queries the account. Both origins must reach the same workspace with the same `cloudId`.

- [ ] **Step 3: Record the outcome**

Write `SLICE_11G_EVIDENCE.md` (git-ignored, local) with a `## Gate capability preflight` section stating: both origins, both sessions discovered the same owner workspace, date. **No OTP, token, address or credential in the file.**

If either session cannot be created, stop the whole plan and report 11G as **blocked**. Not skipped, not deferred.

---

## Task 1: Aware-storage fixpoint preflight, and any fixes it proves

**Spec:** R3. Blocking for the wizard, because it decides whether one bundle can survive a whole run.

**Files:**
- Test: `src/lib/durableDm/__tests__/awareStorageFixpoint.test.ts` (create)
- Modify (only where the test proves a defect): `src/lib/durableDm/campaignSettingsAwareStorage.ts`, `calendarAwareStorage.ts`, `magicItemAwareStorage.ts`, `npcAwareStorage.ts`, `encounterAwareStorage.ts`, `combatLogArchiveAwareStorage.ts`

**Interfaces:**
- Consumes: nothing.
- Produces: a proven answer to "does a post-cutover persist change the legacy key's bytes?" for each of the six families. The wizard's one-bundle design (Task 15) depends on it.

**Background the implementer needs:** each family installs a Zustand `StateStorage` wrapper that, once a campaign's authority marker says `indexedDB` or `postgres`, restores that campaign's fields from the *previous* envelope so the legacy key freezes. `createCombatLogArchiveAwareStorage` rebuilds `state.encounters` as `[entries whose campaign is not routed, in the next envelope's order]` followed by `[routed entries, in the previous envelope's order, campaign code ascending]`. If the original envelope interleaved two campaigns, that reconstruction can emit the same data in a different key order — different bytes, different SHA-256, different device manifest hash, and the wizard would demand a fresh recovery bundle after every single family.

- [ ] **Step 1: Write the failing test**

```ts
import { describe, expect, it } from 'vitest';

import { createCombatLogArchiveAwareStorage } from '../combatLogArchiveAwareStorage';

function memoryStorage(seed: Record<string, string> = {}) {
  const map = new Map(Object.entries(seed));
  return {
    getItem: (key: string) => map.get(key) ?? null,
    setItem: (key: string, value: string) => void map.set(key, value),
    removeItem: (key: string) => void map.delete(key),
    key: (index: number) => [...map.keys()][index] ?? null,
    clear: () => map.clear(),
    get length() {
      return map.size;
    },
  } as Storage;
}

const ROUTED = 'ALPHA';
const UNROUTED = 'BETA';

/** Archives deliberately interleaved: ALPHA, BETA, ALPHA. */
function interleavedEnvelope() {
  return JSON.stringify({
    version: 2,
    state: {
      encounters: {
        'a-1': { campaignCode: ROUTED, events: [] },
        'b-1': { campaignCode: UNROUTED, events: [] },
        'a-2': { campaignCode: ROUTED, events: [] },
      },
      combatLogTombstones: {},
      activeArchiveId: null,
    },
  });
}

describe('combat log archive aware storage — device manifest stability', () => {
  it('leaves the legacy envelope byte-identical when a routed campaign is re-persisted unchanged', () => {
    process.env.NEXT_PUBLIC_COMBAT_LOG_SYNC_VISIBLE = 'true';
    const before = interleavedEnvelope();
    const storage = memoryStorage({
      'rollkeeper-combat-log': before,
      [`rollkeeper:combat-log-archive-authority:${ROUTED}`]: JSON.stringify({
        version: 1,
        campaignCode: ROUTED,
        authority: 'indexedDB',
        epoch: 1,
        accountId: 'account-1',
        campaignId: 'campaign-1',
      }),
    });
    const aware = createCombatLogArchiveAwareStorage(storage);

    // The store re-persists exactly what it already holds. Nothing changed.
    aware.setItem('rollkeeper-combat-log', before);

    expect(storage.getItem('rollkeeper-combat-log')).toBe(before);
  });
});
```

- [ ] **Step 2: Run it and record the result verbatim**

Run: `npx vitest run --project unit src/lib/durableDm/__tests__/awareStorageFixpoint.test.ts`

Copy the exact assertion output into `SLICE_11G_EVIDENCE.md`. Two possible outcomes, and they lead to different work:

- **PASS** — this family's reconstruction is already a byte fixpoint. Record it and move to the next family.
- **FAIL** (expected shape: `expected '{"version":2,"state":{"encounters":{"a-1"…` to be `'…{"b-1"…`) — the reconstruction reordered semantically identical data. That is the aware-storage defect the spec names, not wizard behaviour.

- [ ] **Step 3: Repeat the test for the other five families**

Add one `describe` block per family in the same file, each with an interleaved two-campaign envelope in that family's own shape and that family's own marker key and value schema:

| Family | Legacy key | Marker key | Marker `authority` value to seed |
|---|---|---|---|
| `campaign_settings` | `rollkeeper-dm-data` | `rollkeeper:campaign-settings-projection-authority:ALPHA` | `indexedDB` |
| `calendar` | `rollkeeper-calendar-data` | `rollkeeper:calendar-projection-authority:ALPHA` | `indexedDB` |
| `magic_item` | `rollkeeper-dm-magic-item-library` | `rollkeeper:magic-item-authority:ALPHA` | `indexedDB` |
| `npc` | `rollkeeper-npc-data` | `rollkeeper:npc-authority:ALPHA` | `indexedDB` |
| `encounter_definition` | `rollkeeper-encounter-data` | `rollkeeper:encounter-authority:ALPHA` | `indexedDB` |
| `combat_log_archive` | `rollkeeper-combat-log` | `rollkeeper:combat-log-archive-authority:ALPHA` | `indexedDB` |

Set each family's client flag in the test (`NEXT_PUBLIC_CAMPAIGN_SETTINGS_SYNC_VISIBLE`, `NEXT_PUBLIC_CALENDAR_SYNC_VISIBLE`, `NEXT_PUBLIC_MAGIC_ITEM_SYNC_VISIBLE`, `NEXT_PUBLIC_NPC_SYNC_VISIBLE`, `NEXT_PUBLIC_ENCOUNTER_SYNC_VISIBLE`, `NEXT_PUBLIC_COMBAT_LOG_SYNC_VISIBLE`); confirm each exact name from that family's `slice11*Flags.ts` before writing it.

- [ ] **Step 4: Fix only the families that failed**

The fix is in the aware storage, never in the wizard. Add an early identity check before the reconstruction is written, so a semantically-unchanged write cannot change the bytes:

```ts
// A rewrite that reproduces the same data in a different key order still
// changes the device recovery manifest hash, which would force the migration
// wizard to demand a fresh bundle after every family. Compare the routed
// reconstruction against the previous raw envelope and write nothing when the
// content is unchanged.
const routedRaw = JSON.stringify(next);
if (routedRaw === previousRaw) return;
```

`campaignSettingsAwareStorage` and `combatLogArchiveAwareStorage` already carry this check. If a family fails despite it, the reconstruction itself reorders — fix the ordering so routed entries are emitted in the previous envelope's own key order rather than appended, and re-run.

- [ ] **Step 5: Mutation-verify each fix**

For every file you changed, delete the identity check (or revert the ordering fix), run that family's test, confirm it goes red, quote the failure line into the evidence file, restore.

- [ ] **Step 6: Run the affected families' existing suites**

Run: `npx vitest run --project unit src/lib/durableDm/` — all existing aware-storage tests must stay green. Any family you changed must also pass its slice contract, e.g. `npm run test:slice11f:coverage`.

- [ ] **Step 7: Commit**

```bash
git add src/lib/durableDm/__tests__/awareStorageFixpoint.test.ts
# plus only the aware-storage files that actually needed a fix
git commit -m "test: prove device manifest stability across every durable family cutover"
```

---

## Task 2: Flag module and the 11G coverage contract

**Files:**
- Create: `src/lib/durableDm/slice11gFlags.ts`, `src/lib/durableDm/__tests__/slice11gFlags.test.ts`
- Create: `config/vitest/slice11g.config.ts`
- Modify: `package.json`

**Interfaces:**
- Produces: `isMigrationWizardVisible(): boolean`. Every later task's route, launcher and registry read it.

- [ ] **Step 1: Write the failing test**

```ts
import { afterEach, describe, expect, it } from 'vitest';

import { isMigrationWizardVisible } from '../slice11gFlags';

const original = process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE;

afterEach(() => {
  process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE = original;
});

describe('isMigrationWizardVisible', () => {
  it('is off when the flag is unset', () => {
    delete process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE;
    expect(isMigrationWizardVisible()).toBe(false);
  });

  it('is off for any value other than the exact string "true"', () => {
    process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE = 'TRUE';
    expect(isMigrationWizardVisible()).toBe(false);
    process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE = '1';
    expect(isMigrationWizardVisible()).toBe(false);
  });

  it('is on for the exact string "true"', () => {
    process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE = 'true';
    expect(isMigrationWizardVisible()).toBe(true);
  });
});
```

- [ ] **Step 2: Run it and watch it fail**

Run: `npx vitest run --project unit src/lib/durableDm/__tests__/slice11gFlags.test.ts`
Expected: `Failed to resolve import "../slice11gFlags"`.

- [ ] **Step 3: Implement**

```ts
export function isMigrationWizardVisible() {
  return process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE === 'true';
}
```

- [ ] **Step 4: Run it and watch it pass**

Run: `npx vitest run --project unit src/lib/durableDm/__tests__/slice11gFlags.test.ts`
Expected: 23 passed.

- [ ] **Step 5: Add the coverage contract**

Create `config/vitest/slice11g.config.ts`. Copy `config/vitest/slice11f.config.ts` as the structural model and change `name`, `reportsDirectory`, `include` and `coverage.include`. Keep the warning comment, adapted:

```ts
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { defineConfig } from 'vitest/config';

// Slice 11G coverage contract for the migration wizard.
//
// WARNING for the next reader: the wizard component
// (src/components/ui/campaign/MigrationWizard/) runs as part of this suite via
// test.include, but is deliberately NOT in coverage.include. coverage.include
// lists the src/lib/** modules only. The percentages this config reports
// measure those library modules and are NEVER evidence that the wizard's
// guards — the one-bundle receipt gate, the per-family typed confirmation, the
// skip/cancel no-write rule, and the report's completion claims — are covered.
// Guard coverage for the wizard is demonstrated only by the wizard's own tests
// and the mutation-verify red/green cycle recorded in SLICE_11G_EVIDENCE.md.
// See the same caveat in BACKPORT_EVIDENCE.md; do not repeat that mistake.

const dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(dirname, '../..');

export default defineConfig({
  root,
  resolve: { alias: { '@': path.join(root, 'src') } },
  test: {
    name: 'slice11g-coverage',
    environment: 'jsdom',
    execArgv: ['--no-experimental-webstorage'],
    setupFiles: ['src/test/setup.ts'],
    include: [
      'src/lib/durableDm/__tests__/slice11gFlags.test.ts',
      'src/lib/durableDm/__tests__/migrationMutationIds.test.ts',
      'src/lib/durableDm/__tests__/familyAuthorityNormalizer.test.ts',
      'src/lib/durableDm/__tests__/resumableCloudActivation.test.ts',
      'src/lib/durableDm/__tests__/familyRegistry.test.ts',
      'src/lib/durableDm/__tests__/migrationRunState.test.ts',
      'src/lib/durableDm/__tests__/authorityRepair.test.ts',
      'src/lib/durableDm/adapters/__tests__/*.test.ts',
      'src/lib/__tests__/browserRecoveryRepository.test.ts',
      'src/components/ui/campaign/MigrationWizard/*.test.tsx',
      'src/app/dm/migrate/[code]/__tests__/*.test.tsx',
    ],
    coverage: {
      enabled: true,
      provider: 'v8',
      reporter: ['text', 'json-summary'],
      reportsDirectory: 'coverage/slice11g',
      include: [
        'src/lib/durableDm/slice11gFlags.ts',
        'src/lib/durableDm/migrationMutationIds.ts',
        'src/lib/durableDm/familyAuthorityNormalizer.ts',
        'src/lib/durableDm/resumableCloudActivation.ts',
        'src/lib/durableDm/durableFamilyAdapter.ts',
        'src/lib/durableDm/familyRegistry.ts',
        'src/lib/durableDm/migrationRunState.ts',
        'src/lib/durableDm/authorityRepair.ts',
        'src/lib/durableDm/adapters/*.ts',
      ],
      thresholds: {
        perFile: true,
        statements: 85,
        functions: 85,
        branches: 75,
      },
    },
  },
});
```

Add to `package.json` scripts, immediately after `test:slice11f:coverage`:

```json
"test:slice11g:coverage": "vitest run --config config/vitest/slice11g.config.ts",
```

- [ ] **Step 6: Commit**

```bash
git add src/lib/durableDm/slice11gFlags.ts src/lib/durableDm/__tests__/slice11gFlags.test.ts config/vitest/slice11g.config.ts package.json
git commit -m "feat: add the Slice 11G wizard flag and coverage contract"
```

---

## Task 3: Recovery receipt — verified lookup and entry vector

**Spec:** R4. This is what makes the run resumable across a reload and what lets the wizard name a changed key.

**Files:**
- Modify: `src/lib/browserRecoveryRepository.ts`
- Modify: `src/lib/deviceRecovery.ts` (`RecoveryDownloadReceipt`, `initiateDeviceBackupDownload`)
- Test: `src/lib/__tests__/browserRecoveryRepository.test.ts` (extend)

**Interfaces:**
- Consumes: nothing.
- Produces:
  - `RecoveryDownloadReceipt` gains `entries?: { key: string; byteCount: number; sha256: string }[]`.
  - `BrowserRecoveryRepository.readVerifiedDownloadReceipt(manifestHash: string): Promise<RecoveryDownloadReceipt | null>` — returns `null` for a receipt with no `verifiedAt`.

**Constraints:** additive only. No existing method's behaviour changes, and `DATABASE_VERSION` stays `1` — same object store, same `keyPath: 'manifestHash'`. `initiateDeviceBackupDownload` is shared with the character family (Slice 8), so its suites are part of this task's green bar.

- [ ] **Step 1: Write the failing tests**

Append to `src/lib/__tests__/browserRecoveryRepository.test.ts`:

```ts
describe('readVerifiedDownloadReceipt', () => {
  it('returns null when the receipt was initiated but never verified', async () => {
    const repository = new BrowserRecoveryRepository();
    await repository.recordDownloadReceipt({
      runId: 'run-1',
      manifestHash: 'a'.repeat(64),
      initiatedAt: '2026-08-24T00:00:00.000Z',
    });

    expect(
      await repository.readVerifiedDownloadReceipt('a'.repeat(64))
    ).toBeNull();
  });

  it('returns the receipt, its run id and its entry vector once verified', async () => {
    const repository = new BrowserRecoveryRepository();
    await repository.recordDownloadReceipt({
      runId: 'run-1',
      manifestHash: 'b'.repeat(64),
      initiatedAt: '2026-08-24T00:00:00.000Z',
      entries: [
        { key: 'rollkeeper-dm-data', byteCount: 12, sha256: 'c'.repeat(64) },
      ],
    });
    await repository.verifyDownloadReceipt({
      runId: 'run-1',
      manifestHash: 'b'.repeat(64),
      verifiedAt: '2026-08-24T00:01:00.000Z',
    });

    const receipt = await repository.readVerifiedDownloadReceipt('b'.repeat(64));

    expect(receipt?.runId).toBe('run-1');
    expect(receipt?.entries).toEqual([
      { key: 'rollkeeper-dm-data', byteCount: 12, sha256: 'c'.repeat(64) },
    ]);
  });

  it('returns null for a manifest hash with no receipt at all', async () => {
    const repository = new BrowserRecoveryRepository();
    expect(
      await repository.readVerifiedDownloadReceipt('d'.repeat(64))
    ).toBeNull();
  });
});
```

And in `src/lib/__tests__/deviceRecovery.test.ts` (or the existing download test file — locate it with `grep -rl "initiateDeviceBackupDownload" src/lib/__tests__/`):

```ts
it('records the bundle entry vector on the download receipt', async () => {
  const recorded: RecoveryDownloadReceipt[] = [];
  const bundle = await captureDeviceBackup(storage, {
    appVersion: 'test',
    runId: 'run-1',
    timestamp: '2026-08-24T00:00:00.000Z',
  });

  await initiateDeviceBackupDownload(bundle, {
    recordDownloadReceipt: async receipt => void recorded.push(receipt),
  });

  expect(recorded[0].entries).toEqual(
    bundle.entries.map(({ key, byteCount, sha256 }) => ({
      key,
      byteCount,
      sha256,
    }))
  );
});
```

- [ ] **Step 2: Run them and watch them fail**

Run: `npx vitest run --project unit src/lib/__tests__/browserRecoveryRepository.test.ts src/lib/__tests__/deviceRecovery.test.ts`
Expected: `repository.readVerifiedDownloadReceipt is not a function`, and `expected undefined to equal [ … ]` for the entry vector.

- [ ] **Step 3: Implement**

In `src/lib/deviceRecovery.ts`, extend the receipt type (additive, all existing writers still type-check):

```ts
export interface RecoveryDownloadReceipt {
  runId: string;
  manifestHash: string;
  initiatedAt: string;
  verifiedAt?: string;
  /**
   * The verified bundle's per-entry hashes. Recovery evidence, not wizard
   * state: it is what lets a migration run resumed after a reload name the
   * exact key whose bytes changed, instead of only reporting that the device
   * manifest no longer matches.
   */
  entries?: { key: string; byteCount: number; sha256: string }[];
}
```

and in `initiateDeviceBackupDownload`, pass it through:

```ts
await receipts.recordDownloadReceipt({
  runId: bundle.runId,
  manifestHash: bundle.manifestHash,
  initiatedAt: new Date().toISOString(),
  entries: bundle.entries.map(({ key, byteCount, sha256 }) => ({
    key,
    byteCount,
    sha256,
  })),
});
```

In `src/lib/browserRecoveryRepository.ts`, add the accessor next to `hasVerifiedDownloadReceipt`:

```ts
  async readVerifiedDownloadReceipt(
    manifestHash: string
  ): Promise<RecoveryDownloadReceipt | null> {
    const database = await openDatabase();
    try {
      const transaction = database.transaction(RECEIPTS_STORE, 'readonly');
      const receipt = await requestResult<RecoveryDownloadReceipt | undefined>(
        transaction.objectStore(RECEIPTS_STORE).get(manifestHash)
      );
      await transactionComplete(transaction);
      // An initiated-only receipt is not a receipt a migration run may resume
      // on: the file was never re-selected and checked against the bundle.
      return typeof receipt?.verifiedAt === 'string' ? receipt : null;
    } finally {
      database.close();
    }
  }
```

- [ ] **Step 4: Run them and watch them pass**

Run: `npx vitest run --project unit src/lib/__tests__/browserRecoveryRepository.test.ts src/lib/__tests__/deviceRecovery.test.ts`

- [ ] **Step 5: Mutation-verify the verified-only rule**

Change the return to `return receipt ?? null`, run the suite, confirm `returns null when the receipt was initiated but never verified` goes red, quote the line into the evidence file, restore.

- [ ] **Step 6: Prove nothing else regressed**

Run: `npm run test:slice8:coverage && npm run test:slice9:coverage && npx vitest run --project unit src/lib/`
All green. These cover the character family, the other consumer of `initiateDeviceBackupDownload`.

- [ ] **Step 7: Commit**

```bash
git add src/lib/browserRecoveryRepository.ts src/lib/deviceRecovery.ts src/lib/__tests__/browserRecoveryRepository.test.ts src/lib/__tests__/deviceRecovery.test.ts
git commit -m "feat: record the bundle entry vector and read verified recovery receipts"
```

---

## Task 4: Deterministic cloud mutation IDs

**Spec:** R7. Random mutation IDs cannot satisfy "reload at every step without duplicate staging".

**Files:**
- Create: `src/lib/durableDm/migrationMutationIds.ts`
- Test: `src/lib/durableDm/__tests__/migrationMutationIds.test.ts`

**Interfaces:**
- Produces: `migrationMutationId(input): Promise<string>` where `input` is
  `{ recoveryRunId: string; campaignId: string; family: string; manifestFingerprint: string; expectedEpoch: number; operation: MigrationCloudOperation }`,
  and `MigrationCloudOperation = 'begin-staging' | 'stage-items' | 'confirm-cutover' | 'rollback'`.
  Tasks 6 and 7–12 call it.

**Background:** `private.campaign_document_mutation_receipts` is keyed `(actor_id, mutation_id)` and stores `operation`, `request_hash` and `result`. A repeated call with the same mutation ID replays the stored `result` — but only if `operation` and `request_hash` match, otherwise the RPC raises `22023 mutation ID reuse mismatch`. So the ID must be stable across retries **and** distinct per operation and per epoch.

- [ ] **Step 1: Write the failing test**

```ts
import { describe, expect, it } from 'vitest';

import { migrationMutationId } from '../migrationMutationIds';

const base = {
  recoveryRunId: 'run-1',
  campaignId: '11111111-1111-4111-8111-111111111111',
  family: 'combat_log_archive',
  manifestFingerprint: 'a'.repeat(64),
  expectedEpoch: 0,
};

describe('migrationMutationId', () => {
  it('is stable for the same run, family, manifest, epoch and operation', async () => {
    const first = await migrationMutationId({ ...base, operation: 'begin-staging' });
    const second = await migrationMutationId({ ...base, operation: 'begin-staging' });
    expect(first).toBe(second);
  });

  it('is a syntactically valid UUID', async () => {
    const id = await migrationMutationId({ ...base, operation: 'begin-staging' });
    expect(id).toMatch(
      /^[0-9a-f]{8}-[0-9a-f]{4}-8[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/
    );
  });

  it('differs per operation, so one receipt cannot be replayed for another call', async () => {
    const ids = await Promise.all(
      (['begin-staging', 'stage-items', 'confirm-cutover', 'rollback'] as const).map(
        operation => migrationMutationId({ ...base, operation })
      )
    );
    expect(new Set(ids).size).toBe(4);
  });

  it('differs per epoch, run, campaign, family and manifest', async () => {
    const reference = await migrationMutationId({ ...base, operation: 'begin-staging' });
    const variants = await Promise.all([
      migrationMutationId({ ...base, operation: 'begin-staging', expectedEpoch: 1 }),
      migrationMutationId({ ...base, operation: 'begin-staging', recoveryRunId: 'run-2' }),
      migrationMutationId({
        ...base,
        operation: 'begin-staging',
        campaignId: '22222222-2222-4222-8222-222222222222',
      }),
      migrationMutationId({ ...base, operation: 'begin-staging', family: 'npc' }),
      migrationMutationId({
        ...base,
        operation: 'begin-staging',
        manifestFingerprint: 'b'.repeat(64),
      }),
    ]);
    for (const variant of variants) expect(variant).not.toBe(reference);
  });

  it('cannot be collided by moving a character across a field boundary', async () => {
    const left = await migrationMutationId({
      ...base,
      operation: 'begin-staging',
      recoveryRunId: 'run',
      campaignId: '1' + base.campaignId,
    });
    const right = await migrationMutationId({
      ...base,
      operation: 'begin-staging',
      recoveryRunId: 'run1',
      campaignId: base.campaignId,
    });
    expect(left).not.toBe(right);
  });
});
```

- [ ] **Step 2: Run it and watch it fail**

Run: `npx vitest run --project unit src/lib/durableDm/__tests__/migrationMutationIds.test.ts`
Expected: `Failed to resolve import "../migrationMutationIds"`.

- [ ] **Step 3: Implement**

```ts
export type MigrationCloudOperation =
  | 'begin-staging'
  | 'stage-items'
  | 'confirm-cutover'
  | 'rollback';

const encoder = new TextEncoder();

/**
 * A mutation ID derived from the run rather than generated per attempt.
 *
 * The server keys its mutation receipts on (actor, mutation id) and replays the
 * stored result for a repeat call, so a deterministic ID turns "the response
 * was lost" into "read the receipt again" instead of "start a second staging
 * run". The material is JSON-encoded rather than delimiter-joined, so field
 * boundaries survive any input a future caller passes.
 */
export async function migrationMutationId(input: {
  recoveryRunId: string;
  campaignId: string;
  family: string;
  manifestFingerprint: string;
  expectedEpoch: number;
  operation: MigrationCloudOperation;
}): Promise<string> {
  // JSON, not a delimiter-joined string. Relying on "a space cannot appear in
  // any of these fields" is an assumption about every present and future
  // caller; JSON.stringify escapes and length-delimits each field, so no two
  // distinct inputs can produce the same material regardless.
  const material = JSON.stringify([
    'rollkeeper-migration-mutation-v1',
    input.recoveryRunId,
    input.campaignId,
    input.family,
    input.manifestFingerprint,
    input.expectedEpoch,
    input.operation,
  ]);
  const digest = new Uint8Array(
    await crypto.subtle.digest('SHA-256', encoder.encode(material))
  );
  const bytes = digest.slice(0, 16);
  bytes[6] = (bytes[6] & 0x0f) | 0x80; // RFC 9562 version 8: custom
  bytes[8] = (bytes[8] & 0x3f) | 0x80; // RFC 9562 variant 10
  const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join(
    ''
  );
  return [
    hex.slice(0, 8),
    hex.slice(8, 12),
    hex.slice(12, 16),
    hex.slice(16, 20),
    hex.slice(20),
  ].join('-');
}
```

- [ ] **Step 4: Run it and watch it pass**

Run: `npx vitest run --project unit src/lib/durableDm/__tests__/migrationMutationIds.test.ts`
Expected: 5 passed.

- [ ] **Step 5: Mutation-verify the delimiter and the operation field**

Two mutations, one at a time, each restored afterwards:
1. Replace `JSON.stringify([...])` with `[...].join('')` — expect `cannot be collided by moving a character across a field boundary` to go red.
2. Remove `input.operation` from the material array — expect `differs per operation` to go red.

Quote both failure lines into `SLICE_11G_EVIDENCE.md`.

- [ ] **Step 6: Commit**

```bash
git add src/lib/durableDm/migrationMutationIds.ts src/lib/durableDm/__tests__/migrationMutationIds.test.ts
git commit -m "feat: derive deterministic cloud mutation ids for resumable migration runs"
```

---

## Task 5: Authority normalizer — three key dialects, two value schemas, one `inconsistent`

**Spec:** R5.

**Files:**
- Create: `src/lib/durableDm/familyAuthorityNormalizer.ts`
- Test: `src/lib/durableDm/__tests__/familyAuthorityNormalizer.test.ts`

**Interfaces:**
- Produces `normalizeFamilyAuthority(input): NormalizedAuthority`, plus the exported types `AuthorityMarkerView`, `AuthorityPointerView`, `NormalizedAuthorityState` and `NormalizedAuthority`. Tasks 7–13 call it.

**Background the implementer needs.** Verified against source, the six families group 2 / 3 / 1:

| Families | Marker key | `authority` values | Carries `accountId`? |
|---|---|---|---|
| `campaign_settings`, `calendar` | `rollkeeper:<f>-projection-authority:<code>` | `indexedDB \| postgres \| legacy_restored` | no |
| `magic_item`, `npc`, `encounter_definition` | `rollkeeper:<f>-authority:<code>` | `indexedDB \| postgres \| legacy_restored` | no |
| `combat_log_archive` | `rollkeeper:combat-log-archive-authority:<code>` | `localStorage \| indexedDB \| postgres` | yes, plus `campaignCode` |

Three key and function-name dialects, but only **two** value schemas. Five families never write a plain legacy value at all — they write `legacy_restored` after a rollback and have no marker before their first cutover. Only `combat_log_archive` writes `localStorage`: at epoch 0 before migration, and at a new epoch after a rollback.

The pointer is what `readCampaignSettingsAuthority(database, namespace, campaignId)` and its five siblings return, read under `user:<accountId>`. Because five markers carry no account, **the pointer is what establishes ownership**; the marker never does.

- [ ] **Step 1: Write the failing test**

```ts
import { describe, expect, it } from 'vitest';

import { normalizeFamilyAuthority } from '../familyAuthorityNormalizer';

const scope = { accountId: 'account-1', campaignId: 'campaign-1' };

describe('normalizeFamilyAuthority', () => {
  it('reports legacy when neither a marker nor a routed pointer exists', () => {
    expect(
      normalizeFamilyAuthority({ marker: null, pointer: null, ...scope })
    ).toMatchObject({ state: 'legacy', rolledBack: false });
  });

  it('reports legacy for the combat log dialect before its first cutover', () => {
    expect(
      normalizeFamilyAuthority({
        marker: {
          authority: 'localStorage',
          epoch: 0,
          campaignId: 'campaign-1',
          accountId: 'account-1',
        },
        pointer: { authority: 'localStorage', epoch: 0 },
        ...scope,
      })
    ).toMatchObject({ state: 'legacy', rolledBack: false });
  });

  it('reports a rollback for the legacy_restored dialect', () => {
    expect(
      normalizeFamilyAuthority({
        marker: { authority: 'legacy_restored', epoch: 2, campaignId: 'campaign-1' },
        pointer: { authority: 'localStorage', epoch: 2 },
        ...scope,
      })
    ).toMatchObject({ state: 'legacy', rolledBack: true, epoch: 2 });
  });

  it('reports a rollback for the combat log dialect at a new epoch', () => {
    expect(
      normalizeFamilyAuthority({
        marker: {
          authority: 'localStorage',
          epoch: 2,
          campaignId: 'campaign-1',
          accountId: 'account-1',
        },
        pointer: { authority: 'localStorage', epoch: 2 },
        ...scope,
      })
    ).toMatchObject({ state: 'legacy', rolledBack: true });
  });

  it('blocks a legacy_restored marker at a non-zero epoch with no pointer', () => {
    expect(
      normalizeFamilyAuthority({
        marker: { authority: 'legacy_restored', epoch: 2, campaignId: 'campaign-1' },
        pointer: null,
        ...scope,
      })
    ).toMatchObject({ state: 'inconsistent', reason: 'incomplete-rollback' });
  });

  it('blocks a localStorage pointer at a non-zero epoch with no marker', () => {
    expect(
      normalizeFamilyAuthority({
        marker: null,
        pointer: { authority: 'localStorage', epoch: 2 },
        ...scope,
      })
    ).toMatchObject({ state: 'inconsistent', reason: 'incomplete-rollback' });
  });

  it('preserves the observed marker and pointer on every inconsistency', () => {
    const marker = { authority: 'postgres' as const, epoch: 1, campaignId: 'campaign-1' };
    const pointer = { authority: 'indexedDB' as const, epoch: 1 };
    expect(
      normalizeFamilyAuthority({ marker, pointer, ...scope }).observed
    ).toEqual({ marker, pointer });
  });

  it('normalizes indexedDB and postgres when marker and pointer agree', () => {
    expect(
      normalizeFamilyAuthority({
        marker: { authority: 'indexedDB', epoch: 1, campaignId: 'campaign-1' },
        pointer: { authority: 'indexedDB', epoch: 1 },
        ...scope,
      })
    ).toMatchObject({ state: 'indexedDB', epoch: 1 });
    expect(
      normalizeFamilyAuthority({
        marker: { authority: 'postgres', epoch: 1, campaignId: 'campaign-1' },
        pointer: { authority: 'postgres', epoch: 1 },
        ...scope,
      })
    ).toMatchObject({ state: 'postgres', epoch: 1 });
  });

  it('blocks, rather than choosing, when the marker and the pointer disagree', () => {
    expect(
      normalizeFamilyAuthority({
        marker: { authority: 'postgres', epoch: 1, campaignId: 'campaign-1' },
        pointer: { authority: 'indexedDB', epoch: 1 },
        ...scope,
      })
    ).toMatchObject({
      state: 'inconsistent',
      reason: 'marker-pointer-disagreement',
    });
  });

  it('blocks when a routed marker has no pointer at all', () => {
    expect(
      normalizeFamilyAuthority({
        marker: { authority: 'indexedDB', epoch: 1, campaignId: 'campaign-1' },
        pointer: null,
        ...scope,
      })
    ).toMatchObject({ state: 'inconsistent' });
  });

  it('blocks when the epochs disagree', () => {
    expect(
      normalizeFamilyAuthority({
        marker: { authority: 'postgres', epoch: 2, campaignId: 'campaign-1' },
        pointer: { authority: 'postgres', epoch: 1 },
        ...scope,
      })
    ).toMatchObject({ state: 'inconsistent', reason: 'epoch-disagreement' });
  });

  it('blocks when a marker that carries an account names a different one', () => {
    expect(
      normalizeFamilyAuthority({
        marker: {
          authority: 'postgres',
          epoch: 1,
          campaignId: 'campaign-1',
          accountId: 'account-2',
        },
        pointer: { authority: 'postgres', epoch: 1 },
        ...scope,
      })
    ).toMatchObject({ state: 'inconsistent', reason: 'account-mismatch' });
  });

  it('blocks when the marker names a different campaign', () => {
    expect(
      normalizeFamilyAuthority({
        marker: { authority: 'postgres', epoch: 1, campaignId: 'campaign-9' },
        pointer: { authority: 'postgres', epoch: 1 },
        ...scope,
      })
    ).toMatchObject({ state: 'inconsistent', reason: 'campaign-mismatch' });
  });
});
```

- [ ] **Step 2: Run it and watch it fail**

Run: `npx vitest run --project unit src/lib/durableDm/__tests__/familyAuthorityNormalizer.test.ts`
Expected: `Failed to resolve import "../familyAuthorityNormalizer"`.

- [ ] **Step 3: Implement**

```ts
export interface AuthorityMarkerView {
  authority: 'localStorage' | 'indexedDB' | 'postgres' | 'legacy_restored';
  epoch: number;
  campaignId: string;
  /** Only the combat_log_archive dialect carries one. */
  accountId?: string;
}

export interface AuthorityPointerView {
  authority: 'localStorage' | 'indexedDB' | 'postgres';
  epoch: number;
}

export type NormalizedAuthorityState =
  | 'legacy'
  | 'indexedDB'
  | 'postgres'
  | 'inconsistent';

export interface NormalizedAuthority {
  state: NormalizedAuthorityState;
  epoch: number;
  campaignId: string | null;
  accountId: string | null;
  rolledBack: boolean;
  reason?:
    | 'account-mismatch'
    | 'campaign-mismatch'
    | 'marker-pointer-disagreement'
    | 'epoch-disagreement'
    | 'incomplete-rollback';
  /**
   * The records exactly as they were observed. Task 13b's repair needs to know
   * WHICH side is ahead, and a bare `inconsistent` cannot say. Never used to
   * pick a winner here — only to let an evidence-backed repair decide.
   */
  observed?: {
    marker: AuthorityMarkerView | null;
    pointer: AuthorityPointerView | null;
  };
}

function blocked(
  reason: NonNullable<NormalizedAuthority['reason']>,
  observed: NormalizedAuthority['observed']
): NormalizedAuthority {
  return {
    state: 'inconsistent',
    epoch: 0,
    campaignId: null,
    accountId: null,
    rolledBack: false,
    reason,
    observed,
  };
}

/**
 * Reduces the three marker dialects and the IndexedDB pointer to one shape.
 *
 * A disagreement is never resolved by preferring one source: five of the six
 * markers carry no account, so the pointer — read under `user:<accountId>` — is
 * the only thing that establishes ownership, and a marker that outruns it means
 * a run stopped between two writes. The caller must block that family rather
 * than migrate it a second time or claim it is already migrated.
 */
export function normalizeFamilyAuthority(input: {
  marker: AuthorityMarkerView | null;
  pointer: AuthorityPointerView | null;
  accountId: string;
  campaignId: string;
}): NormalizedAuthority {
  const { marker, pointer, accountId, campaignId } = input;
  const observed = { marker, pointer };

  if (marker) {
    if (marker.accountId !== undefined && marker.accountId !== accountId)
      return blocked('account-mismatch', observed);
    if (marker.campaignId !== campaignId)
      return blocked('campaign-mismatch', observed);
  }

  const markerState = !marker
    ? 'legacy'
    : marker.authority === 'legacy_restored' ||
        marker.authority === 'localStorage'
      ? 'legacy'
      : marker.authority;
  const pointerState = !pointer
    ? 'legacy'
    : pointer.authority === 'localStorage'
      ? 'legacy'
      : pointer.authority;

  if (markerState !== pointerState)
    return blocked('marker-pointer-disagreement', observed);
  if (marker && pointer && marker.epoch !== pointer.epoch)
    return blocked('epoch-disagreement', observed);

  const epoch = marker?.epoch ?? pointer?.epoch ?? 0;

  // Both records agree that the family is legacy, but only one of them exists
  // at an epoch above zero. That is a rollback that got half-written, not a
  // family that was never migrated: at epoch > 0 a legacy state requires both
  // records to say so. Accepting it would re-migrate over a half-rolled-back
  // family.
  if (markerState === 'legacy' && epoch > 0 && (!marker || !pointer))
    return blocked('incomplete-rollback', observed);

  return {
    state: markerState,
    epoch,
    campaignId: marker?.campaignId ?? (pointer ? campaignId : null),
    accountId: marker?.accountId ?? (pointer ? accountId : null),
    // `legacy_restored` is the five-family dialect for "rolled back"; the
    // combat log dialect says it by returning to localStorage at a new epoch.
    rolledBack: markerState === 'legacy' && epoch > 0,
  };
}
```

- [ ] **Step 4: Run it and watch it pass**

Run: `npx vitest run --project unit src/lib/durableDm/__tests__/familyAuthorityNormalizer.test.ts`
Expected: 14 passed.

- [ ] **Step 5: Mutation-verify every guard**

One at a time, restoring after each; quote each failure line into the evidence file:
1. Replace the `markerState !== pointerState` branch with `return { state: markerState, epoch: marker?.epoch ?? 0, campaignId, accountId, rolledBack: false }` — expect `blocks, rather than choosing, when the marker and the pointer disagree` to go red.
2. Delete the `marker.accountId !== undefined && …` clause — expect `blocks when a marker that carries an account names a different one` to go red.
3. Replace `rolledBack` with the constant `false` — expect both rollback tests to go red.
4. Delete the `incomplete-rollback` branch — expect both unilateral-rollback tests to go red.
5. Drop `observed` from `blocked` — expect `preserves the observed marker and pointer on every inconsistency` to go red, and note that Task 13b's repair cannot function without it.

- [ ] **Step 6: Commit**

```bash
git add src/lib/durableDm/familyAuthorityNormalizer.ts src/lib/durableDm/__tests__/familyAuthorityNormalizer.test.ts
git commit -m "feat: normalize the durable family authority dialects and block on disagreement"
```

---

## Task 6: Response-loss-safe cloud activation protocol

**Spec:** R7. This is the highest-risk unit in the slice. Every adapter's `activateCloud` delegates to it.

**Files:**
- Create: `src/lib/durableDm/resumableCloudActivation.ts`
- Test: `src/lib/durableDm/__tests__/resumableCloudActivation.test.ts`

**Interfaces:**
- Consumes: `migrationMutationId` and `MigrationCloudOperation` from Task 4.
- Produces:
```ts
export interface CloudEnrollmentPreview {
  authority: 'legacy' | 'postgres';
  epoch?: number;
  previewFingerprint?: string;
  recordCount?: number;
  documents?: {
    legacyId: string;
    serverVersion: number;
    schemaVersion: number;
    payloadFingerprint: string;
    tombstoned: boolean;
  }[];
}

export interface ActivationManifestRecord {
  legacyId: string;
  schemaVersion: number;
  payloadFingerprint: string;
  tombstoned: boolean;
}

/**
 * Every field the server folds into its `request_hash` travels through these
 * signatures. A deterministic mutation id only replays a receipt when the
 * request hashes to the same value, so a retry that quietly changed one of
 * these raises `22023` instead — and the protocol must be able to see them to
 * keep them stable. Verified inputs:
 *
 *   begin_staging   {campaignId, deviceId, epoch, manifest, recovery, count, bytes}
 *   stage_items     {runId, items}
 *   confirm_cutover {runId, manifest, epoch}
 *
 * Note that `family` is NOT part of any of them, despite appearing in the RPC
 * names; the mutation id already separates families.
 */
export interface ResumableActivationGateway {
  previewEnrollment(): Promise<CloudEnrollmentPreview>;
  beginStaging(input: {
    mutationId: string;
    expectedEpoch: number;
    deviceId: string;
    manifestFingerprint: string;
    recoveryManifestHash: string;
    recordCount: number;
    totalBytes: number;
  }): Promise<{ runId: string }>;
  stageItems(input: {
    mutationId: string;
    runId: string;
    items: readonly unknown[];
  }): Promise<unknown>;
  confirmCutover(input: {
    mutationId: string;
    runId: string;
    manifestFingerprint: string;
    expectedEpoch: number;
  }): Promise<{ epoch: number }>;
}

export type ResumableActivationResult =
  | {
      status: 'activated' | 'reconciled';
      epoch: number;
      acceptedVersions: {
        legacyId: string;
        serverVersion: number;
        schemaVersion: number;
        payloadFingerprint: string;
      }[];
    }
  | {
      status: 'conflict';
      reason:
        | 'cloud-generation-diverged'
        | 'cloud-epoch-unknown'
        | 'cloud-epoch-unexpected'
        | 'cloud-preview-unusable';
    };

export async function runResumableCloudActivation(input: {
  gateway: ResumableActivationGateway;
  /**
   * Re-reads the IndexedDB working copy and throws if it no longer matches the
   * manifest. Injected, because only the adapter knows its own repository.
   */
  assertWorkingCopyUnchanged: () => Promise<void>;
  family: string;
  recoveryRunId: string;
  campaignId: string;
  manifestFingerprint: string;
  records: readonly ActivationManifestRecord[];
  expectedEpoch: number;
  /**
   * The rest of the hashed request bodies. `deviceId` MUST come from the
   * persisted `rollkeeper:<family>-device:*` key, never a fresh UUID: it is
   * hashed into begin_staging, so a regenerated id turns a legitimate retry
   * into `22023 mutation ID was already used with different input` and strands
   * the run.
   */
  request: {
    deviceId: string;
    recoveryManifestHash: string;
    recordCount: number;
    totalBytes: number;
    items: readonly unknown[];
  };
}): Promise<ResumableActivationResult>;
```
Tasks 7–12 call `runResumableCloudActivation`, then pass the result's `acceptedVersions` and `epoch` into their own `mark*CloudAuthority` and write their own localStorage marker. This module owns the server protocol only; the adapter owns the local half.

**`assertWorkingCopyUnchanged` is called at three points**, matching what the shipped cards do and extending it to the path they do not have:

1. before `begin-staging` — do not upload a generation the device has already moved past;
2. after `stage-items` and immediately before `confirm-cutover` — the DM may have edited while the upload was in flight, and only an unchanged working copy may become authoritative;
3. before reconciling a Postgres preview — an interrupted run whose device has since been edited must not silently adopt the cloud generation as if it still matched.

**Background the implementer needs.** The shipped chain is `begin-staging` → `stage-items` → `confirm-cutover`, each an RPC through the family's existing API route, each writing a mutation receipt keyed `(actor_id, mutation_id)`. A repeat call replays the stored result if `operation` and `request_hash` match, and otherwise raises `22023` (worded `mutation ID was already used with different input` by some families and `mutation ID reuse mismatch` by others — match on `/mutation ID/`).

The `request_hash` inputs, verified against `20260821000000_create_campaign_documents.sql`:

| Operation | Hashed inputs | Line |
|---|---|---|
| `begin-staging` | `{campaignId, deviceId, epoch, manifest, recovery, count, bytes}` | :281 |
| `stage-items` | `{runId, items}` | :304 |
| `confirm-cutover` | `{runId, manifest, epoch}` | :355 |

`family` is in **none** of them, despite appearing in the RPC names — the mutation id already separates families. Two consequences the implementation must honour: **a retry must reuse the replayed `runId`, never a fresh one**, and **`deviceId` must come from the persisted `rollkeeper:<family>-device:*` key**, because both are hashed and a change to either turns a legitimate retry into a rejection.

`expectedEpoch` is what the shipped cards pass as `Math.max(0, authority.epoch - 1)` — the epoch the server is expected to still hold, not the local one. The adapter computes it; this module takes it as given.

Two interruption classes, distinguished by `preview-enrollment` (read-only):

1. **Server authority still `legacy`** — confirm never committed. Re-run the three calls with deterministic IDs; `begin-staging` replays its original `runId`.
2. **Server authority already `postgres`** — confirm committed and its response was lost. Starting another staging run is forbidden. Compare the preview's documents against the manifest: exact parity means reconcile the local pointer only; any divergence is a conflict.

- [ ] **Step 1: Write the failing test**

```ts
import { describe, expect, it, vi } from 'vitest';

import {
  runResumableCloudActivation,
  type CloudEnrollmentPreview,
  type ResumableActivationGateway,
} from '../resumableCloudActivation';

const records = [
  { legacyId: 'one', schemaVersion: 2, payloadFingerprint: 'a'.repeat(64), tombstoned: false },
  { legacyId: 'two', schemaVersion: 2, payloadFingerprint: 'b'.repeat(64), tombstoned: true },
];

const fakeOptions = {
  campaignId: '11111111-1111-4111-8111-111111111111',
  manifestFingerprint: 'c'.repeat(64),
  records,
};

/** The begin-staging body the adapter would send; reused so retries hash equal. */
const beginInput = {
  mutationId: 'begin-id',
  expectedEpoch: 0,
  deviceId: 'device-1',
  manifestFingerprint: 'c'.repeat(64),
  recoveryManifestHash: 'r'.repeat(64),
  recordCount: records.length,
  totalBytes: 128,
};

const base = {
  assertWorkingCopyUnchanged: async () => {},
  request: {
    deviceId: 'device-1',
    recoveryManifestHash: 'r'.repeat(64),
    recordCount: records.length,
    totalBytes: 128,
    items: records,
  },
  family: 'combat_log_archive',
  recoveryRunId: 'run-1',
  campaignId: '11111111-1111-4111-8111-111111111111',
  manifestFingerprint: 'c'.repeat(64),
  records,
  expectedEpoch: 0,
};

function gateway(overrides: Partial<ResumableActivationGateway> = {}) {
  return {
    previewEnrollment: vi.fn(async () => ({ authority: 'legacy' }) as CloudEnrollmentPreview),
    beginStaging: vi.fn(async (_input: unknown) => ({ runId: 'server-run-1' })),
    stageItems: vi.fn(async (_input: unknown) => ({})),
    confirmCutover: vi.fn(async (_input: unknown) => ({ epoch: 1 })),
    ...overrides,
  };
}

function postgresPreview(): CloudEnrollmentPreview {
  return {
    authority: 'postgres',
    epoch: 1,
    previewFingerprint: 'c'.repeat(64),
    recordCount: 2,
    documents: [
      { legacyId: 'one', serverVersion: 1, schemaVersion: 2, payloadFingerprint: 'a'.repeat(64), tombstoned: false },
      { legacyId: 'two', serverVersion: 1, schemaVersion: 2, payloadFingerprint: 'b'.repeat(64), tombstoned: true },
    ],
  };
}

describe('runResumableCloudActivation', () => {
  it('stages and confirms when the server is still legacy', async () => {
    const cloud = gateway();

    const result = await runResumableCloudActivation({ ...base, gateway: cloud });

    expect(result).toMatchObject({ status: 'activated', epoch: 1 });
    expect(cloud.beginStaging).toHaveBeenCalledTimes(1);
    expect(cloud.stageItems).toHaveBeenCalledWith(
      expect.objectContaining({ runId: 'server-run-1' })
    );
    expect(cloud.confirmCutover).toHaveBeenCalledWith(
      expect.objectContaining({ runId: 'server-run-1', expectedEpoch: 0 })
    );
  });

  it('uses the same mutation ids on a repeated run, so the server replays its receipts', async () => {
    const first = gateway();
    const second = gateway();

    await runResumableCloudActivation({ ...base, gateway: first });
    await runResumableCloudActivation({ ...base, gateway: second });

    expect(second.beginStaging.mock.calls[0][0].mutationId).toBe(
      first.beginStaging.mock.calls[0][0].mutationId
    );
    expect(second.stageItems.mock.calls[0][0].mutationId).toBe(
      first.stageItems.mock.calls[0][0].mutationId
    );
    expect(second.confirmCutover.mock.calls[0][0].mutationId).toBe(
      first.confirmCutover.mock.calls[0][0].mutationId
    );
  });

  it('gives each call a distinct mutation id', async () => {
    const cloud = gateway();
    await runResumableCloudActivation({ ...base, gateway: cloud });
    const ids = new Set([
      cloud.beginStaging.mock.calls[0][0].mutationId,
      cloud.stageItems.mock.calls[0][0].mutationId,
      cloud.confirmCutover.mock.calls[0][0].mutationId,
    ]);
    expect(ids.size).toBe(3);
  });

  it('reconciles without staging again when confirm already committed', async () => {
    const cloud = gateway({
      previewEnrollment: vi.fn(async () => postgresPreview()),
    });

    const result = await runResumableCloudActivation({ ...base, gateway: cloud });

    expect(result).toMatchObject({
      status: 'reconciled',
      epoch: 1,
      acceptedVersions: [
        { legacyId: 'one', serverVersion: 1, payloadFingerprint: 'a'.repeat(64) },
        { legacyId: 'two', serverVersion: 1, payloadFingerprint: 'b'.repeat(64) },
      ],
    });
    expect(cloud.beginStaging).not.toHaveBeenCalled();
    expect(cloud.stageItems).not.toHaveBeenCalled();
    expect(cloud.confirmCutover).not.toHaveBeenCalled();
  });

  it('conflicts, and never stages, when the cloud generation has diverged', async () => {
    const diverged = postgresPreview();
    diverged.documents![1].payloadFingerprint = 'f'.repeat(64);
    const cloud = gateway({ previewEnrollment: vi.fn(async () => diverged) });

    const result = await runResumableCloudActivation({ ...base, gateway: cloud });

    expect(result).toEqual({ status: 'conflict', reason: 'cloud-generation-diverged' });
    expect(cloud.beginStaging).not.toHaveBeenCalled();
  });

  it('conflicts when the cloud holds a different document set', async () => {
    const extra = postgresPreview();
    extra.documents!.push({
      legacyId: 'three',
      serverVersion: 1,
      schemaVersion: 2,
      payloadFingerprint: 'e'.repeat(64),
      tombstoned: false,
    });
    extra.recordCount = 3;
    const cloud = gateway({ previewEnrollment: vi.fn(async () => extra) });

    expect(
      await runResumableCloudActivation({ ...base, gateway: cloud })
    ).toEqual({ status: 'conflict', reason: 'cloud-generation-diverged' });
  });

  it('conflicts when a tombstone flag disagrees', async () => {
    const flipped = postgresPreview();
    flipped.documents![1].tombstoned = false;
    const cloud = gateway({ previewEnrollment: vi.fn(async () => flipped) });

    expect(
      await runResumableCloudActivation({ ...base, gateway: cloud })
    ).toEqual({ status: 'conflict', reason: 'cloud-generation-diverged' });
  });

  it('refuses to reconcile a postgres preview that reports no epoch', async () => {
    const noEpoch = postgresPreview();
    delete noEpoch.epoch;
    const cloud = gateway({ previewEnrollment: vi.fn(async () => noEpoch) });

    expect(
      await runResumableCloudActivation({ ...base, gateway: cloud })
    ).toEqual({ status: 'conflict', reason: 'cloud-epoch-unknown' });
  });

  it('checks the working copy before staging and again before confirming', async () => {
    const seen: string[] = [];
    const assertWorkingCopyUnchanged = vi.fn(async () => void seen.push('check'));
    const cloud = gateway({
      beginStaging: vi.fn(async () => {
        seen.push('begin');
        return { runId: 'server-run-1' };
      }),
      stageItems: vi.fn(async () => void seen.push('stage')),
      confirmCutover: vi.fn(async () => {
        seen.push('confirm');
        return { epoch: 1 };
      }),
    });

    await runResumableCloudActivation({ ...base, gateway: cloud, assertWorkingCopyUnchanged });

    expect(seen).toEqual(['check', 'begin', 'stage', 'check', 'confirm']);
  });

  it('refuses to confirm when the working copy changed during the upload', async () => {
    let calls = 0;
    const cloud = gateway();

    await expect(
      runResumableCloudActivation({
        ...base,
        gateway: cloud,
        assertWorkingCopyUnchanged: vi.fn(async () => {
          calls += 1;
          if (calls > 1) throw new Error('changed since the last check');
        }),
      })
    ).rejects.toThrow('changed since the last check');
    expect(cloud.confirmCutover).not.toHaveBeenCalled();
  });

  it('checks the working copy before reconciling an already-committed generation', async () => {
    const cloud = gateway({ previewEnrollment: vi.fn(async () => postgresPreview()) });

    await expect(
      runResumableCloudActivation({
        ...base,
        gateway: cloud,
        assertWorkingCopyUnchanged: vi.fn(async () => {
          throw new Error('changed since the last check');
        }),
      })
    ).rejects.toThrow('changed since the last check');
  });

  it('conflicts when only the schema version differs', async () => {
    const bumped = postgresPreview();
    bumped.documents![0].schemaVersion = 3;
    const cloud = gateway({ previewEnrollment: vi.fn(async () => bumped) });

    expect(
      await runResumableCloudActivation({ ...base, gateway: cloud })
    ).toEqual({ status: 'conflict', reason: 'cloud-generation-diverged' });
  });

  it('conflicts when the cloud sits at an epoch this run was not activating into', async () => {
    const ahead = postgresPreview();
    ahead.epoch = 4;
    const cloud = gateway({ previewEnrollment: vi.fn(async () => ahead) });

    expect(
      await runResumableCloudActivation({ ...base, gateway: cloud })
    ).toEqual({ status: 'conflict', reason: 'cloud-epoch-unexpected' });
    expect(cloud.beginStaging).not.toHaveBeenCalled();
  });

  it('conflicts when the preview carries no usable fingerprint', async () => {
    const blank = postgresPreview();
    delete blank.previewFingerprint;
    const cloud = gateway({ previewEnrollment: vi.fn(async () => blank) });

    expect(
      await runResumableCloudActivation({ ...base, gateway: cloud })
    ).toEqual({ status: 'conflict', reason: 'cloud-preview-unusable' });
  });

  // The interruption matrix. Each case kills the run at one point, then re-runs
  // the whole activation against a server that kept whatever had committed.
  //
  // Declared above `describe` in the test file, not inside it.

  describe('resumes correctly from an interruption at every point', () => {
    it('before begin-staging: stages once and activates', async () => {
      const server = fakeServer(fakeOptions);
      await expect(
        runResumableCloudActivation({ ...base, gateway: server.failingAt('begin-staging') })
      ).rejects.toThrow();
      const result = await runResumableCloudActivation({ ...base, gateway: server.gateway() });
      expect(result).toMatchObject({ status: 'activated', epoch: 1 });
      expect(server.stagingRunCount()).toBe(1);
    });

    it('after begin-staging, before stage-items: replays the same server run id', async () => {
      const server = fakeServer(fakeOptions);
      await expect(
        runResumableCloudActivation({ ...base, gateway: server.failingAt('stage-items') })
      ).rejects.toThrow();
      const result = await runResumableCloudActivation({ ...base, gateway: server.gateway() });
      expect(result).toMatchObject({ status: 'activated' });
      expect(server.stagingRunCount()).toBe(1);
      expect(new Set(server.runIdsSeen()).size).toBe(1);
    });

    it('after stage-items, before confirm: confirms without re-staging a new run', async () => {
      const server = fakeServer(fakeOptions);
      await expect(
        runResumableCloudActivation({ ...base, gateway: server.failingAt('confirm-cutover') })
      ).rejects.toThrow();
      const result = await runResumableCloudActivation({ ...base, gateway: server.gateway() });
      expect(result).toMatchObject({ status: 'activated', epoch: 1 });
      expect(server.stagingRunCount()).toBe(1);
    });

    it('after confirm committed but its response was lost: reconciles, never stages again', async () => {
      const server = fakeServer(fakeOptions);
      await expect(
        runResumableCloudActivation({ ...base, gateway: server.losingConfirmResponse() })
      ).rejects.toThrow();
      const result = await runResumableCloudActivation({ ...base, gateway: server.gateway() });
      expect(result).toMatchObject({ status: 'reconciled', epoch: 1 });
      expect(server.stagingRunCount()).toBe(1);
    });
  });

  it('propagates a staging failure without confirming', async () => {
    const cloud = gateway({
      stageItems: vi.fn(async () => {
        throw new Error('cloud unavailable');
      }),
    });

    await expect(
      runResumableCloudActivation({ ...base, gateway: cloud })
    ).rejects.toThrow('cloud unavailable');
    expect(cloud.confirmCutover).not.toHaveBeenCalled();
  });
});
```

- [ ] **Step 1b: Write the fake server the interruption matrix runs against**

It must mirror the server's receipt semantics, not just memoize by mutation id. `private.campaign_document_mutation_receipts` validates `operation` **and** `request_hash` before replaying, and raises `22023 mutation ID reuse mismatch` otherwise. A fake that replays on the mutation id alone would let a retry carrying a fresh `runId` succeed here and fail against the real RPC — on exactly the highest-risk path this task exists to prove.

```ts
type FakeOperation = 'begin-staging' | 'stage-items' | 'confirm-cutover';
type FakeRunState = 'staging' | 'validated' | 'finalized';

interface FakeReceipt {
  operation: FakeOperation;
  signature: string;
  result: unknown;
}

/**
 * A model of the server's receipt and staging-run semantics, verified against
 * `20260821000000_create_campaign_documents.sql`.
 *
 * The signatures below are the REAL `request_hash` inputs, field for field:
 *
 *   begin_staging   {campaignId, deviceId, epoch, manifest, recovery, count, bytes}   (:281)
 *   stage_items     {runId, items}                                                    (:304)
 *   confirm_cutover {runId, manifest, epoch}                                          (:355)
 *
 * `family` is in none of them. Getting this wrong in the fake would let a retry
 * that changed `deviceId`, the recovery hash, the counts or the item bodies pass
 * here and fail against the real RPC — on the exact path these tests exist for.
 *
 * Runs move staging -> validated -> finalized (:74). `stage_items` accepts
 * staging or validated and sets validated (:308, :324); `confirm_cutover`
 * requires validated and sets finalized (:359, :395). A confirm against a run
 * that was only begun must fail.
 */
function fakeServer(options: {
  campaignId: string;
  manifestFingerprint: string;
  records: readonly ActivationManifestRecord[];
}) {
  const receipts = new Map<string, FakeReceipt>();
  const runs = new Map<string, FakeRunState>();
  const runIdsSeen: string[] = [];
  let authority: 'legacy' | 'postgres' = 'legacy';
  let epoch = 0;

  // The per-family RPCs word this differently — campaign_settings raises
  // "mutation ID was already used with different input", combat_log_archive
  // raises "mutation ID reuse mismatch" — so tests match on /mutation ID/,
  // never on the whole string.
  function replay<T>(
    mutationId: string,
    operation: FakeOperation,
    signature: string,
    produce: () => T
  ): T {
    const existing = receipts.get(mutationId);
    if (existing) {
      if (existing.operation !== operation || existing.signature !== signature)
        throw new Error('mutation ID was already used with different input');
      return existing.result as T;
    }
    const result = produce();
    receipts.set(mutationId, { operation, signature, result });
    return result;
  }

  const base: ResumableActivationGateway = {
    previewEnrollment: async () =>
      authority === 'legacy'
        ? { authority: 'legacy' }
        : {
            authority: 'postgres',
            epoch,
            previewFingerprint: 'p'.repeat(64),
            recordCount: options.records.length,
            documents: options.records.map(record => ({
              legacyId: record.legacyId,
              serverVersion: 1,
              schemaVersion: record.schemaVersion,
              payloadFingerprint: record.payloadFingerprint,
              tombstoned: record.tombstoned,
            })),
          },

    beginStaging: async input =>
      replay(
        input.mutationId,
        'begin-staging',
        JSON.stringify({
          campaignId: options.campaignId,
          deviceId: input.deviceId,
          epoch: input.expectedEpoch,
          manifest: input.manifestFingerprint,
          recovery: input.recoveryManifestHash,
          count: input.recordCount,
          bytes: input.totalBytes,
        }),
        () => {
          const runId = `server-run-${runs.size + 1}`;
          runs.set(runId, 'staging');
          return { runId };
        }
      ),

    stageItems: async input => {
      runIdsSeen.push(input.runId);
      return replay(
        input.mutationId,
        'stage-items',
        JSON.stringify({ runId: input.runId, items: input.items }),
        () => {
          const state = runs.get(input.runId);
          if (state !== 'staging' && state !== 'validated')
            throw new Error('staging run is unavailable');
          runs.set(input.runId, 'validated');
          return {};
        }
      );
    },

    confirmCutover: async input => {
      runIdsSeen.push(input.runId);
      return replay(
        input.mutationId,
        'confirm-cutover',
        JSON.stringify({
          runId: input.runId,
          manifest: input.manifestFingerprint,
          epoch: input.expectedEpoch,
        }),
        () => {
          if (runs.get(input.runId) !== 'validated')
            throw new Error('validated staging run required');
          runs.set(input.runId, 'finalized');
          authority = 'postgres';
          epoch = input.expectedEpoch + 1;
          return { epoch };
        }
      );
    },
  };

  const methodFor: Record<FakeOperation, keyof ResumableActivationGateway> = {
    'begin-staging': 'beginStaging',
    'stage-items': 'stageItems',
    'confirm-cutover': 'confirmCutover',
  };

  return {
    gateway: () => base,
    /** Rejects at `step`, having performed every earlier step for real. */
    failingAt: (step: FakeOperation): ResumableActivationGateway => ({
      ...base,
      [methodFor[step]]: async () => {
        throw new Error(`interrupted at ${step}`);
      },
    }),
    /** Commits the confirm, then throws — the lost-response case. */
    losingConfirmResponse: (): ResumableActivationGateway => ({
      ...base,
      confirmCutover: async input => {
        await base.confirmCutover(input);
        throw new Error('response lost');
      },
    }),
    stagingRunCount: () => runs.size,
    runState: (runId: string) => runs.get(runId),
    runIdsSeen: () => runIdsSeen,
  };
}
```

Construct it as `fakeServer({ campaignId: base.campaignId, manifestFingerprint: base.manifestFingerprint, records })`, so the fixture's own values are the ones hashed.

Four tests for the fake itself, so it cannot silently stop enforcing what it exists to enforce:

```ts
it('the fake rejects a replay that reuses a mutation id for another operation', async () => {
  const server = fakeServer(fakeOptions);
  const gateway = server.gateway();
  await gateway.beginStaging({ ...beginInput, mutationId: 'shared-id' });
  await expect(
    gateway.stageItems({ mutationId: 'shared-id', runId: 'server-run-1', items: [] })
  ).rejects.toThrow(/mutation ID/);
});

it('the fake rejects a replay whose request body changed', async () => {
  const server = fakeServer(fakeOptions);
  const gateway = server.gateway();
  await gateway.beginStaging({ ...beginInput, mutationId: 'begin-id' });
  // A regenerated device id is the realistic way this happens.
  await expect(
    gateway.beginStaging({ ...beginInput, mutationId: 'begin-id', deviceId: 'other-device' })
  ).rejects.toThrow(/mutation ID/);
});

it('the fake rejects a replay that reuses a mutation id with a different run id', async () => {
  const server = fakeServer(fakeOptions);
  const gateway = server.gateway();
  await gateway.beginStaging({ ...beginInput, mutationId: 'begin-id' });
  await gateway.stageItems({ mutationId: 'stage-id', runId: 'server-run-1', items: [] });
  await expect(
    gateway.stageItems({ mutationId: 'stage-id', runId: 'server-run-2', items: [] })
  ).rejects.toThrow(/mutation ID/);
});

it('the fake refuses to confirm a run that never reached validated', async () => {
  const server = fakeServer(fakeOptions);
  const gateway = server.gateway();
  const { runId } = await gateway.beginStaging({ ...beginInput, mutationId: 'begin-id' });
  expect(server.runState(runId)).toBe('staging');
  await expect(
    gateway.confirmCutover({
      mutationId: 'confirm-id',
      runId,
      manifestFingerprint: base.manifestFingerprint,
      expectedEpoch: 0,
    })
  ).rejects.toThrow('validated staging run required');
});
```

- [ ] **Step 2: Run it and watch it fail**

Run: `npx vitest run --project unit src/lib/durableDm/__tests__/resumableCloudActivation.test.ts`
Expected: `Failed to resolve import "../resumableCloudActivation"`.

- [ ] **Step 3: Implement**

```ts
import { migrationMutationId } from './migrationMutationIds';

export interface CloudEnrollmentPreview {
  authority: 'legacy' | 'postgres';
  epoch?: number;
  previewFingerprint?: string;
  recordCount?: number;
  documents?: {
    legacyId: string;
    serverVersion: number;
    schemaVersion: number;
    payloadFingerprint: string;
    tombstoned: boolean;
  }[];
}

export interface ActivationManifestRecord {
  legacyId: string;
  schemaVersion: number;
  payloadFingerprint: string;
  tombstoned: boolean;
}

export interface ResumableActivationGateway {
  previewEnrollment(): Promise<CloudEnrollmentPreview>;
  beginStaging(input: {
    mutationId: string;
    expectedEpoch: number;
    deviceId: string;
    manifestFingerprint: string;
    recoveryManifestHash: string;
    recordCount: number;
    totalBytes: number;
  }): Promise<{ runId: string }>;
  stageItems(input: {
    mutationId: string;
    runId: string;
    items: readonly unknown[];
  }): Promise<unknown>;
  confirmCutover(input: {
    mutationId: string;
    runId: string;
    manifestFingerprint: string;
    expectedEpoch: number;
  }): Promise<{ epoch: number }>;
}

export type ResumableActivationResult =
  | {
      status: 'activated' | 'reconciled';
      epoch: number;
      acceptedVersions: {
        legacyId: string;
        serverVersion: number;
        schemaVersion: number;
        payloadFingerprint: string;
      }[];
    }
  | {
      status: 'conflict';
      reason:
        | 'cloud-generation-diverged'
        | 'cloud-epoch-unknown'
        | 'cloud-epoch-unexpected'
        | 'cloud-preview-unusable';
    };

/**
 * True only when the cloud generation is exactly the generation this run would
 * have uploaded: same legacy ids, same fingerprints, same tombstone flags, same
 * count. Anything else means the account holds work this device did not produce,
 * and reconciling the local pointer to it would silently adopt it.
 */
function matchesManifest(
  preview: CloudEnrollmentPreview,
  records: readonly ActivationManifestRecord[]
): boolean {
  const documents = preview.documents ?? [];
  if (preview.recordCount !== records.length) return false;
  if (documents.length !== records.length) return false;
  const cloud = new Map(documents.map(document => [document.legacyId, document]));
  return records.every(record => {
    const document = cloud.get(record.legacyId);
    return (
      document !== undefined &&
      document.payloadFingerprint === record.payloadFingerprint &&
      // The payload fingerprint does not cover the schema version: the same
      // bytes under a different schema version are a different document, and
      // adopting one as "already matching" would pin the device to a
      // generation it cannot correctly hydrate.
      document.schemaVersion === record.schemaVersion &&
      document.tombstoned === record.tombstoned
    );
  });
}

/**
 * Stages and activates a family in the cloud in a way that survives a lost
 * response.
 *
 * The mutation ids are derived from the run rather than generated per attempt,
 * so a repeat call replays the server's mutation receipt instead of opening a
 * second staging run — and the run id must come from that replayed receipt,
 * because the server hashes it into the request hash of both later calls.
 *
 * `preview-enrollment` runs first and is read-only. It is the only way to tell
 * "confirm never committed" from "confirm committed and the response was lost":
 * in the first case the whole chain is safe to repeat, and in the second case
 * beginning another staging run is forbidden.
 */
export async function runResumableCloudActivation(input: {
  gateway: ResumableActivationGateway;
  assertWorkingCopyUnchanged: () => Promise<void>;
  family: string;
  recoveryRunId: string;
  campaignId: string;
  manifestFingerprint: string;
  records: readonly ActivationManifestRecord[];
  expectedEpoch: number;
  request: {
    deviceId: string;
    recoveryManifestHash: string;
    recordCount: number;
    totalBytes: number;
    items: readonly unknown[];
  };
}): Promise<ResumableActivationResult> {
  const { gateway, records, expectedEpoch, request } = input;
  const idFor = (operation: 'begin-staging' | 'stage-items' | 'confirm-cutover') =>
    migrationMutationId({
      recoveryRunId: input.recoveryRunId,
      campaignId: input.campaignId,
      family: input.family,
      manifestFingerprint: input.manifestFingerprint,
      expectedEpoch,
      operation,
    });

  const preview = await gateway.previewEnrollment();

  if (preview.authority === 'postgres') {
    // Checked before reconciling, not only before staging: the interruption
    // that stranded this run may have been followed by local edits, and
    // adopting the cloud generation then would discard them silently.
    await input.assertWorkingCopyUnchanged();
    if (!matchesManifest(preview, records))
      return { status: 'conflict', reason: 'cloud-generation-diverged' };
    if (typeof preview.epoch !== 'number')
      return { status: 'conflict', reason: 'cloud-epoch-unknown' };
    // The epoch this run was activating INTO is `expectedEpoch + 1`. A preview
    // at any other epoch is somebody else's cutover, not this run's lost
    // response, and reconciling to it would adopt another device's generation.
    if (preview.epoch !== expectedEpoch + 1)
      return { status: 'conflict', reason: 'cloud-epoch-unexpected' };
    // `previewFingerprint` is deliberately NOT compared against
    // `manifestFingerprint`: they are different hashes over different inputs.
    // `previewFingerprint` is `private.campaign_document_hash` over the cloud
    // document's fields, while `manifestFingerprint` is `build*Manifest`'s hash
    // over the legacy envelope. Recomputing the server's hash on the client
    // would duplicate a server semantic this slice is forbidden to add, so
    // parity is established by the per-document comparison above plus the epoch
    // check — both exact.
    //
    // Its presence is required and nothing more. It is deliberately NOT
    // returned or cached: rollback fetches its own fresh `preview-enrollment`
    // and passes that response's fingerprint, exactly as the shipped cards do,
    // and an activation-time value would be stale by then.
    if (typeof preview.previewFingerprint !== 'string' || !preview.previewFingerprint)
      return { status: 'conflict', reason: 'cloud-preview-unusable' };
    return {
      status: 'reconciled',
      epoch: preview.epoch,
      acceptedVersions: (preview.documents ?? []).map(document => ({
        legacyId: document.legacyId,
        serverVersion: document.serverVersion,
        schemaVersion: document.schemaVersion,
        payloadFingerprint: document.payloadFingerprint,
      })),
    };
  }

  await input.assertWorkingCopyUnchanged();
  const begun = await gateway.beginStaging({
    mutationId: await idFor('begin-staging'),
    expectedEpoch,
    deviceId: request.deviceId,
    manifestFingerprint: input.manifestFingerprint,
    recoveryManifestHash: request.recoveryManifestHash,
    recordCount: request.recordCount,
    totalBytes: request.totalBytes,
  });
  await gateway.stageItems({
    mutationId: await idFor('stage-items'),
    runId: begun.runId,
    items: request.items,
  });
  // Re-checked after staging: the DM may have logged another change while the
  // upload was in flight, and only an unchanged working copy may be confirmed.
  await input.assertWorkingCopyUnchanged();
  const confirmed = await gateway.confirmCutover({
    mutationId: await idFor('confirm-cutover'),
    runId: begun.runId,
    manifestFingerprint: input.manifestFingerprint,
    expectedEpoch,
  });

  return {
    status: 'activated',
    epoch: confirmed.epoch,
    acceptedVersions: records.map(record => ({
      legacyId: record.legacyId,
      serverVersion: 1,
      schemaVersion: record.schemaVersion,
      payloadFingerprint: record.payloadFingerprint,
    })),
  };
}
```

- [ ] **Step 4: Run it and watch it pass**

Run: `npx vitest run --project unit src/lib/durableDm/__tests__/resumableCloudActivation.test.ts`
Expected: 25 passed.

- [ ] **Step 5: Mutation-verify every guard**

One at a time, restoring the file from a pre-mutation copy after each, and quoting the failure line into `SLICE_11G_EVIDENCE.md`:

| Mutation | Expected red test |
|---|---|
| Delete the whole `preview.authority === 'postgres'` block | `reconciles without staging again when confirm already committed` |
| Make `matchesManifest` `return true` | `conflicts, and never stages, when the cloud generation has diverged` |
| Drop the `recordCount`/`documents.length` checks from `matchesManifest` | `conflicts when the cloud holds a different document set` |
| Drop `document.tombstoned === record.tombstoned` | `conflicts when a tombstone flag disagrees` |
| Replace `runId: begun.runId` in `confirmCutover` with a fresh `crypto.randomUUID()` | `stages and confirms when the server is still legacy` |
| Delete the `preview.epoch !== expectedEpoch + 1` branch | `conflicts when the cloud sits at an epoch this run was not activating into` |
| Delete the `previewFingerprint` presence branch | `conflicts when the preview carries no usable fingerprint` |
| Drop `document.schemaVersion === record.schemaVersion` from `matchesManifest` | `conflicts when only the schema version differs` |
| Delete the `assertWorkingCopyUnchanged` call before `begin-staging` | `checks the working copy before staging and again before confirming` |
| Delete the `assertWorkingCopyUnchanged` call before `confirm-cutover` | `refuses to confirm when the working copy changed during the upload` |
| Delete the `assertWorkingCopyUnchanged` call on the reconcile path | `checks the working copy before reconciling an already-committed generation` |
| Replay `begin-staging` with a fresh mutation id | `after begin-staging, before stage-items: replays the same server run id` |
| Generate a fresh `deviceId` per attempt in the adapter instead of reading the persisted key | `<family>: sends the exact hashed request bodies, and reuses them on a retry` (the conformance suite, which runs a real adapter — the fake's own self-test cannot catch this, because it never executes one) |
| Let `confirmCutover` accept a run in `staging` | `the fake refuses to confirm a run that never reached validated` |

- [ ] **Step 6: Commit**

```bash
git add src/lib/durableDm/resumableCloudActivation.ts src/lib/durableDm/__tests__/resumableCloudActivation.test.ts
git commit -m "feat: make durable family cloud activation safe against a lost response"
```

---

## Task 7: Adapter interface, conformance suite, and the campaign_settings adapter

**Spec:** R1, R10, R12. This task ships the contract and the first implementation together, because a conformance suite with no adapter proves nothing.

**Files:**
- Create: `src/lib/durableDm/durableFamilyAdapter.ts`
- Create: `src/lib/durableDm/adapters/campaignSettingsAdapter.ts`
- Create: `src/lib/durableDm/adapters/__tests__/adapterConformance.ts` (shared suite, not a `.test.ts`)
- Test: `src/lib/durableDm/adapters/__tests__/campaignSettingsAdapter.test.ts`

**Interfaces:**
- Consumes: `normalizeFamilyAuthority` (Task 5), `runResumableCloudActivation` (Task 6).
- Produces:
```ts
export type DurableFamilyName =
  | 'campaign_settings' | 'calendar' | 'magic_item'
  | 'npc' | 'encounter_definition' | 'combat_log_archive';

export interface MigrationRunContext {
  accountId: string;
  campaignId: string;
  campaignCode: string;
  workspace: DmWorkspaceDocument;
  recovery: DeviceBackupV1;
  /** Idempotent, run-level. Awaited before any local cutover (spec R10). */
  ensureWorkspaceRemembered: () => Promise<void>;
}

/**
 * A manifest handle, not a flattened copy.
 *
 * The six families do not share a manifest shape: `CampaignSettingsManifestRecord`
 * carries `payload` and `references` and has no `tombstoned` field, while
 * `CombatLogArchiveManifestRecord` carries `payload | null` and `tombstoned` and
 * has no references. Flattening to ids and fingerprints would throw away exactly
 * what `commit*LocalCutover` and `stage-items` need, forcing every adapter to
 * rebuild the manifest or cast. So the handle carries a uniform projection for
 * the wizard UI and the activation parity check, plus the family's own manifest
 * untouched in `native` — which only that family's adapter ever reads.
 */
export interface FamilyManifestHandle<TNative = unknown> {
  family: DurableFamilyName;
  fingerprint: string;
  recordCount: number;
  totalBytes: number;
  blockers: { kind: string; legacyId: string | null; detail: string }[];
  records: {
    legacyId: string;
    schemaVersion: number;
    byteCount: number;
    payloadFingerprint: string;
    /** `false` for families whose manifest has no tombstone concept. */
    tombstoned: boolean;
    /** `[]` for families with no typed cross-family references. */
    references: { family: string; legacyId: string }[];
  }[];
  native: TNative;
}

export interface FamilyConfirmation {
  familyLabel: string;
  campaignLabel: string;
  manifestFingerprint: string;
  requiredPhrase: string;
}

export interface DurableFamilyAdapter<TNative = unknown> {
  family: DurableFamilyName;
  label: string;
  isVisible(): boolean;
  previewManifest(context: MigrationRunContext): Promise<FamilyManifestHandle<TNative>>;
  confirmation(context: MigrationRunContext, manifest: FamilyManifestHandle<TNative>): FamilyConfirmation;
  selectFamily(context: MigrationRunContext): Promise<void>;
  prepareIndexedDb(context: MigrationRunContext): Promise<{ state: string; generation: string; manifest: FamilyManifestHandle<TNative> }>;
  commitLocalCutover(
    context: MigrationRunContext,
    input: { generation: string; manifest: FamilyManifestHandle<TNative> }
  ): Promise<{ epoch: number }>;
  /**
   * Runs the cloud half AND the local half: staging and confirmation through
   * `runResumableCloudActivation`, then `mark*CloudAuthority` to rebase the
   * accepted document versions and drain the outbox rows, then the family's
   * localStorage authority marker. Returning after the server call alone would
   * leave the account Postgres-authoritative while the device still believes it
   * is IndexedDB-authoritative.
   */
  activateCloud(
    context: MigrationRunContext,
    manifest: FamilyManifestHandle<TNative>
  ): Promise<CloudActivationOutcome>;
  verifyCloud(context: MigrationRunContext): Promise<FamilyVerification>;
  readAuthority(context: Pick<MigrationRunContext, 'accountId' | 'campaignId' | 'campaignCode'>): Promise<NormalizedAuthority>;
  rollback(context: MigrationRunContext): Promise<{ epoch: number }>;
}
```

`repairAuthority` is **deliberately absent here.** Task 13b adds it to this interface and implements it in all six adapters in the same commit. Declaring it now would make every Task 7–12 commit fail to satisfy `DurableFamilyAdapter`, since none of them implement it yet.

```ts

export type CloudActivationOutcome =
  | { status: 'activated' | 'reconciled'; epoch: number }
  | { status: 'conflict'; reason: string };
```
**`verifyCloud` is implemented in each adapter's own task, not deferred.** The interface requires it from Task 7 onward, so an adapter that stubs it would ship an incomplete commit and the conformance suite's verification tests could not run. Task 16 builds the *report* on top of these, and adds only the cross-family check (unrelated recovery entries unchanged). `FamilyVerification` is declared once here so every task shares it:
```ts
export interface FamilyVerification {
  authorityAgrees: boolean;
  cloudAuthority: 'legacy' | 'postgres';
  epoch: number;
  recordCount: number;
  /** Compares legacyId, payloadFingerprint AND schemaVersion. */
  documentsMatch: boolean;
  tombstonesMatch: boolean;
  /**
   * Settled state, not an empty table: zero NON-TERMINAL outbox entries.
   * Acknowledged and superseded rows are history and stay. Requiring physical
   * emptiness would make a correctly synced device permanently unverifiable.
   */
  outboxEmpty: boolean;
  /**
   * UNRESOLVED conflicts only. A preserved device candidate is recoverable data
   * the program exists to protect; counting it here would make origin B
   * permanently unverifiable after any legitimate divergence.
   */
  conflictCount: number;
  verified: boolean;
}
```

**Per-family symbol map — verified against source.** Every adapter is the same shape with these six substitutions. Tasks 8–12 use the same table.

| Family | Manifest builder | Selection writer | Migration runner | Local cutover | Cloud authority | Rollback | Authority pointer | Repository | API gateway | Marker reader |
|---|---|---|---|---|---|---|---|---|---|---|
| `campaign_settings` | `buildCampaignSettingsManifest` | `selectCampaignSettings` | `runCampaignSettingsIndexedDbMigration` | `commitCampaignSettingsLocalCutover` | `markCampaignSettingsCloudAuthority` | `rollbackCampaignSettingsLocalAuthority` | `readCampaignSettingsAuthority` | `IndexedDbCampaignSettingsRepository` | `campaignSettingsApi` → `/api/campaign-settings` | `readCampaignSettingsProjectionAuthority` |
| `calendar` | `buildCalendarManifest` | `selectCalendar` | `runCalendarIndexedDbMigration` | `commitCalendarLocalCutover` | `markCalendarCloudAuthority` | `rollbackCalendarLocalAuthority` | `readCalendarAuthority` | `IndexedDbCalendarRepository` | `calendarApi` → `/api/calendar-sync` | `readCalendarProjectionAuthority` |
| `magic_item` | `buildMagicItemManifest` | `selectMagicItemLibrary` | `runMagicItemIndexedDbMigration` | `commitMagicItemLocalCutover` | `markMagicItemCloudAuthority` | `rollbackMagicItemLocalAuthority` | `readMagicItemAuthority` | `IndexedDbMagicItemRepository` | `magicItemApi` → `/api/magic-item-sync` | `readMagicItemAuthorityMarker` |
| `npc` | `buildNpcManifest` | `selectNpcFamily` | `runNpcIndexedDbMigration` | `commitNpcLocalCutover` | `markNpcCloudAuthority` | `rollbackNpcLocalAuthority` | `readNpcAuthority` | `IndexedDbNpcRepository` | `npcApi` → `/api/npc-sync` | `readNpcAuthorityMarker` |
| `encounter_definition` | `buildEncounterManifest` | `selectEncounterFamily` | `runEncounterIndexedDbMigration` | `commitEncounterLocalCutover` | `markEncounterCloudAuthority` | `rollbackEncounterLocalAuthority` | `readEncounterAuthority` | `IndexedDbEncounterRepository` | `encounterApi` → `/api/encounter-sync` | `readEncounterAuthorityMarker` |
| `combat_log_archive` | `buildCombatLogArchiveManifest` | `selectCombatLogArchiveFamily` | `runCombatLogArchiveIndexedDbMigration` | `commitCombatLogArchiveLocalCutover` | `markCombatLogArchiveCloudAuthority` | `rollbackCombatLogArchiveLocalAuthority` | `readCombatLogArchiveAuthority` | `IndexedDbCombatLogArchiveRepository` | `combatLogArchiveApi` → `/api/combat-log-sync` | `readCombatLogArchiveAuthorityMarker` |

Confirm each name with `grep -n "export .*<name>" src/lib/...` before you use it; do not trust the table alone.

**The reference for every step's arguments is the shipped card.** For `campaign_settings` that is `src/components/ui/campaign/CampaignSettingsSyncControls.tsx`; read its `preview`, `verifyRecoveryAndSelect`, `prepare`, `activateLocal`, `activateCloud` and `rollback` handlers and reproduce their argument objects exactly. The adapter changes *who calls*, never *what is called with what*.

- [ ] **Step 1: Write the shared conformance suite**

`src/lib/durableDm/adapters/__tests__/adapterConformance.ts` — a function, invoked from each adapter's own test file, so a new adapter joins the contract by adding one line.

```ts
import { expect, it, vi } from 'vitest';

import type { DurableFamilyAdapter, MigrationRunContext } from '../../durableFamilyAdapter';

export interface ConformanceHarness {
  adapter: DurableFamilyAdapter;
  /** Seeds legacy localStorage + an open rollkeeper-local database. */
  seed(): Promise<MigrationRunContext>;
  /** Every localStorage key and IndexedDB document, for byte comparison. */
  snapshot(): Promise<string>;
  /** Drives select -> prepare -> commitLocalCutover with the real adapter. */
  runChainThroughLocalCutover(context: MigrationRunContext): Promise<void>;
  /** The above, plus activateCloud against the fake server. */
  runChainThroughCloudActivation(context: MigrationRunContext): Promise<void>;
  /** Makes the next cloud call reject, for the failure-path tests. */
  failCloud(): void;
  /** Ordered trace of API actions, working-copy checks and local commits. */
  trace(): string[];
  /** Seeds the persisted `rollkeeper:<family>-device:*` key before the run. */
  seedDeviceId(deviceId: string): void;
  /** The complete request body handed to each cloud call, in order. */
  requestBodies(): {
    beginStaging: Record<string, unknown>[];
    stageItems: Record<string, unknown>[];
    confirmCutover: Record<string, unknown>[];
  };
  /** legacyId -> payloadFingerprint for every local document. */
  documentFingerprints(): Promise<Record<string, string>>;
  addPendingOutboxEntry(): Promise<void>;
  addAcknowledgedOutboxRow(): Promise<void>;
  drainOutbox(): Promise<void>;
  addUnresolvedConflict(): Promise<void>;
  /** The run id the fake server issued, for the request-body assertions. */
  serverRunId(): string;
  /** Clears `requestBodies()` so a second attempt can be compared to the first. */
  resetRecordedRequests(): void;
  /** Marker/pointer states for Task 13b's repair cases. */
  pointerState(): Promise<'localStorage' | 'indexedDB' | 'postgres'>;
}

export function describeAdapterConformance(
  name: string,
  createHarness: () => ConformanceHarness
) {
  it(`${name}: previewManifest changes nothing`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    const before = await harness.snapshot();
    await harness.adapter.previewManifest(context);
    expect(await harness.snapshot()).toBe(before);
  });

  it(`${name}: readAuthority changes nothing`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    const before = await harness.snapshot();
    await harness.adapter.readAuthority(context);
    expect(await harness.snapshot()).toBe(before);
  });

  it(`${name}: readAuthority reports legacy before any migration`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    expect(await harness.adapter.readAuthority(context)).toMatchObject({
      state: 'legacy',
      rolledBack: false,
    });
  });

  it(`${name}: selectFamily refuses without a verified receipt for this run`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    const before = await harness.snapshot();
    await expect(
      harness.adapter.selectFamily({
        ...context,
        recovery: { ...context.recovery, manifestHash: 'f'.repeat(64) },
      })
    ).rejects.toThrow();
    expect(await harness.snapshot()).toBe(before);
  });

  it(`${name}: prepareIndexedDb refuses a manifest hash that is not the run's`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    await harness.adapter.selectFamily(context);
    await expect(
      harness.adapter.prepareIndexedDb({
        ...context,
        recovery: { ...context.recovery, manifestHash: 'e'.repeat(64) },
      })
    ).rejects.toThrow();
  });

  it(`${name}: commitLocalCutover refuses when the workspace is not remembered`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    await harness.adapter.selectFamily(context);
    const prepared = await harness.adapter.prepareIndexedDb(context);
    const before = await harness.snapshot();
    await expect(
      harness.adapter.commitLocalCutover(
        { ...context, ensureWorkspaceRemembered: async () => {} },
        { generation: prepared.generation, manifest: prepared.manifest }
      )
    ).rejects.toThrow(/workspace/i);
    expect(await harness.snapshot()).toBe(before);
  });

  it(`${name}: commitLocalCutover remembers the workspace before it cuts over`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    const order: string[] = [];
    const remembering = {
      ...context,
      ensureWorkspaceRemembered: vi.fn(async () => {
        order.push('remember');
        await context.ensureWorkspaceRemembered();
      }),
    };
    await harness.adapter.selectFamily(remembering);
    const prepared = await harness.adapter.prepareIndexedDb(remembering);
    await harness.adapter.commitLocalCutover(remembering, {
      generation: prepared.generation,
      manifest: prepared.manifest,
    });
    order.push('cutover');
    expect(remembering.ensureWorkspaceRemembered).toHaveBeenCalled();
    expect(order).toEqual(['remember', 'cutover']);
    expect(await harness.adapter.readAuthority(remembering)).toMatchObject({
      state: 'indexedDB',
    });
  });

  it(`${name}: a failed cloud activation leaves IndexedDB authority in place`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    await harness.adapter.selectFamily(context);
    const prepared = await harness.adapter.prepareIndexedDb(context);
    await harness.adapter.commitLocalCutover(context, {
      generation: prepared.generation,
      manifest: prepared.manifest,
    });
    harness.failCloud();
    await expect(
      harness.adapter.activateCloud(context, prepared.manifest)
    ).rejects.toThrow();
    expect(await harness.adapter.readAuthority(context)).toMatchObject({
      state: 'indexedDB',
      epoch: 1,
    });
  });

  it(`${name}: activation calls the server in order and commits the local half`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    await harness.runChainThroughLocalCutover(context);
    const manifest = await harness.adapter.previewManifest(context);
    await harness.adapter.activateCloud(context, manifest);
    expect(harness.trace()).toEqual([
      'preview-enrollment',
      'assert-working-copy',
      'begin-staging',
      'stage-items',
      'assert-working-copy',
      'confirm-cutover',
      'mark-cloud-authority',
      'write-marker',
    ]);
    expect(await harness.adapter.readAuthority(context)).toMatchObject({
      state: 'postgres',
    });
  });

  it(`${name}: sends the exact hashed request bodies, and reuses them on a retry`, async () => {
    // This is what actually pins the persisted-device rule. The fake server's
    // own self-tests call it directly with hard-coded inputs and never execute
    // an adapter, so they cannot catch an adapter that generates a fresh device
    // id per attempt. Only asserting the bodies an adapter really sends can.
    const harness = createHarness();
    const context = await harness.seed();
    harness.seedDeviceId('device-under-test');
    await harness.runChainThroughLocalCutover(context);
    const manifest = await harness.adapter.previewManifest(context);

    await harness.adapter.activateCloud(context, manifest);

    const first = harness.requestBodies();
    expect(first.beginStaging).toHaveLength(1);
    expect(first.beginStaging[0]).toMatchObject({
      campaignId: context.campaignId,
      // Read from the persisted key, never regenerated: it is hashed into
      // begin_staging, so a fresh value turns a retry into a 22023 rejection.
      deviceId: 'device-under-test',
      expectedEpoch: 0,
      manifestFingerprint: manifest.fingerprint,
      recoveryManifestHash: context.recovery.manifestHash,
      recordCount: manifest.recordCount,
      totalBytes: manifest.totalBytes,
    });

    const runId = harness.serverRunId();
    expect(first.stageItems[0]).toMatchObject({ runId, items: expect.any(Array) });
    expect(first.stageItems[0].items).toHaveLength(manifest.recordCount);
    expect(first.confirmCutover[0]).toMatchObject({
      runId,
      manifestFingerprint: manifest.fingerprint,
      expectedEpoch: 0,
    });

    // Re-run the whole activation against the same fake server. Every body must
    // hash equal to the first attempt, or the receipts cannot replay.
    harness.resetRecordedRequests();
    await harness.adapter.activateCloud(context, manifest);
    const second = harness.requestBodies();
    expect(second.beginStaging[0]).toEqual(first.beginStaging[0]);
    expect(second.stageItems[0]).toEqual(first.stageItems[0]);
    expect(second.confirmCutover[0]).toEqual(first.confirmCutover[0]);
  });

  it(`${name}: rollback returns to legacy at a new epoch and keeps every document`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    await harness.runChainThroughCloudActivation(context);
    const documents = await harness.documentFingerprints();
    const result = await harness.adapter.rollback(context);
    expect(result.epoch).toBeGreaterThan(1);
    expect(await harness.adapter.readAuthority(context)).toMatchObject({
      state: 'legacy',
      rolledBack: true,
    });
    expect(await harness.documentFingerprints()).toEqual(documents);
  });

  it(`${name}: verification fails on a pending outbox entry or an unresolved conflict`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    await harness.runChainThroughCloudActivation(context);
    expect(await harness.adapter.verifyCloud(context)).toMatchObject({
      verified: true,
      outboxEmpty: true,
      conflictCount: 0,
    });

    await harness.addPendingOutboxEntry();
    expect(await harness.adapter.verifyCloud(context)).toMatchObject({
      verified: false,
      outboxEmpty: false,
    });

    await harness.drainOutbox();
    await harness.addUnresolvedConflict();
    expect(await harness.adapter.verifyCloud(context)).toMatchObject({
      verified: false,
    });
  });

  it(`${name}: an acknowledged outbox row does not make the family unverifiable`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    await harness.runChainThroughCloudActivation(context);
    await harness.addAcknowledgedOutboxRow();
    expect(await harness.adapter.verifyCloud(context)).toMatchObject({
      verified: true,
      outboxEmpty: true,
    });
  });

  it(`${name}: confirmation names the exact manifest fingerprint being cut over`, async () => {
    const harness = createHarness();
    const context = await harness.seed();
    const manifest = await harness.adapter.previewManifest(context);
    const confirmation = harness.adapter.confirmation(context, manifest);
    expect(confirmation.manifestFingerprint).toBe(manifest.fingerprint);
    expect(confirmation.requiredPhrase.length).toBeGreaterThan(0);
    expect(confirmation.campaignLabel).toContain(context.campaignCode);
  });
}
```

- [ ] **Step 2: Write the campaign_settings adapter test**

`src/lib/durableDm/adapters/__tests__/campaignSettingsAdapter.test.ts`:

```ts
import { beforeEach, describe, expect, it } from 'vitest';

import { campaignSettingsAdapter } from '../campaignSettingsAdapter';
import { describeAdapterConformance } from './adapterConformance';
import { createCampaignSettingsHarness } from './harnesses/campaignSettings';

describe('campaignSettingsAdapter', () => {
  beforeEach(() => {
    process.env.NEXT_PUBLIC_CAMPAIGN_SETTINGS_SYNC_VISIBLE = 'true';
  });

  describeAdapterConformance('campaign_settings', createCampaignSettingsHarness);

  it('is invisible when its own client flag is off', () => {
    process.env.NEXT_PUBLIC_CAMPAIGN_SETTINGS_SYNC_VISIBLE = 'false';
    expect(campaignSettingsAdapter.isVisible()).toBe(false);
  });

  it('reports the manifest blockers verbatim, without deciding what to do about them', async () => {
    const harness = createCampaignSettingsHarness();
    const context = await harness.seedWithBlocker();
    const manifest = await campaignSettingsAdapter.previewManifest(context);
    expect(manifest.blockers.length).toBeGreaterThan(0);
  });
});
```

Build `harnesses/campaignSettings.ts` on the fixtures the shipped tests already use: copy the localStorage seed and the fake IndexedDB setup from `src/lib/indexeddb/__tests__/campaignSettingsMigration.test.ts` rather than inventing new ones, so the adapter is exercised against the same shapes the family already asserts on.

- [ ] **Step 3: Run and watch it fail**

Run: `npx vitest run --project unit src/lib/durableDm/adapters/__tests__/campaignSettingsAdapter.test.ts`
Expected: `Failed to resolve import "../campaignSettingsAdapter"`.

- [ ] **Step 4: Implement the interface module and the adapter**

`durableFamilyAdapter.ts` holds only the types listed under **Interfaces** above — no logic.

`campaignSettingsAdapter.ts` implements each method by calling the mapped symbol with the argument object copied from `CampaignSettingsSyncControls.tsx`.

At **module scope**, above the adapter object — a `function` declaration inside an object literal is not valid TypeScript:

```ts
/**
 * The per-device identity the cards store under
 * `rollkeeper:<family>-device:<accountId>:<campaignId>`, created on first use.
 * Copy the card's own helper rather than inventing a second key shape.
 */
function deviceIdFor(context: MigrationRunContext) {
  const key = `rollkeeper:campaign-settings-device:${context.accountId}:${context.campaignId}`;
  let deviceId = localStorage.getItem(key);
  if (!deviceId) {
    deviceId = crypto.randomUUID();
    localStorage.setItem(key, deviceId);
  }
  return deviceId;
}
```

Three rules that are not obvious from the card:

```ts
  async commitLocalCutover(context, input) {
    const namespace = `user:${context.accountId}` as const;
    // Spec R10. The backport's defect 1 was this call missing on the local
    // cutover path: hydration then failed after a reload, the store fell back
    // to the frozen legacy copy, and every later edit was accepted by the UI
    // and lost. Ordered before the cutover so a failure here leaves legacy
    // authority untouched, and asserted afterwards so a caller that passes a
    // no-op cannot cut over into an unhydratable state.
    await context.ensureWorkspaceRemembered();
    const database = await openRollkeeperDatabase();
    try {
      // There is no `readWorkspaceIdentity` helper. The identity record lives
      // in the `documents` store under [namespace, 'workspace_identity',
      // localId], which is exactly what this repository's `get` reads. Matching
      // `cloudId` is the part that matters: a record for a different cloud
      // campaign would satisfy a bare existence check and still leave hydration
      // unable to find this campaign.
      const identity = await new IndexedDbDmWorkspaceRepository(database).get(
        namespace,
        context.workspace.localId
      );
      if (!identity || identity.cloudId !== context.campaignId)
        throw new Error(
          'This device has no owner workspace recorded for the campaign, so the migration cannot continue.'
        );
      const next = await commitCampaignSettingsLocalCutover(database, {
        namespace,
        campaignId: context.campaignId,
        generation: input.generation,
        confirmed: true,
        gates: { /* copy verbatim from the card's activateLocal */ },
        now: () => new Date().toISOString(),
        // Singular, and optional: campaign_settings is a single-record family
        // and its option is `initialDocument?: CampaignSettingsDocument`, not
        // the `initialDocuments` array the multi-record families take. Build it
        // from `input.manifest.native.records[0]`, exactly as the card does.
        initialDocument: /* copy verbatim from the card's activateLocal */,
      });
      writeCampaignSettingsProjectionAuthority(localStorage, context.campaignCode, {
        version: 1,
        authority: 'indexedDB',
        epoch: next.epoch,
        campaignId: context.campaignId,
        namespace,
      });
      return { epoch: next.epoch };
    } finally {
      database.close();
    }
  },

  async activateCloud(context, manifest) {
    // The local epoch is read fresh and reconciled, never carried in from an
    // earlier step: `expectedEpoch` is the epoch the SERVER is expected to
    // still hold, which the shipped cards compute as `authority.epoch - 1`
    // floored at zero. A stale local value here either rejects a legal
    // activation or, worse, confirms against the wrong epoch.
    const local = await this.readAuthority(context);
    if (local.state !== 'indexedDB')
      throw new Error('This device is not ready to back this family up yet.');
    const localEpoch = local.epoch;

    // Spec R7: the protocol lives in one place; the adapter binds the family's
    // own API route to it and supplies the working-copy check the shipped card
    // performs. Without that check an edit made while the upload is in flight
    // is silently excluded from the generation that becomes authoritative.
    const result = await runResumableCloudActivation({
      // `IndexedDbCampaignSettingsRepository` has no `listDocuments`. It is a
      // single-record family, and its accessor is
      // `getDocument(namespace, legacyId)` — keyed by the campaign code, which
      // is this family's legacy id.
      assertWorkingCopyUnchanged: async () => {
        const [record] = manifest.records;
        const database = await openRollkeeperDatabase();
        try {
          const document = await new IndexedDbCampaignSettingsRepository(
            database
          ).getDocument(`user:${context.accountId}`, record.legacyId);
          if (
            !document ||
            document.contentFingerprint !== record.payloadFingerprint ||
            document.schemaVersion !== record.schemaVersion
          )
            throw new Error(
              'Your campaign settings changed since the last check. Preview the migration again.'
            );
        } finally {
          database.close();
        }
      },
      gateway: {
        // `preview_campaign_settings_device_enrollment` returns a FLAT single
        // document — `legacyId`, `serverVersion`, `schemaVersion`,
        // `payloadFingerprint`, `tombstoned`, `payload` at the top level — with
        // no `recordCount` and no `documents` array. The generic protocol is
        // multi-document, so the adapter normalizes here rather than teaching
        // the protocol about a per-family response shape.
        previewEnrollment: async () => {
          const raw = await campaignSettingsApi<{
            authority: 'legacy' | 'postgres';
            epoch?: number;
            previewFingerprint?: string;
            legacyId?: string;
            serverVersion?: number;
            schemaVersion?: number;
            payloadFingerprint?: string;
            tombstoned?: boolean;
          }>({ action: 'preview-enrollment', campaignId: context.campaignId });
          if (raw.authority !== 'postgres') return { authority: 'legacy' };
          return {
            authority: 'postgres',
            epoch: raw.epoch,
            previewFingerprint: raw.previewFingerprint,
            recordCount: 1,
            documents: [
              {
                legacyId: raw.legacyId!,
                serverVersion: raw.serverVersion!,
                schemaVersion: raw.schemaVersion!,
                payloadFingerprint: raw.payloadFingerprint!,
                tombstoned: raw.tombstoned ?? false,
              },
            ],
          };
        },
        beginStaging: input =>
          campaignSettingsApi({
            action: 'begin-staging',
            mutationId: input.mutationId,
            campaignId: context.campaignId,
            deviceId: input.deviceId,
            expectedEpoch: input.expectedEpoch,
            manifestFingerprint: input.manifestFingerprint,
            recoveryManifestHash: input.recoveryManifestHash,
            recoveryReceiptHash: input.recoveryManifestHash,
            recordCount: input.recordCount,
            totalBytes: input.totalBytes,
          }),
        stageItems: input =>
          campaignSettingsApi({
            action: 'stage-items',
            mutationId: input.mutationId,
            runId: input.runId,
            items: input.items,
          }),
        confirmCutover: input =>
          campaignSettingsApi({
            action: 'confirm-cutover',
            mutationId: input.mutationId,
            runId: input.runId,
            manifestFingerprint: input.manifestFingerprint,
            expectedEpoch: input.expectedEpoch,
          }),
      },
      family: 'campaign_settings',
      recoveryRunId: context.recovery.runId,
      campaignId: context.campaignId,
      manifestFingerprint: manifest.fingerprint,
      records: manifest.records,
      expectedEpoch: Math.max(0, localEpoch - 1),
      request: {
        // Persisted, never freshly generated — it is hashed into begin_staging.
        deviceId: deviceIdFor(context),
        recoveryManifestHash: context.recovery.manifestHash,
        recordCount: manifest.recordCount,
        totalBytes: manifest.totalBytes,
        // The exact staged item bodies the card sends, built from
        // `manifest.native.records`. They are hashed into stage_items, so they
        // must be byte-identical on a retry.
        items: /* copy verbatim from the card's activateCloud */,
      },
    });

    if (result.status === 'conflict')
      return { status: 'conflict', reason: result.reason };

    // The local half. Without it the account is Postgres-authoritative while
    // this device still believes it owns the family locally: the accepted
    // server versions are never rebased onto the local documents, the outbox
    // rows for them are never drained, and the marker still says indexedDB, so
    // the next reload hydrates against the wrong authority.
    const database = await openRollkeeperDatabase();
    try {
      const next = await markCampaignSettingsCloudAuthority(database, {
        namespace: `user:${context.accountId}`,
        campaignId: context.campaignId,
        expectedLocalEpoch: localEpoch,
        cloudEpoch: result.epoch,
        now: () => new Date().toISOString(),
        // Singular: campaign_settings is a single-record family and its option
        // is `acceptedVersion?`, not the `acceptedVersions` array the
        // multi-record families take.
        acceptedVersion: result.acceptedVersions[0],
      });
      writeCampaignSettingsProjectionAuthority(localStorage, context.campaignCode, {
        version: 1,
        authority: 'postgres',
        epoch: next.epoch,
        campaignId: context.campaignId,
        namespace: `user:${context.accountId}`,
      });
      return { status: result.status, epoch: next.epoch };
    } finally {
      database.close();
    }
  },

  confirmation(context, manifest) {
    // Spec R12: a structured contract, never a copy of the card's prose. The
    // cards are untouched by this slice, so their literal strings can drift;
    // tests assert these four fields, never textual equality with a card.
    return {
      familyLabel: 'Campaign settings',
      campaignLabel: `${context.campaignCode}`,
      manifestFingerprint: manifest.fingerprint,
      requiredPhrase: `migrate campaign settings ${manifest.fingerprint.slice(0, 12)}`,
    };
  },
```

- [ ] **Step 5: Run and watch it pass**

Run: `npx vitest run --project unit src/lib/durableDm/adapters/__tests__/campaignSettingsAdapter.test.ts`

- [ ] **Step 6: Mutation-verify the two adapter-specific guards**

1. Delete `await context.ensureWorkspaceRemembered()` and the identity assertion — expect `commitLocalCutover refuses when the workspace is not remembered` to go red.
2. Return a hard-coded fingerprint from `confirmation` — expect `confirmation names the exact manifest fingerprint being cut over` to go red.

Quote both into the evidence file, then restore.

- [ ] **Step 7: Prove the family's own contract still passes**

Run: `npm run test:slice11a:coverage`
Expected: green. The adapter must not have changed anything the family already asserts.

- [ ] **Step 8: Commit**

```bash
git add src/lib/durableDm/durableFamilyAdapter.ts src/lib/durableDm/adapters/
git commit -m "feat: extract the durable family adapter and implement it for campaign settings"
```

---

## Tasks 8–12: the remaining five adapters

Each of these is its own task, its own review and its own commit. They are ordered by risk, easiest first, so a mistake in the pattern surfaces on a simple family. **Do not batch them.**

Every one of the five follows the same five-part shape:

1. Read the family's shipped card end to end and copy each step's argument object verbatim.
2. Build a harness in `src/lib/durableDm/adapters/__tests__/harnesses/<family>.ts` from the fixtures in that family's existing `src/lib/indexeddb/__tests__/<family>Migration.test.ts`.
3. Register the family with `describeAdapterConformance('<family>', createHarness)` — that single line is how the family joins the contract.
4. Add the family-specific tests listed in its task below.
5. Mutation-verify the `ensureWorkspaceRemembered` ordering and the `confirmation` fingerprint, exactly as in Task 7 step 6, plus any guard the task names.
6. Write the **card/adapter step-parity test** for the family. This is the check that makes ruling R1's two call-sites safe, and it is not optional.

**The step-parity test.** Drive the shipped card through its own chain with a recording gateway, then drive the adapter through the same chain against the same seed, and assert the two traces match on:

- the ordered sequence of library calls and API actions, **and the complete request body of each cloud call** — action names alone would let a changed `deviceId`, recovery hash, count, byte total or item body through;
- the argument object handed to `commit*LocalCutover`, compared field by field, including every `gates` flag and the `initialDocument`/`initialDocuments` shape;
- the ordered `gates` evaluation, so a reordered gate is caught;
- the localStorage marker written, compared as parsed JSON;
- the `mark*CloudAuthority` arguments, including `expectedLocalEpoch`, `cloudEpoch` and `acceptedVersions`.

Differences that are expected and must be allowed for explicitly, with a comment naming each: the adapter has no enrollment path, no history/restore/export, and no `window.confirm`. Everything else must be identical. If a trace differs for any other reason, the adapter is wrong — not the test.

The symbol map is the table in Task 7. The card to read for each family:

| Family | Card | Contract to re-run |
|---|---|---|
| `calendar` | `src/components/ui/calendar/CalendarSyncControls.tsx` | `npm run test:slice11b:coverage` |
| `magic_item` | `src/components/ui/campaign/MagicItemLibrary/MagicItemSyncControls.tsx` | `npm run test:slice11c:coverage` |
| `npc` | `src/components/ui/campaign/NpcSyncControls/NpcSyncControls.hooks.ts` | `npm run test:slice11d:coverage` |
| `encounter_definition` | `src/components/ui/campaign/EncounterSyncControls/EncounterSyncControls.hooks.ts` | `npm run test:slice11e:coverage` |
| `combat_log_archive` | `src/components/ui/campaign/CombatLogArchiveSyncControls/CombatLogArchiveSyncControls.hooks.ts` | `npm run test:slice11f:coverage` |

### Task 8: `calendar` adapter

**Files:** create `src/lib/durableDm/adapters/calendarAdapter.ts`, `.../__tests__/calendarAdapter.test.ts`, `.../__tests__/harnesses/calendar.ts`.

**Divergences to encode:**

- **Single-record family.** The manifest carries one record for the whole campaign calendar, so `records.length === 1` and `matchesManifest` in Task 6 compares a one-element set. Do not assume a multi-record shape anywhere.
- **Player projection.** `calendar` publishes a sanitized player view; `campaign_settings` does too. The adapter must not touch projection: no `projection-status`, `projection-incidents` or `replay-projection` call belongs in it. Assert this.
- **Marker dialect.** `readCalendarProjectionAuthority` — the projection-authority key, no `accountId`, `legacy_restored` for a rollback. Ownership comes from `readCalendarAuthority(database, namespace, campaignId)`.
- **`applyExactCloudVersion` short-circuit is not the adapter's problem.** The backport's Critical lived in the card's enrollment path, which the wizard deliberately does not have. Do not port it, and do not add an enrollment method to the adapter.

**Extra test:**

```ts
it('makes no projection call during the whole migration chain', async () => {
  const harness = createCalendarHarness();
  const context = await harness.seed();
  const calls = harness.recordedApiActions();
  await harness.adapter.previewManifest(context);
  await harness.adapter.selectFamily(context);
  const prepared = await harness.adapter.prepareIndexedDb(context);
  await harness.adapter.commitLocalCutover(context, {
    generation: prepared.generation,
    manifest: prepared.manifest,
  });
  expect(calls()).not.toContain('projection-status');
  expect(calls()).not.toContain('replay-projection');
  expect(calls()).not.toContain('projection-incidents');
});
```

**Commit:** `feat: implement the durable family adapter for calendars`

### Task 9: `magic_item` adapter

**Files:** create `src/lib/durableDm/adapters/magicItemAdapter.ts`, `.../__tests__/magicItemAdapter.test.ts`, `.../__tests__/harnesses/magicItem.ts`.

**Divergences to encode:**

- **Multi-record family**, one document per library item, so the manifest's `records` array drives both staging and Task 6's parity check.
- **The chain lives inline in the component**, not in an extracted hook — only `planMagicItemMutations` and `runMagicItemMutationPlan` are exported. Read `MagicItemSyncControls` from its `preview` handler down and copy the argument objects; do not import anything from the component into the adapter.
- **Marker dialect:** `readMagicItemAuthorityMarker`, the ordinary authority key, no `accountId`, `legacy_restored` for a rollback.
- **Selection writer is `selectMagicItemLibrary`**, not `selectMagicItemFamily`. This is the one name that breaks the pattern.

**Extra test:**

```ts
it('stages every library item, in the manifest order, and nothing else', async () => {
  const harness = createMagicItemHarness();
  const context = await harness.seedWithItems(3);
  // The real chain first: activateCloud reads a reconciled indexedDB authority
  // and refuses outright on a family that was never selected, prepared and cut
  // over, so calling it directly would assert nothing.
  await harness.adapter.selectFamily(context);
  const prepared = await harness.adapter.prepareIndexedDb(context);
  await harness.adapter.commitLocalCutover(context, {
    generation: prepared.generation,
    manifest: prepared.manifest,
  });
  const manifest = prepared.manifest;
  await harness.adapter.activateCloud(context, manifest);
  expect(harness.stagedLegacyIds()).toEqual(
    manifest.records.map(record => record.legacyId)
  );
});
```

**Commit:** `feat: implement the durable family adapter for magic items`

### Task 10: `npc` adapter

**Files:** create `src/lib/durableDm/adapters/npcAdapter.ts`, `.../__tests__/npcAdapter.test.ts`, `.../__tests__/harnesses/npc.ts`.

**Divergences to encode:**

- **A mounted owner exists for this family** (`NpcSyncProvider`, in the campaign route-group layout). The wizard runs on a route where that layout is not mounted (spec R2a), so the adapter must never assume a provider is present and must never reach for `useNpcSyncContext`.
- **Multi-record family** with cross-family references: `campaign_settings.dmDashboardUi.npcCollapsedGroupNames` points at NPC group names. The adapter migrates NPC documents only; it does not read, rewrite or validate that reference. If `campaign_settings` migrated first in the same run, nothing about the NPC step changes.
- **Marker dialect:** `readNpcAuthorityMarker`, ordinary key, no `accountId`.

**Extra test:**

```ts
it('migrates NPC documents without touching the campaign settings family', async () => {
  const harness = createNpcHarness();
  const context = await harness.seedWithCampaignSettingsAlreadyMigrated();
  const settingsBefore = await harness.campaignSettingsSnapshot();
  const manifest = await harness.adapter.previewManifest(context);
  await harness.adapter.selectFamily(context);
  const prepared = await harness.adapter.prepareIndexedDb(context);
  await harness.adapter.commitLocalCutover(context, {
    generation: prepared.generation,
    manifest: prepared.manifest,
  });
  expect(await harness.campaignSettingsSnapshot()).toBe(settingsBefore);
});
```

**Commit:** `feat: implement the durable family adapter for NPCs`

### Task 11: `encounter_definition` adapter

**Files:** create `src/lib/durableDm/adapters/encounterAdapter.ts`, `.../__tests__/encounterAdapter.test.ts`, `.../__tests__/harnesses/encounter.ts`.

**Divergences to encode:**

- **The `active-encounter` blocker.** Slice 11E ruling 1b: an encounter with `isActive: true` blocks cutover but never blocks autosave, and the server enforces it too in `stage_encounter_items`. The adapter surfaces the blocker in `FamilyManifestHandle.blockers` and stops the family. It must not skip the active encounter, must not end combat, and must not retry.
- **Excluded envelope fields.** `combatConfig` and `activeEncounterId` are device-global and are never routed. The adapter neither reads nor writes them.
- **Encounters with no `campaignCode` are ignored, not blockers.**
- **Marker dialect:** `readEncounterAuthorityMarker`, ordinary key, no `accountId`.

**Extra tests:**

```ts
it('reports the active encounter as a blocker and refuses to prepare', async () => {
  const harness = createEncounterHarness();
  const context = await harness.seedWithActiveEncounter();
  const manifest = await harness.adapter.previewManifest(context);
  expect(manifest.blockers.map(blocker => blocker.kind)).toContain(
    'active-encounter'
  );
  await harness.adapter.selectFamily(context);
  await expect(harness.adapter.prepareIndexedDb(context)).rejects.toThrow();
});

it('leaves combatConfig and activeEncounterId byte-identical across a cutover', async () => {
  const harness = createEncounterHarness();
  const context = await harness.seed();
  const before = harness.rawEnvelopeFields(['combatConfig', 'activeEncounterId']);
  await harness.adapter.selectFamily(context);
  const prepared = await harness.adapter.prepareIndexedDb(context);
  await harness.adapter.commitLocalCutover(context, {
    generation: prepared.generation,
    manifest: prepared.manifest,
  });
  expect(harness.rawEnvelopeFields(['combatConfig', 'activeEncounterId'])).toBe(
    before
  );
});
```

**Commit:** `feat: implement the durable family adapter for encounter definitions`

### Task 12: `combat_log_archive` adapter

**Files:** create `src/lib/durableDm/adapters/combatLogArchiveAdapter.ts`, `.../__tests__/combatLogArchiveAdapter.test.ts`, `.../__tests__/harnesses/combatLogArchive.ts`.

**Divergences to encode:**

- **The only family whose marker carries `accountId` and `campaignCode`,** and the only one that writes `localStorage` rather than `legacy_restored`. Task 5's normalizer already handles both; this adapter is what proves the third dialect is covered — assert it explicitly.
- **The `active-combat-log` blocker**, same shape as the encounter one.
- **Archives with no `campaignCode` are out of scope** (Slice 11F ruling 1) and must remain in localStorage untouched.
- **Two archives can share an `encounterId`** (ruling 6); the legacy id is the `archiveId`, never the `encounterId`.

**Extra tests:**

```ts
it('normalizes the combat log dialect, including localStorage at epoch zero', async () => {
  const harness = createCombatLogArchiveHarness();
  const context = await harness.seed();
  expect(await harness.adapter.readAuthority(context)).toMatchObject({
    state: 'legacy',
    rolledBack: false,
  });
});

it('blocks the family when the marker names a different account', async () => {
  const harness = createCombatLogArchiveHarness();
  const context = await harness.seedWithMarkerForAnotherAccount();
  expect(await harness.adapter.readAuthority(context)).toMatchObject({
    state: 'inconsistent',
    reason: 'account-mismatch',
  });
});

it('leaves an unscoped archive in localStorage and out of the manifest', async () => {
  const harness = createCombatLogArchiveHarness();
  const context = await harness.seedWithUnscopedArchive();
  const manifest = await harness.adapter.previewManifest(context);
  expect(manifest.records.map(record => record.legacyId)).not.toContain(
    'unscoped-archive'
  );
  expect(harness.legacyArchiveIds()).toContain('unscoped-archive');
});
```

**Commit:** `feat: implement the durable family adapter for combat log archives`

---

## Task 13: Registry and derived run state

**Spec:** R6, R12 (registered vs planned), R13.

**Files:**
- Create: `src/lib/durableDm/familyRegistry.ts`, `src/lib/durableDm/__tests__/familyRegistry.test.ts`
- Create: `src/lib/durableDm/migrationRunState.ts`, `src/lib/durableDm/__tests__/migrationRunState.test.ts`

**Interfaces:**
- Consumes: the six adapters (Tasks 7–12), `normalizeFamilyAuthority` (Task 5).
- Produces:
```ts
export type RegistryEntry =
  | { status: 'registered'; family: DurableFamilyName; label: string; adapter: DurableFamilyAdapter }
  | { status: 'planned'; family: 'location' | 'battle_map' | 'deliveries'; label: string };

export const DURABLE_FAMILY_REGISTRY: readonly RegistryEntry[];
export function registeredAdapters(): DurableFamilyAdapter[];
export function enabledAdapters(): DurableFamilyAdapter[];

export type FamilyStepState =
  | 'notAvailable' | 'legacy' | 'selected' | 'prepared'
  | 'indexedDb' | 'postgresUnverified' | 'verified'
  | 'blocked' | 'rolledBack' | 'inconsistent';

export function deriveFamilyStepState(input: {
  entry: RegistryEntry;
  /** The family's own client flag. A registered-but-disabled family is `notAvailable`. */
  enabled: boolean;
  authority: NormalizedAuthority;
  selection: { runId: string; manifestHash: string } | null;
  runRecovery: { runId: string; manifestHash: string };
  preparedState: string | null;
  blockers: { kind: string }[];
  verification: FamilyVerification | null;
}): FamilyStepState;
```

**Order is fixed and comes from the spec brief:** `campaign_settings → calendar → magic_item → npc → encounter_definition → combat_log_archive → location → battle_map → deliveries`.

- [ ] **Step 1: Write the failing registry test**

```ts
import { describe, expect, it } from 'vitest';

import { DURABLE_FAMILY_REGISTRY, enabledAdapters, registeredAdapters } from '../familyRegistry';

describe('DURABLE_FAMILY_REGISTRY', () => {
  it('lists the nine families in the roadmap order', () => {
    expect(DURABLE_FAMILY_REGISTRY.map(entry => entry.family)).toEqual([
      'campaign_settings',
      'calendar',
      'magic_item',
      'npc',
      'encounter_definition',
      'combat_log_archive',
      'location',
      'battle_map',
      'deliveries',
    ]);
  });

  it('marks the three unshipped families planned, with no adapter', () => {
    const planned = DURABLE_FAMILY_REGISTRY.filter(entry => entry.status === 'planned');
    expect(planned.map(entry => entry.family)).toEqual([
      'location',
      'battle_map',
      'deliveries',
    ]);
    for (const entry of planned) expect('adapter' in entry).toBe(false);
  });

  it('registers exactly the six shipped families', () => {
    expect(registeredAdapters()).toHaveLength(6);
  });

  it('excludes a registered family whose own client flag is off from the enabled set', () => {
    process.env.NEXT_PUBLIC_COMBAT_LOG_SYNC_VISIBLE = 'false';
    expect(enabledAdapters().map(adapter => adapter.family)).not.toContain(
      'combat_log_archive'
    );
    expect(registeredAdapters().map(adapter => adapter.family)).toContain(
      'combat_log_archive'
    );
  });
});
```

The last assertion is the one that matters for spec R13: a disabled family is still *registered*, so it still counts against "Fully migrated".

- [ ] **Step 2: Write the failing derived-state test**

```ts
import { describe, expect, it } from 'vitest';

import { deriveFamilyStepState } from '../migrationRunState';

const runRecovery = { runId: 'run-1', manifestHash: 'a'.repeat(64) };
const registered = { status: 'registered' as const, family: 'npc' as const, label: 'NPCs', adapter: {} as never };
const planned = { status: 'planned' as const, family: 'location' as const, label: 'Locations' };
const legacy = { state: 'legacy' as const, epoch: 0, campaignId: null, accountId: null, rolledBack: false };

const base = {
  entry: registered,
  enabled: true,
  authority: legacy,
  selection: null,
  runRecovery,
  preparedState: null,
  blockers: [],
  verification: null,
};

describe('deriveFamilyStepState', () => {
  it('reports a planned family as not available', () => {
    expect(deriveFamilyStepState({ ...base, entry: planned })).toBe('notAvailable');
  });

  it('reports legacy before anything has happened', () => {
    expect(deriveFamilyStepState(base)).toBe('legacy');
  });

  it('reports a registered family whose own flag is off as not available', () => {
    expect(deriveFamilyStepState({ ...base, enabled: false })).toBe('notAvailable');
  });

  it('ignores a selection left behind by an earlier run', () => {
    expect(
      deriveFamilyStepState({
        ...base,
        selection: { runId: 'run-0', manifestHash: 'b'.repeat(64) },
      })
    ).toBe('legacy');
  });

  it('reports selected only when the selection matches this run exactly', () => {
    expect(deriveFamilyStepState({ ...base, selection: runRecovery })).toBe('selected');
  });

  it('reports prepared from the persisted migration state, not from wizard memory', () => {
    expect(
      deriveFamilyStepState({
        ...base,
        selection: runRecovery,
        preparedState: 'CUTOVER_READY',
      })
    ).toBe('prepared');
  });

  it('reports blocked whenever the manifest carries a blocker', () => {
    expect(
      deriveFamilyStepState({
        ...base,
        selection: runRecovery,
        blockers: [{ kind: 'active-encounter' }],
      })
    ).toBe('blocked');
  });

  it('reports indexedDb and postgresUnverified from the normalized authority', () => {
    expect(
      deriveFamilyStepState({
        ...base,
        authority: { ...legacy, state: 'indexedDB', epoch: 1 },
      })
    ).toBe('indexedDb');
    expect(
      deriveFamilyStepState({
        ...base,
        authority: { ...legacy, state: 'postgres', epoch: 1 },
      })
    ).toBe('postgresUnverified');
  });

  it('reports verified only with a live passing verification', () => {
    expect(
      deriveFamilyStepState({
        ...base,
        authority: { ...legacy, state: 'postgres', epoch: 1 },
        verification: { verified: true } as never,
      })
    ).toBe('verified');
    expect(
      deriveFamilyStepState({
        ...base,
        authority: { ...legacy, state: 'postgres', epoch: 1 },
        verification: { verified: false } as never,
      })
    ).toBe('postgresUnverified');
  });

  it('reports a rollback and an inconsistency distinctly', () => {
    expect(
      deriveFamilyStepState({
        ...base,
        authority: { ...legacy, epoch: 2, rolledBack: true },
      })
    ).toBe('rolledBack');
    expect(
      deriveFamilyStepState({
        ...base,
        authority: { ...legacy, state: 'inconsistent', reason: 'epoch-disagreement' },
      })
    ).toBe('inconsistent');
  });
});
```

- [ ] **Step 3: Run both, watch them fail, implement, run again**

Run: `npx vitest run --project unit src/lib/durableDm/__tests__/familyRegistry.test.ts src/lib/durableDm/__tests__/migrationRunState.test.ts`

The precedence order inside `deriveFamilyStepState` is, as a sequence of early returns:

1. `notAvailable` — a planned entry, or `enabled === false`;
2. `inconsistent` — the normalizer blocked;
3. `blocked` — the manifest carries a blocker;
4. **routed authority states** — `postgres` (then `verified` or `postgresUnverified`), then `indexedDB`;
5. `rolledBack` — legacy with `rolledBack`;
6. `prepared` — `preparedState === 'CUTOVER_READY'` and the selection matches this run;
7. `selected` — the selection matches this run;
8. `legacy` — everything else.

Returning `legacy` as soon as the authority is legacy would make `selected` and `prepared` unreachable, because both are states a family occupies *while still legacy*. The authority check must therefore return early only for the routed and rolled-back states.

- [ ] **Step 4: Mutation-verify**

1. Drop the `selection.runId === runRecovery.runId` comparison — expect `ignores a selection left behind by an earlier run` to go red.
2. Make `verified` depend on the authority alone — expect `reports verified only with a live passing verification` to go red.
3. Filter planned entries out of `DURABLE_FAMILY_REGISTRY` — expect `lists the nine families in the roadmap order` to go red.
4. Make `registeredAdapters()` return `enabledAdapters()` — expect the disabled-family test to go red.

- [ ] **Step 5: Commit**

```bash
git add src/lib/durableDm/familyRegistry.ts src/lib/durableDm/migrationRunState.ts src/lib/durableDm/__tests__/familyRegistry.test.ts src/lib/durableDm/__tests__/migrationRunState.test.ts
git commit -m "feat: add the durable family registry and derived migration step state"
```

---

## Task 13b: Evidence-backed repair of a partially committed transition

**Spec:** R5b, added to the design for this task. This closes the gap that makes "resumable at every step" true rather than aspirational.

**Files:**
- Modify: `src/lib/durableDm/durableFamilyAdapter.ts` (adds `repairAuthority` to the interface), all six adapters (implement it), `src/lib/durableDm/adapters/__tests__/adapterConformance.ts`
- Create: `src/lib/durableDm/authorityRepair.ts`, `src/lib/durableDm/__tests__/authorityRepair.test.ts`

The interface method and its six implementations land in **one commit**, so no intermediate state has an adapter that cannot satisfy its own interface. Add to `DurableFamilyAdapter`:

```ts
  /**
   * Evidence-backed repair of a marker/pointer disagreement. The ONLY operation
   * permitted to resolve an `inconsistent` state, and it refuses unless the
   * surviving records prove which side is ahead.
   */
  repairAuthority(context: MigrationRunContext): Promise<NormalizedAuthority>;
```

**No wizard files are touched here.** Task 14 has not created them yet; the `inconsistent` step's repair control belongs to Task 15 and is listed there.

**The problem.** Advancing the IndexedDB pointer and writing the localStorage marker are two operations. A crash, a closed tab or a failed write between them leaves them disagreeing. Task 5 correctly refuses to guess, and `deriveFamilyStepState` reports `inconsistent` — but with no repair, that family is blocked forever and the DM has no way forward except a rollback they may not be able to reach.

**The rule: repair is permitted only when the surviving records prove which side is ahead.** `readAuthority` keeps reporting the disagreement; `repairAuthority` is the only operation allowed to resolve it, and it verifies before it writes.

| Observed | Meaning | Action |
|---|---|---|
| Pointer behind the marker (marker routed, pointer legacy) | The marker was written for a transition the pointer never made. No evidence the documents exist. | **Block.** Never write a pointer to match a marker. |
| Pointer ahead at `indexedDB`, marker legacy or absent | The local cutover committed and the marker write was lost. | Verify the prepared generation matches and every manifest document is present at that generation, then write the marker to `indexedDB` at the pointer's epoch. |
| Pointer ahead at `postgres`, marker at `indexedDB` or absent | Cloud activation committed and the marker write was lost. | Fetch `preview-enrollment`, require **`preview.epoch === pointer.epoch`** *and* exact document parity — legacy ids, fingerprints, schema versions, tombstones, count — against the local documents, then write the marker to `postgres` at the pointer's epoch. Parity alone is not enough: the same documents can exist at an epoch this device never reached. |
| Epoch disagreement in the same state | Ambiguous: could be either direction. | **Block.** |

The asymmetry is the point: a pointer is only ever advanced by an operation that also wrote the documents, so a pointer ahead is evidence. A marker is a cheap write with nothing behind it, so a marker ahead is not.

- [ ] **Step 1: Write the failing tests**

Written as a **parameterized suite**, exported from `adapterConformance.ts` beside `describeAdapterConformance` and called from all six adapter test files — never bound to one family's harness. Add `describeRepairConformance(name, createHarness)` and, in each of `campaignSettingsAdapter.test.ts` … `combatLogArchiveAdapter.test.ts`, one line: `describeRepairConformance('<family>', create<Family>Harness)`.

The six seeded states below extend `ConformanceHarness`; declare them there so the suite type-checks:

```ts
  /** Local cutover committed, marker write lost. */
  seedCutOverWithMarkerMissing(): Promise<MigrationRunContext>;
  /** Cloud activation committed, marker still at indexedDB. */
  seedCloudActiveWithMarkerAtIndexedDb(): Promise<MigrationRunContext>;
  /** Cloud holds these exact documents, but at a different epoch. */
  seedCloudActiveWithMatchingDocumentsAtAnotherEpoch(): Promise<MigrationRunContext>;
  /** Cloud is postgres but its documents differ from the local ones. */
  seedCloudActiveWithDivergedDocuments(): Promise<MigrationRunContext>;
  /** Marker routed, pointer still legacy. */
  seedMarkerAheadOfPointer(): Promise<MigrationRunContext>;
  /** Marker and pointer in the same state at different epochs. */
  seedEpochDisagreement(): Promise<MigrationRunContext>;
```

```ts
export function describeRepairConformance(
  name: string,
  createHarness: () => ConformanceHarness
) {
  it(`${name}: repairs a lost marker write after a local cutover`, async () => {
    const harness = createHarness();
    const context = await harness.seedCutOverWithMarkerMissing();
    expect(await harness.adapter.readAuthority(context)).toMatchObject({
      state: 'inconsistent',
    });

    expect(await harness.adapter.repairAuthority(context)).toMatchObject({
      state: 'indexedDB',
      epoch: 1,
    });
    expect(await harness.adapter.readAuthority(context)).toMatchObject({
      state: 'indexedDB',
      epoch: 1,
    });
  });

  it(`${name}: repairs a lost marker write after cloud activation, against the exact cloud preview`, async () => {
    const harness = createHarness();
    const context = await harness.seedCloudActiveWithMarkerAtIndexedDb();
    expect(await harness.adapter.repairAuthority(context)).toMatchObject({
      state: 'postgres',
      epoch: 1,
    });
  });

  it(`${name}: refuses to repair when the cloud epoch is not the pointer epoch`, async () => {
    const harness = createHarness();
    const context = await harness.seedCloudActiveWithMatchingDocumentsAtAnotherEpoch();
    await expect(harness.adapter.repairAuthority(context)).rejects.toThrow();
    expect(await harness.adapter.readAuthority(context)).toMatchObject({
      state: 'inconsistent',
    });
  });

  it(`${name}: refuses to repair when the cloud generation does not match the local documents`, async () => {
    const harness = createHarness();
    const context = await harness.seedCloudActiveWithDivergedDocuments();
    await expect(harness.adapter.repairAuthority(context)).rejects.toThrow();
    expect(await harness.adapter.readAuthority(context)).toMatchObject({
      state: 'inconsistent',
    });
  });

  it(`${name}: refuses to repair a pointer that is behind its marker`, async () => {
    const harness = createHarness();
    const context = await harness.seedMarkerAheadOfPointer();
    await expect(harness.adapter.repairAuthority(context)).rejects.toThrow();
    expect(await harness.pointerState()).toBe('localStorage');
  });

  it(`${name}: refuses to repair an epoch disagreement in the same state`, async () => {
    const harness = createHarness();
    const context = await harness.seedEpochDisagreement();
    await expect(harness.adapter.repairAuthority(context)).rejects.toThrow();
  });

  it(`${name}: leaves readAuthority reporting the disagreement until a repair succeeds`, async () => {
    const harness = createHarness();
    const context = await harness.seedMarkerAheadOfPointer();
    await expect(harness.adapter.repairAuthority(context)).rejects.toThrow();
    expect(await harness.adapter.readAuthority(context)).toMatchObject({
      state: 'inconsistent',
    });
  });
}
```

- [ ] **Step 2: Run, watch fail, implement, run again**

`authorityRepair.ts` holds the decision table as a pure function over `NormalizedAuthority['observed']` plus the verification callbacks; each adapter binds its own repository, marker writer and `preview-enrollment` call to it. No adapter reimplements the table.

- [ ] **Step 3: Mutation-verify**

1. Allow repair when the pointer is behind — expect `refuses to repair a pointer that is behind its marker` to go red.
2. Skip the `preview-enrollment` parity check — expect `refuses to repair when the cloud generation does not match the local documents` to go red.
2b. Drop the `preview.epoch === pointer.epoch` requirement — expect `refuses to repair when the cloud epoch is not the pointer epoch` to go red.
3. Let `readAuthority` prefer the pointer instead of reporting `inconsistent` — expect `leaves readAuthority reporting the disagreement until a repair succeeds` to go red.

- [ ] **Step 4: Commit**

```bash
git add src/lib/durableDm/durableFamilyAdapter.ts
git add src/lib/durableDm/authorityRepair.ts src/lib/durableDm/__tests__/authorityRepair.test.ts
git add src/lib/durableDm/adapters/
git commit -m "feat: repair a partially committed authority transition from surviving evidence"
```

---

## Task 14: Wizard shell — steps 0 and 1

**Spec:** R2a, R3, R4, R11, R12.

**Files:**
- Create: `src/components/ui/campaign/MigrationWizard/index.tsx`, `MigrationWizard.hooks.ts`, `MigrationWizard.types.ts`
- Create: `src/components/ui/campaign/MigrationWizard/steps/WorkspaceStep.tsx`, `steps/RecoveryStep.tsx`
- Test: `src/components/ui/campaign/MigrationWizard/MigrationWizard.test.tsx`

**Interfaces:**
- Consumes: `registeredAdapters`, `enabledAdapters` (Task 13), `isMigrationWizardVisible` (Task 2), `readVerifiedDownloadReceipt` (Task 3), `captureDeviceBackup` / `initiateDeviceBackupDownload` / `verifyDownloadedDeviceBackup` from `src/lib/deviceRecovery.ts`, `createBrowserDmWorkspace` (see the shipped cards for its import path).
- Produces: `useMigrationWizard(campaignCode: string)` returning the run controller, and `<MigrationWizard campaignCode={...} />`.

**Component rules:** `Dialog` from `@/components/ui/feedback/dialog`, `Button`, `Card`, `Badge`. Semantic tokens only. Keep `index.tsx` under ~150 lines by pushing every step into `steps/`. No `window.confirm` anywhere in this directory — a lint-visible grep is part of Task 21's checklist.

**Step 0** is read-only discovery: sign-in state, then the owner-verified workspace for `campaignCode`. It changes nothing — no selection, no marker, no pointer.

**Step 1** captures **one** `rollkeeper-device-backup` bundle for the whole device, downloads it, re-selects it, verifies every entry's byte count and SHA-256 plus the manifest hash, and stores one verified receipt. Every family step in the run references that receipt.

**Resume, on mount (spec R4):** re-capture the device bundle with a throwaway `runId`, compute its `manifestHash`, and call `readVerifiedDownloadReceipt(hash)`. A hit means this device already has a verified bundle for exactly this content: adopt the receipt's `runId` as the run's `runId` and skip step 1. A miss means step 1 runs. The hash covers entry content only — not `runId`, not `createdAt` — which is what makes this work.

- [ ] **Step 1: Write the failing tests**

```tsx
describe('MigrationWizard — steps 0 and 1', () => {
  it('renders nothing while the wizard flag is off', () => {
    process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE = 'false';
    const { container } = render(<MigrationWizard campaignCode="ALPHA" />);
    expect(container).toBeEmptyDOMElement();
  });

  it('discovery changes no authority, no marker and no selection', async () => {
    const before = await snapshotDurableState();
    render(<MigrationWizard campaignCode="ALPHA" />);
    await userEvent.click(screen.getByRole('button', { name: /find my campaigns/i }));
    await screen.findByText(/nothing has changed/i);
    expect(await snapshotDurableState()).toBe(before);
  });

  it('downloads and verifies exactly one bundle for the whole run', async () => {
    renderWizardAtRecoveryStep();
    await userEvent.click(screen.getByRole('button', { name: /download/i }));
    await userEvent.upload(screen.getByLabelText(/safety copy/i), bundleFile());
    // One initiated download, one user re-selection, one verified receipt.
    // `captureDeviceBackup` itself is deliberately NOT asserted at one call:
    // the wizard re-captures read-only before every authority transition to
    // detect drift, so its call count grows with the run.
    expect(initiateDeviceBackupDownload).toHaveBeenCalledTimes(1);
    expect(verifyDownloadedDeviceBackup).toHaveBeenCalledTimes(1);
    expect(await verifiedReceiptCount()).toBe(1);
  });

  it('refuses a bundle that does not match the current device', async () => {
    renderWizardAtRecoveryStep();
    await userEvent.click(screen.getByRole('button', { name: /download/i }));
    await userEvent.upload(screen.getByLabelText(/safety copy/i), staleBundleFile());
    expect(
      await screen.findByText(/does not match|download a fresh one/i)
    ).toBeInTheDocument();
    expect(screen.queryByRole('button', { name: /continue/i })).toBeDisabled();
  });

  it('resumes on a verified receipt for the same device content, without a second download', async () => {
    await seedVerifiedReceipt({ runId: 'run-1', manifestHash: currentDeviceHash() });
    render(<MigrationWizard campaignCode="ALPHA" />);
    expect(await screen.findByText(/safety copy is ready/i)).toBeInTheDocument();
    expect(initiateDeviceBackupDownload).not.toHaveBeenCalled();
  });

  it('does not resume on a verified receipt that predates the entry vector', async () => {
    // A receipt written before Task 3 has no per-entry hashes, so a drift stop
    // could not name the changed key. Either enrich it after proving the
    // aggregate hash still matches, or require a fresh bundle. Never resume on
    // it as-is.
    await seedVerifiedReceiptWithoutEntries({
      runId: 'run-1',
      manifestHash: currentDeviceHash(),
    });
    render(<MigrationWizard campaignCode="ALPHA" />);
    expect(await screen.findByRole('button', { name: /download/i })).toBeEnabled();
  });

  it('enriches a legacy receipt when the aggregate hash still matches, then resumes', async () => {
    await seedVerifiedReceiptWithoutEntries({
      runId: 'run-1',
      manifestHash: currentDeviceHash(),
    });
    render(<MigrationWizard campaignCode="ALPHA" />);
    await userEvent.click(screen.getByRole('button', { name: /check this device/i }));
    expect(await screen.findByText(/safety copy is ready/i)).toBeInTheDocument();
    expect(await storedReceiptEntries('run-1')).toHaveLength(currentEntryCount());
  });

  it('does not resume on a receipt that was downloaded but never verified', async () => {
    await seedInitiatedOnlyReceipt({ runId: 'run-1', manifestHash: currentDeviceHash() });
    render(<MigrationWizard campaignCode="ALPHA" />);
    expect(await screen.findByRole('button', { name: /download/i })).toBeEnabled();
  });

  it('renders every warning at a 390px viewport without truncation', async () => {
    setViewport(390);
    renderWizardAtRecoveryStep();
    for (const warning of screen.getAllByRole('alert')) {
      expect(warning.scrollWidth).toBeLessThanOrEqual(warning.clientWidth);
    }
  });
});
```

- [ ] **Step 2: Run, watch fail, implement, run again**

Run: `npx vitest run --project unit src/components/ui/campaign/MigrationWizard/MigrationWizard.test.tsx`

- [ ] **Step 3: Mutation-verify**

1. Remove the flag check from `index.tsx` — expect `renders nothing while the wizard flag is off` to go red.
2. Return a fresh `runId` from the resume path instead of the receipt's — expect `resumes on a verified receipt for the same device content, without a second download` to go red.
3. Change the resume lookup to `hasDownloadReceipt` — expect `does not resume on a receipt that was downloaded but never verified` to go red.

- [ ] **Step 4: Commit**

```bash
git add src/components/ui/campaign/MigrationWizard/
git commit -m "feat: add the migration wizard shell with device recovery"
```

---

## Task 15: Family steps

**Spec:** R3, R6, R11, R12, and the failure semantics section.

**Files:**
- Create: `src/components/ui/campaign/MigrationWizard/steps/FamilyStep.tsx`
- Modify: `MigrationWizard.hooks.ts`, `MigrationWizard.test.tsx`

Each family step shows the exact manifest (counts, bytes, blockers, references), requires the typed confirmation from `adapter.confirmation(...)`, then runs select → prepare → local cutover → cloud activate, and re-checks the device manifest hash before each authority transition.

- [ ] **Step 1: Write the failing tests**

```tsx
describe('MigrationWizard — family steps', () => {
  it('runs with zero, one and all families REGISTERED', async () => {
    // Registered, not enabled. Spec R13: progress is verified / registered, and
    // a registered family whose flag is off stays in the denominator.
    for (const count of [0, 1, 6]) {
      const { unmount } = renderWizardWithRegisteredAdapters(count);
      expect(await screen.findByText(new RegExp(`0 of ${count}`))).toBeInTheDocument();
      unmount();
    }
  });

  it('keeps a disabled registered family in the denominator', async () => {
    // Production registry: six registered, one enabled.
    disableAllFamiliesExcept('campaign_settings');
    renderWizardWithProductionRegistry();
    expect(await screen.findByText(/0 of 6/)).toBeInTheDocument();
    expect(screen.queryByText(/0 of 1/)).not.toBeInTheDocument();
  });

  it('cuts a family over only after the typed confirmation', async () => {
    renderWizardAtFamilyStep('campaign_settings');
    expect(screen.getByRole('button', { name: /switch this device over/i })).toBeDisabled();
    await userEvent.type(
      screen.getByLabelText(/type .* to confirm/i),
      confirmationPhraseFor('campaign_settings')
    );
    expect(screen.getByRole('button', { name: /switch this device over/i })).toBeEnabled();
  });

  it('reuses the one verified receipt across every family', async () => {
    await runWizardThroughFamilies(['campaign_settings', 'calendar']);
    expect(initiateDeviceBackupDownload).toHaveBeenCalledTimes(1);
    expect(verifyDownloadedDeviceBackup).toHaveBeenCalledTimes(1);
    expect(await verifiedReceiptCount()).toBe(1);
    expect(selectionRecoveryRunIds()).toEqual(['run-1', 'run-1']);
    // Read-only re-captures are expected and required: they are how drift is
    // detected before each authority transition.
    expect(captureDeviceBackup.mock.calls.length).toBeGreaterThan(1);
  });

  it('stops before the next authority transition when a captured key changes mid-run, and names it', async () => {
    await runWizardThroughFamilies(['campaign_settings']);
    mutateCapturedKey('rollkeeper-calendar-data');
    await advanceToFamily('calendar');
    expect(await screen.findByText(/rollkeeper-calendar-data/)).toBeInTheDocument();
    expect(await screen.findByText(/download a fresh/i)).toBeInTheDocument();
    expect(await authorityOf('calendar')).toMatchObject({ state: 'legacy' });
    expect(await authorityOf('campaign_settings')).toMatchObject({ state: 'postgres' });
  });

  it('leaves a skipped family byte-identical legacy and writes nothing for it', async () => {
    const before = await legacyKeySnapshot('rollkeeper-calendar-data');
    await runWizardSkipping('calendar');
    expect(await legacyKeySnapshot('rollkeeper-calendar-data')).toBe(before);
    expect(await selectionRecordFor('calendar')).toBeNull();
  });

  it('leaves family k on IndexedDB authority and k+1 untouched when the cloud fails', async () => {
    failCloudFor('magic_item');
    await runWizardThroughFamilies(['magic_item', 'npc']);
    expect(await authorityOf('magic_item')).toMatchObject({ state: 'indexedDB' });
    expect(await authorityOf('npc')).toMatchObject({ state: 'legacy' });
    expect(await screen.findByText(/on this device only/i)).toBeInTheDocument();
  });

  it('never rolls local authority back after a failed cloud activation', async () => {
    failCloudFor('magic_item');
    await runWizardThroughFamilies(['magic_item']);
    expect(screen.queryByText(/rolled back/i)).not.toBeInTheDocument();
    expect(await authorityOf('magic_item')).toMatchObject({ state: 'indexedDB', epoch: 1 });
  });

  it('closing between steps writes nothing for any unconfirmed family', async () => {
    const before = await snapshotDurableState();
    renderWizardAtFamilyStep('npc');
    await userEvent.click(screen.getByRole('button', { name: /close/i }));
    expect(await snapshotDurableState()).toBe(before);
  });

  it('resumes after a reload without cutting over or staging twice', async () => {
    await runWizardThroughFamilies(['campaign_settings']);
    const stagingCalls = countApiCalls('begin-staging');
    await reloadWizard();
    await advanceToFamily('campaign_settings');
    expect(countApiCalls('begin-staging')).toBe(stagingCalls);
    expect(await authorityOf('campaign_settings')).toMatchObject({ state: 'postgres', epoch: 1 });
  });

  it('blocks a family whose marker and pointer disagree, and continues to the next', async () => {
    await seedMarkerPointerDisagreement('npc');
    await advanceToFamily('npc');
    expect(await screen.findByText(/needs attention/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /continue/i })).toBeEnabled();
    // It never advances silently: the family stays inconsistent until repaired.
    expect(await authorityOf('npc')).toMatchObject({ state: 'inconsistent' });
  });

  it('offers an inconsistent family a repair control, and continues after it succeeds', async () => {
    await seedMarkerPointerDisagreement('npc');
    await advanceToFamily('npc');
    await userEvent.click(screen.getByRole('button', { name: /check this device and fix it/i }));
    expect(await screen.findByText(/fixed/i)).toBeInTheDocument();
    expect(await authorityOf('npc')).toMatchObject({ state: 'indexedDB' });
  });

  it('keeps an inconsistent family blocked when the repair refuses, and allows a skip', async () => {
    await seedMarkerAheadOfPointer('npc');
    await advanceToFamily('npc');
    await userEvent.click(screen.getByRole('button', { name: /check this device and fix it/i }));
    expect(await screen.findByText(/could not be fixed/i)).toBeInTheDocument();
    expect(await authorityOf('npc')).toMatchObject({ state: 'inconsistent' });
    expect(screen.getByRole('button', { name: /skip/i })).toBeEnabled();
  });

  it('renders a planned family as not yet available and offers no controls', async () => {
    await advanceToFamily('location');
    expect(await screen.findByText(/not yet available/i)).toBeInTheDocument();
    expect(screen.queryByLabelText(/type .* to confirm/i)).not.toBeInTheDocument();
  });
});
```

- [ ] **Step 2: Run, watch fail, implement, run again**

The drift check is the load-bearing part: before `selectFamily`, before `commitLocalCutover` and before `activateCloud`, re-capture the device bundle with the run's `runId` and compare its `manifestHash` to the receipt's. On a mismatch, diff the receipt's entry vector against the fresh capture to name the changed key, then stop. Do not record an exception, and do not touch the family's authority.

- [ ] **Step 3: Mutation-verify**

| Mutation | Expected red test |
|---|---|
| Move the bundle download and verification into the family loop instead of the run | `reuses the one verified receipt across every family` |
| Remove the pre-transition manifest re-check | `stops before the next authority transition when a captured key changes mid-run, and names it` |
| Persist the skip in `localStorage` | `leaves a skipped family byte-identical legacy and writes nothing for it` |
| Call `rollback` in the `activateCloud` catch | `never rolls local authority back after a failed cloud activation` |
| Continue to family k+1 inside the same try after a cloud failure | `leaves family k on IndexedDB authority and k+1 untouched when the cloud fails` |
| Enable the cutover button without the typed phrase | `cuts a family over only after the typed confirmation` |

- [ ] **Step 4: Commit**

```bash
git add src/components/ui/campaign/MigrationWizard/
git commit -m "feat: run each registered family through the migration wizard"
```

---

## Task 16: Verification and the final report

**Spec:** R8, R13, R14.

**Files:**
- Create: `src/components/ui/campaign/MigrationWizard/steps/ReportStep.tsx`
- Modify: `MigrationWizard.hooks.ts`

Each adapter's `verifyCloud` already exists from its own task. This task consumes them and adds the cross-family check. `verifyCloud` returns the `FamilyVerification` declared in Task 7 and is the definition of "verified" from spec R8: marker and pointer agree; cloud authority is `postgres` at the expected epoch; the document multiset matches exactly by `legacyId`, `payloadFingerprint`, **`schemaVersion`** and tombstone flag — the payload fingerprint does not cover the schema version, so identical bytes under a different schema version are a different document; record count matches; outbox settled (zero non-terminal entries); unresolved conflicts zero. The report adds the cross-family check: every recovery entry not owned by a migrated family still hashes to the value in the run's receipt.

- [ ] **Step 1: Write the failing tests**

```tsx
describe('MigrationWizard — report', () => {
  it('verifies on entry and again on Refresh, and never persists the result', async () => {
    await openReport();
    expect(verifySpy).toHaveBeenCalledTimes(enabledFamilyCount);
    await userEvent.click(screen.getByRole('button', { name: /refresh/i }));
    expect(verifySpy).toHaveBeenCalledTimes(enabledFamilyCount * 2);
    expect(await storedVerificationClaims()).toEqual([]);
  });

  it('re-verifies when the report is reopened', async () => {
    await openReport();
    await closeReport();
    await openReport();
    expect(verifySpy).toHaveBeenCalledTimes(enabledFamilyCount * 2);
  });

  it('ignores a stale verification response that lands after a newer one', async () => {
    const slow = deferVerification('npc');
    await openReport();
    await userEvent.click(screen.getByRole('button', { name: /refresh/i }));
    slow.resolve({ verified: false });
    expect(await screen.findByTestId('npc-status')).toHaveTextContent(/verified/i);
  });

  it('claims Fully migrated only when all six registered families are enabled, postgres and verified', async () => {
    await openReportWithAllSixMigratedAndVerified();
    expect(await screen.findByText(/fully migrated/i)).toBeInTheDocument();
  });

  it('claims only Available migrations complete when a registered family is disabled', async () => {
    disableFamily('combat_log_archive');
    await openReportWithEveryEnabledFamilyVerified();
    expect(await screen.findByText(/available migrations complete/i)).toBeInTheDocument();
    expect(screen.queryByText(/fully migrated/i)).not.toBeInTheDocument();
    expect(await screen.findByText(/combat log/i)).toBeInTheDocument();
  });

  it('refuses Fully migrated when one family is unverified, and names it', async () => {
    failVerificationFor('calendar');
    await openReportWithAllSixMigrated();
    expect(screen.queryByText(/fully migrated/i)).not.toBeInTheDocument();
    expect(await screen.findByText(/calendar/i)).toBeInTheDocument();
  });

  it('lists the planned families as not yet available and excludes them from the denominator', async () => {
    await openReportWithAllSixMigratedAndVerified();
    expect(await screen.findByText(/6 of 6/)).toBeInTheDocument();
    expect(await screen.findByText(/battle maps.*not yet available/i)).toBeInTheDocument();
  });

  it('counts settled outbox state, not an empty table', async () => {
    await openReportWithAcknowledgedOutboxRows();
    expect(await screen.findByTestId('npc-status')).toHaveTextContent(/verified/i);
  });

  it('counts unresolved conflicts only, and keeps preserved candidates recoverable', async () => {
    await openReportWithPreservedResolvedCandidate();
    expect(await screen.findByTestId('npc-status')).toHaveTextContent(/verified/i);
    expect(await preservedCandidateStillReadable()).toBe(true);
  });

  it('refuses verification when only the schema version differs', async () => {
    await openReportWithSchemaVersionDrift('calendar');
    expect(screen.queryByText(/fully migrated/i)).not.toBeInTheDocument();
    expect(await screen.findByTestId('calendar-status')).toHaveTextContent(/not verified/i);
  });

  it('reports an unrelated recovery entry whose bytes changed during the run', async () => {
    mutateCapturedKey('rollkeeper-player-data');
    await openReport();
    expect(await screen.findByText(/rollkeeper-player-data/)).toBeInTheDocument();
  });
});
```

- [ ] **Step 2: Run, watch fail, implement, run again**

Guard the async verification with an incrementing request token; discard a response whose token is not the newest. That is what `ignores a stale verification response` pins.

- [ ] **Step 3: Mutation-verify**

1. Cache the verification in module scope — expect `re-verifies when the report is reopened` to go red.
2. Compute the badge from `enabledAdapters()` instead of `registeredAdapters()` — expect `claims only Available migrations complete when a registered family is disabled` to go red.
3. Drop the request token — expect `ignores a stale verification response that lands after a newer one` to go red.
4. Drop the outbox-empty term from `verifyCloud` — expect the adapter conformance verification test to go red.

- [ ] **Step 4: Commit**

```bash
git add src/components/ui/campaign/MigrationWizard/ src/lib/durableDm/adapters/
git commit -m "feat: verify every migrated family and report the three completion claims"
```

---

## Task 17: Route and launcher

**Spec:** R2a.

**Files:**
- Create: `src/app/dm/migrate/[code]/page.tsx`, `src/app/dm/migrate/[code]/__tests__/page.test.tsx`
- Modify: `src/app/dm/page.tsx`

**Read first:** `node_modules/next/dist/docs/` for this Next.js version's route and params conventions. They differ from older releases; do not write the route from memory.

The route sits outside `src/app/dm/campaign/[code]/layout.tsx`, so **no durable-family owner is mounted while the wizard runs**. That is the whole point: a cutover committed under a mounted card would leave that card with `authority` null and `hydrated` false while the aware storage froze the legacy key — the silent-loss shape of backport defects 1 and 3.

- [ ] **Step 1: Write the failing tests**

```tsx
describe('/dm/migrate/[code]', () => {
  it('is a 404 while the flag is off, even by direct navigation', async () => {
    process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE = 'false';
    expect(await renderRoute('ALPHA')).toMatchObject({ notFound: true });
  });

  it('mounts no durable family sync provider', async () => {
    process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE = 'true';
    await renderRoute('ALPHA');
    expect(npcProviderMounted()).toBe(false);
    expect(encounterProviderMounted()).toBe(false);
    expect(combatLogArchiveProviderMounted()).toBe(false);
  });

  it('replaces into the campaign route on close once anything was cut over', async () => {
    await renderRouteAfterCutover('ALPHA');
    await userEvent.click(screen.getByRole('button', { name: /close/i }));
    expect(routerReplace).toHaveBeenCalledWith('/dm/campaign/ALPHA');
  });

  it('returns to the dashboard when nothing was cut over', async () => {
    // Closing the dialog must still leave the route: a closed dialog on
    // /dm/migrate/[code] is a blank page.
    await renderRoute('ALPHA');
    await userEvent.click(screen.getByRole('button', { name: /close/i }));
    expect(routerReplace).toHaveBeenCalledWith('/dm');
  });

  it('reopens and re-derives progress after a reload', async () => {
    await renderRouteAfterCutover('ALPHA');
    await reloadRoute('ALPHA');
    expect(await screen.findByText(/1 of 6/)).toBeInTheDocument();
  });
});
```

And in the dashboard test file:

```tsx
it('shows the migration launcher only while the wizard flag is on', () => {
  process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE = 'false';
  const { rerender } = render(<DmDashboardPage />);
  expect(screen.queryByRole('link', { name: /migrate/i })).not.toBeInTheDocument();
  process.env.NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE = 'true';
  rerender(<DmDashboardPage />);
  expect(screen.getByRole('link', { name: /migrate/i })).toHaveAttribute(
    'href',
    '/dm/migrate/ALPHA'
  );
});
```

The `replace` on close is what guarantees fresh owners mount before editable campaign UI returns.

- [ ] **Step 2: Run, watch fail, implement, run again**

- [ ] **Step 3: Mutation-verify**

1. Remove the route's own flag check, keeping only the launcher's — expect `is a 404 while the flag is off, even by direct navigation` to go red.
2. Change `replace` to `push` — expect `replaces into the campaign route on close once anything was cut over` to go red (assert the call, not the history depth).
3. Send both close paths to `/dm` — expect `replaces into the campaign route on close once anything was cut over` to go red. The cutover path must reach the campaign route so fresh owners mount before editable campaign UI returns.

- [ ] **Step 4: Commit**

```bash
git add src/app/dm/migrate/ src/app/dm/page.tsx
git commit -m "feat: serve the migration wizard from a route outside the campaign providers"
```

---

## Task 18: Dashboard hardening for migrated campaigns

**Spec:** R2b. This closes a hole the wizard would otherwise open.

**Files:**
- Modify: `src/app/dm/page.tsx`
- Test: the dashboard's test file (`grep -rl "DmDashboardPage" src/app/dm/`)

**The two holes, verified against source:**

1. `bannerUrl` is in `CAMPAIGN_SETTINGS_FAMILY_INVENTORY.privateFields`. Once `campaign_settings` is routed, `createCampaignSettingsAwareDmStorage` restores the previous value on every `rollkeeper-dm-data` write, so a banner upload from `/dm` is accepted by the UI and silently reverted — and no IndexedDB owner is mounted on `/dm` to commit it instead.
2. The aware storage only restores fields on campaigns present in the *next* envelope. `removeCampaign` drops a routed campaign from legacy entirely while its IndexedDB documents, its Postgres rows and its authority marker all survive. That is an orphan, not a delete.

- [ ] **Step 1: Write the failing tests**

```tsx
describe('DM dashboard — migrated campaigns', () => {
  it('offers no banner upload for a campaign whose settings are routed', async () => {
    seedRoutedCampaignSettings('ALPHA');
    render(<DmDashboardPage />);
    expect(within(campaignCard('ALPHA')).queryByLabelText(/banner/i)).not.toBeInTheDocument();
  });

  it('offers no legacy delete for a campaign whose settings are routed', async () => {
    seedRoutedCampaignSettings('ALPHA');
    render(<DmDashboardPage />);
    expect(within(campaignCard('ALPHA')).queryByRole('button', { name: /delete/i })).not.toBeInTheDocument();
  });

  it('links into the campaign-owned UI instead', async () => {
    seedRoutedCampaignSettings('ALPHA');
    render(<DmDashboardPage />);
    expect(within(campaignCard('ALPHA')).getByRole('link', { name: /manage/i })).toHaveAttribute(
      'href',
      '/dm/campaign/ALPHA'
    );
  });

  it('performs no dmStore mutation for a migrated campaign', async () => {
    seedRoutedCampaignSettings('ALPHA');
    const before = localStorage.getItem('rollkeeper-dm-data');
    render(<DmDashboardPage />);
    await userEvent.click(campaignCard('ALPHA'));
    expect(localStorage.getItem('rollkeeper-dm-data')).toBe(before);
  });

  it('keeps the controls hidden when the family flag is turned off after migration', async () => {
    seedRoutedCampaignSettings('ALPHA');
    process.env.NEXT_PUBLIC_CAMPAIGN_SETTINGS_SYNC_VISIBLE = 'false';
    render(<DmDashboardPage />);
    expect(within(campaignCard('ALPHA')).queryByLabelText(/banner/i)).not.toBeInTheDocument();
    expect(
      within(campaignCard('ALPHA')).queryByRole('button', { name: /delete/i })
    ).not.toBeInTheDocument();
  });

  it('returns the controls for a campaign that was rolled back', async () => {
    seedRolledBackCampaignSettings('ALPHA'); // marker authority: 'legacy_restored'
    render(<DmDashboardPage />);
    expect(within(campaignCard('ALPHA')).getByLabelText(/banner/i)).toBeInTheDocument();
    expect(
      within(campaignCard('ALPHA')).getByRole('button', { name: /delete/i })
    ).toBeInTheDocument();
  });

  it('leaves the controls of an unmigrated campaign exactly as they were', async () => {
    seedRoutedCampaignSettings('ALPHA');
    render(<DmDashboardPage />);
    expect(within(campaignCard('BETA')).getByLabelText(/banner/i)).toBeInTheDocument();
    expect(within(campaignCard('BETA')).getByRole('button', { name: /delete/i })).toBeInTheDocument();
  });
});
```

The last test is the one that keeps this change scoped: nothing changes for a DM who has not migrated.

- [ ] **Step 2: Run, watch fail, implement, run again**

**Do not gate on `readCampaignSettingsProjectionAuthority`.** It returns `null` whenever the `campaign_settings` client flag is off, so turning that flag off after a campaign had migrated would silently hand the unsafe banner and delete controls back — on a campaign whose documents live in IndexedDB and whose legacy envelope the family no longer reads from. The hardening must not depend on current visibility.

Read the marker key directly instead, with its own small parser, independent of any flag:

```ts
/**
 * Deliberately flag-independent, and note WHY.
 *
 * While the family flag is off, `campaignSettingsUsesIndexedDbAuthority` reads
 * through the flag-gated marker reader, returns false, and the aware storage
 * passes the write through — so legacy writes are NOT frozen while the flag is
 * off. That is the hazard, not the protection: those writes land in the legacy
 * envelope that the family no longer reads from, and the moment the flag is
 * re-enabled the campaign is authoritative from IndexedDB again and the edits
 * made in between are invisible. So the dashboard must hide these controls for
 * any campaign that is CURRENTLY ROUTED, whatever the flag says. Currently
 * routed means `indexedDB` or `postgres`; a rolled-back campaign carries
 * `legacy_restored` and is editable again by design.
 */
function campaignSettingsRouted(campaignCode: string): boolean {
  try {
    const raw = localStorage.getItem(
      `rollkeeper:campaign-settings-projection-authority:${campaignCode}`
    );
    if (!raw) return false;
    const marker = JSON.parse(raw) as { authority?: string };
    return marker.authority === 'indexedDB' || marker.authority === 'postgres';
  } catch {
    return false;
  }
}
```

**Currently routed, not "ever migrated".** The predicate matches `indexedDB` and `postgres` only. A campaign that was rolled back carries `legacy_restored`, and that is deliberately editable again: rollback exists to hand the family back to legacy storage, so the dashboard's controls are safe for it and must return. A campaign with no marker is untouched, so a device that never migrated is byte-identical to today — which is what the unmigrated-campaign test pins.

- [ ] **Step 3: Mutation-verify**

1. Remove the routed check from the banner branch — expect `offers no banner upload for a campaign whose settings are routed` to go red.
2. Apply the gate to every campaign regardless of its marker — expect `leaves the controls of an unmigrated campaign exactly as they were` to go red.
3. Replace the direct marker read with `readCampaignSettingsProjectionAuthority` — expect `keeps the controls hidden when the family flag is turned off after migration` to go red.
4. Widen the predicate to "any marker at all" — expect `returns the controls for a campaign that was rolled back` to go red.

- [ ] **Step 4: Commit**

```bash
git add src/app/dm/page.tsx
git commit -m "fix: stop the DM dashboard writing campaign settings a migrated campaign no longer owns"
```

---

## Task 19: Manual-gate seed and checklist

**Files:**
- Modify: `.agents/skills/rollkeeper-manual-browser/scripts/` (the seed generator) and `.agents/skills/rollkeeper-manual-browser/references/` (the checklist)
- Do **not** edit `.agents/skills/rollkeeper-manual-browser/SKILL.md` or `AGENTS.md` — those are Codex's harness instructions.

`.claude/skills/rollkeeper-manual-browser/` holds only a `SKILL.md`; the seed and checklist assets it points at live under `.agents/`, and both harnesses share them. Editing anything under `.claude/skills/` for this task would create a second, divergent copy.

- [ ] **Step 1: Extend the seed to cover all six families**

Today's seed is single-family. 11G needs one deterministic device carrying legacy data for `campaign_settings`, `calendar`, `magic_item`, `npc`, `encounter_definition` and `combat_log_archive` at once, plus at least one unrelated `rollkeeper-*` key that must stay byte-identical, and **two campaigns whose records interleave** so Task 1's fixpoint property is exercised by hand as well.

Close the gap 11F's gate recorded: seed encounters that match the combat log archives' `encounterId`s, so archive rows render real names instead of the "Untitled combat" fallback.

Print the manifest: entry count, total bytes, manifest hash prefix. The gate quotes those numbers.

- [ ] **Step 2: Add the §11G scenarios to the shared checklist**

Three origins: participating devices **A** and **B**, plus a separate default-off control origin.

1. Full run end to end on A: every enabled family, one bundle, one download, one verification.
2. **On B, first enroll and apply each family through its existing card** — enrollment is deliberately absent from the adapter — then open the wizard and check the verification report.
3. One family skipped in the wizard, then migrated later from its own card.
4. One forced cloud failure at family *k*: *k* stays on this device, *k+1* untouched, nothing rolled back.
5. One rollback after completion, from the family's own card.
6. Default-off control origin: no launcher, no route, no `rollkeeper-local`, no `rollkeeper:` markers.
7. Re-drive 11F's blocked path — enroll → apply exact cloud version → delete → reload — and the backport's second-device path. Record them under 11G, not as implied by the wizard.

Record the trap already proven twice: an unauthenticated `POST` to a family route returns **403 whether the flag is on or off**, because membership validation runs before the flag check. Default-off evidence rests on card and route absence and on absent IndexedDB/markers, never on a status code.

- [ ] **Step 3: Commit**

Stage the exact files you changed, by name — never the directory, and never its `SKILL.md`:

```bash
git status --short .agents/skills/rollkeeper-manual-browser/
git add .agents/skills/rollkeeper-manual-browser/scripts/<the seed script you changed>
git add .agents/skills/rollkeeper-manual-browser/references/<the checklist you changed>
git commit -m "test: seed all six durable families for the manual migration gate"
```

---

## Task 20: Automated gate matrix and evidence

- [ ] **Step 1: Run the full matrix and record every result**

Stop only the servers this run started — record their PIDs when you launch them and `kill` those. A broad `pkill -f "next dev"` would kill a dev server the user is running for their own work.

```bash
npm run type-check
npm run lint:ci
npm run format:ci
npm run test:ci-tools
npm run test
npm run test:slice8:coverage && npm run test:slice9:coverage
npm run test:slice10a1:coverage && npm run test:slice10a2:coverage && npm run test:slice10b:coverage
npm run test:slice11a:coverage && npm run test:slice11b:coverage && npm run test:slice11c:coverage
npm run test:slice11d:coverage && npm run test:slice11e:coverage && npm run test:slice11f:coverage
npm run test:slice11g:coverage
npm run build
npm run test:visual
npm run test:e2e && npm run test:indexeddb:e2e && npm run test:automatic-sync:e2e && npm run test:auth:e2e
npm run db:lint && npm run db:test && npm run db:types:check
```

`db:test` needs a clean local database. **Do not run `npm run db:reset`.** 11G changes zero SQL, so if pgTAP fails, prove it environmental with `git diff master...HEAD -- supabase/ '*.sql'` returning empty, and report it blocked — never passed.

- [ ] **Step 2: Grep for the two forbidden patterns**

```bash
grep -rn "window.confirm" src/components/ui/campaign/MigrationWizard/ src/app/dm/migrate/ && echo "FAIL: spec R12"
grep -rEn "bg-(gray|white|black|slate)-|text-(gray|white|black|slate)-" src/components/ui/campaign/MigrationWizard/ src/app/dm/migrate/ && echo "FAIL: raw colours"
```

Both must produce no output.

- [ ] **Step 3: Write `SLICE_11G_EVIDENCE.md`**

Git-ignored, local, and it must already hold Task 0's preflight and every mutation transcript from Tasks 1–18. Add: what shipped, the numbered rulings with any that changed during execution, files changed, the command-to-result table, and an honest limitations section. Anything not exercised is recorded as **not exercised** — never as passed, never as skipped.

Repeat the coverage caveat verbatim: `test:slice11g:coverage` measures `src/lib/**` only and is not evidence for the wizard component's guards.

- [ ] **Step 4: Commit**

This task normally produces **no tracked commit**: `SLICE_11G_EVIDENCE.md` is git-ignored, and the matrix should not change source. Never use `git add -u` — it stages every modified tracked file, including unrelated work in the user's tree, and it contradicts the explicit-path rule.

If a run genuinely required a source fix, commit only that file by name:

```bash
git status                       # confirm what changed and why
git add <the exact file you fixed>
git commit -m "fix: <what the gate matrix caught>"
```

---

## Task 21: Manual browser gate (BLOCKING — requires the user)

**Spec:** R16 phase 2. Run only after Task 20 is green.

- [ ] **Step 1: Revalidate both sessions**

Ask the user to confirm both origins are still signed in as the synthetic owner. A local database reset or a token expiry since Task 0 means signing in again. **If reauthentication is unavailable, 11G is blocked** — not complete, not merge-ready. Say so plainly and stop.

- [ ] **Step 2: Run the §11G checklist from Task 19**

Claude Code's Chrome integration only, per `CLAUDE.md`; the Codex pass uses the Codex desktop in-app Browser, per `AGENTS.md`. Never Playwright, Storybook or headless Chromium as a substitute. New tabs on synthetic origins only; never read, reuse or clear the user's real tabs, cookies, storage or accounts.

Known environment quirk from two prior gates: ref-targeted clicks may not reach React handlers; screenshot-space coordinate clicks do. Page JavaScript is for seeding, reading durable state and hashing — never for driving the behaviour under test, and **never for suppressing the application's real persistence behaviour**. A download or a storage write that the app performs must be allowed to happen; suppressing it means the gate no longer observes what ships. Point the browser's download directory somewhere disposable instead.

- [ ] **Step 3: Record the verdict honestly**

Passed, partial or blocked, with every unexercised scenario named. Two prior slices in this program were reported BLOCKED/PARTIAL; a third would be a pattern worth stating outright in the PR body.

- [ ] **Step 4: Stop**

Do not merge, do not open a PR without explicit approval. Per `CLAUDE.md`, keep the PR body to outcome, essential design changes, checks run, and unresolved risks.

---

## Self-review

**Spec coverage:** R1 → Tasks 7–12. R2a → Task 17; R2b → Task 18. R3 → Tasks 1 and 15. R4 → Tasks 3 and 14. R5 → Tasks 5, 12 and 13b. R6 → Tasks 13 and 13b. R7 → Tasks 4, 6, and the resume test in Task 15. R8 → each adapter's `verifyCloud` (Tasks 7–12) and the report in Task 16. R9 → the Global Constraints and Task 20's `git diff` check. R10 → Task 7's conformance test, inherited by Tasks 8–12. R11 → Task 15. R12 → Tasks 7 and 15. R13 → Tasks 13 and 16. R14 → Task 16. R15 → Tasks 2, 7 and 19. R16 → Tasks 0 and 21.

**Type consistency:** `FamilyVerification` is declared once, in `durableFamilyAdapter.ts` (Task 7), and consumed by Tasks 13 and 16. `NormalizedAuthority` is declared in Task 5 and consumed by Tasks 7–13. `ResumableActivationResult` is declared in Task 6 and returned by every adapter's `activateCloud`. `MigrationCloudOperation` is declared in Task 4 and consumed by Task 6.

**Known soft spot:** Tasks 8–12 give each adapter its symbol row, its divergences and its own tests, but not a full second copy of the reference implementation. Two things carry that weight: the instruction to read the shipped card and copy each step's argument object verbatim, and the mandatory card/adapter step-parity test in step 6 of those tasks, which compares the two traces mechanically. A reviewer should still check each adapter against its card argument by argument before approving it — the parity test proves the traces match, not that the trace itself is right.
