# Handoff: Campaign cloud migration wizard (Slice 11G)

## Overview

A guided, whole-device migration wizard for RollKeeper's DM side: it walks a DM
through moving one campaign's data categories out of browser-only storage and
into cloud sync, one category at a time, behind a single verified browser
backup.

### Naming (user-facing vs internal)

The UI copy in this design follows a fixed vocabulary. Internal identifiers keep
the engineering names; **only the user-facing words changed.**

| Internal (keep in code) | User-facing (use in UI copy) |
|---|---|
| device | **this browser** |
| family | **data category** / **campaign data** |
| whole-device migration | **campaign cloud migration** (never "whole-device") |
| \`deliveries\` → rename to \`player_deliveries\` | **Player inbox** |
| \`verified\`, "fully migrated" | **All campaign data is synced** (technical status stays internal) |

The wizard title is **"Move campaign data to cloud sync"** and its safety step is
**"Back up this browser"**.

Note for the test suite: several Task 14–15 tests assert on the old strings
(\`/switch this device over/i\`, \`getByLabelText(/safety copy/i)\`,
\`/check this device and fix it/i\`). Those queries need updating alongside the
copy — the guards they protect are unchanged.

This design covers the UI half of the plan in
`docs/superpowers/specs/2026-08-24-slice-11g-migration-wizard-design.md` and its
implementation plan (Tasks 14–18): the wizard shell, steps 0 and 1, the family
steps, the final report, the route chrome, and the hardened DM dashboard.

## About the design files

The files in this bundle are **design references created in HTML** — prototypes
showing intended look and behaviour, **not production code to copy**. They are
authored as single self-contained streaming components with inline styles, which
is not how RollKeeper is built.

The task is to **recreate these designs inside RollKeeper's existing
environment**: Next.js App Router + React 19 + Tailwind CSS 4 with the semantic
token utilities from `src/app/globals.css`, the CVA variants in
`src/components/ui/primitives/variants.ts`, the `Dialog` primitives in
`src/components/ui/feedback/dialog.tsx`, and `lucide-react` icons. Every colour,
size and radius in this document was lifted from those files, so in the real
implementation you should almost always be writing the **token class** rather
than the hex value (e.g. `bg-accent-amber-bg`, not `#fffbeb`). The hex values
below are given so you can confirm a match, and because the prototype could not
use Tailwind.

## Fidelity

**High-fidelity.** Colours, typography, spacing, radii, component structure and
copy are final and were derived from the repository's own design system. Recreate
the UI faithfully using the existing components — do not introduce new colours,
new button variants, or a new dialog.

Two deliberate deviations from a "pixel-perfect copy" instruction:

1. The prototype renders light theme only. The real implementation gets dark and
   parchment for free by using the semantic token utilities.
2. The prototype's dashed **"Design states"** strip at the top of the wizard file
   is a review affordance for walking the edge cases. **It is not part of the
   product** and must not be implemented.

## Files in this bundle

| File | What it is |
|---|---|
| `Cloud Migration Wizard.dc.html` | The wizard: route chrome, dialog shell, step rail, all four step kinds, all edge states, final report. The primary deliverable. |
| `DM Dashboard.dc.html` | Recreation of the existing `/dm` dashboard showing where the wizard is launched from, and the Task 18 hardening for a cloud-owned campaign. |
| `src/app/fonts/geist-latin.woff2`, `geist-mono-latin.woff2` | The app's own font files, copied so the prototype matched. The real app already loads these via `next/font/local` in `src/app/layout.tsx` — do not add them again. |

Open either file directly in a browser. In the wizard, the top strip jumps
between every state documented under "Edge states" below.

## Where this lives in the app

Per Task 17 / ruling R2a, the wizard is served from **`/dm/migrate/[code]`**,
deliberately **outside** `src/app/dm/campaign/[code]/layout.tsx`, so no durable
family sync provider is mounted while a cutover commits. The route and the
dashboard launcher are gated **independently** on
`NEXT_PUBLIC_MIGRATION_WIZARD_VISIBLE === 'true'`; the route must 404 when the
flag is off, even by direct navigation.

On close: `router.replace('/dm/campaign/<code>')` when anything was cut over
(so fresh owners mount before editable campaign UI returns), otherwise
`router.replace('/dm')`. A closed dialog on this route would be a blank page, so
closing must always leave the route.

---

## Screen 1 — Route chrome (`/dm/migrate/[code]`)

**Purpose:** frame the wizard and make it obvious that campaign screens are not
running underneath it.

**Layout:** `min-h-screen bg-surface`. A header identical in structure to the DM
dashboard's — `border-b border-divider bg-surface-secondary shadow-sm`, inner
`max-w-7xl px-4 sm:px-6 lg:px-8`, row `h-16 flex items-center justify-between`.
Below the header, the dialog overlay fills the viewport.

**Header components (left to right):**

- Ghost `Button` `size="sm"`, `leftIcon={<ArrowLeft size={20} />}`, label
  "Back to campaigns".
- 24px `CloudCog` icon in `text-purple-600 dark:text-purple-400` (matching the
  dashboard's `Crown`), then `<h1 class="text-heading text-xl font-bold">Campaign cloud
  migration</h1>`, then the campaign code as `<Badge variant="info"
  className="font-mono tracking-wider">` — exactly the dashboard's code badge.
- Right side, `text-muted text-xs` with a 14px `Lock` icon: "Campaign screens
  are closed while this runs".

**Overlay:** `bg-black/50 backdrop-blur-sm` (the `DialogOverlay` default),
padding `40px 24px`.

## Screen 2 — The wizard dialog

Use `DialogContent` with `size="lg"` (`max-w-4xl`, 896px). Its own defaults give
you `rounded-xl border-2 border-divider bg-surface-raised p-6 shadow-2xl
max-h-[90vh] flex flex-col gap-4` and the 44×44 close button at `top-4 right-4`.
Do not restyle it.

### Dialog header

- `DialogTitle`: "Move campaign data to cloud sync"
  (`text-heading text-xl font-semibold tracking-tight`; the prototype renders
  20px/600).
- `DialogDescription`: "One data category at a time, with a backup of this browser first. Nothing
  moves until you confirm it, and you can stop after any category."
- Reserve `padding-right: 48px` so the title clears the close button.

### Body: two columns

`display: flex; gap: 20px; align-items: stretch`.

**Left — the run rail.** Fixed `width: 252px`, `border border-divider
bg-surface-secondary rounded-lg p-3`, rows `gap: 2px`.

- Eyebrow: "This run" — `text-muted`, 11px, weight 700, letter-spacing 0.06em,
  uppercase, `padding: 0 6px`, 6px bottom margin.
- One row per step, as a button (rows are clickable and jump to the step):
  `display: flex; align-items: center; gap: 8px; padding: 7px 6px; border-radius: 6px`.
  - 8px status dot, `border-radius: 9999px`:
    done `#059669` (emerald-600) · on this device only `#2563eb` (blue-600) ·
    current `#b45309` (amber-700) · not started `#cbd5e1` (divider).
  - Label 13px, truncated with ellipsis. Current step: weight 600 and the row
    gets `bg-surface-raised`; not-started steps use `text-body`, everything else
    `text-heading`.
  - Trailing status word, 11px: "now" / "found" / "saved" / "cloud" / "device" /
    "off". Colour: done `#047857`, device `#1d4ed8`, current `#b45309`.
- Row order: **Your account**, **Browser backup**, then the six registered categories
  in the plan's fixed order — Campaign settings, Calendar, Magic items, NPCs,
  Encounters, Combat logs — then **Result**.
- Below a `border-t border-divider` with 10px padding: an 11px `text-faint`
  "Not yet available" label, then the three planned categories (Locations, Battle
  maps, Player inbox) as non-interactive rows — 13px `text-faint`, hollow dot
  (1px `#cbd5e1` border, white fill).

**Right — the step body.** `flex: 1; min-width: 0`, `gap: 16px` column. Every
step body opens with the same header row: `display: flex; align-items:
flex-start; justify-content: space-between; gap: 12px` holding an eyebrow +
title on the left and a status `Badge` on the right.

- Eyebrow: 11px, weight 700, 0.06em, uppercase, `text-muted` —
  "Step 1 of 3 · Account", "Step 2 of 3 · Backup",
  "Category 4 of 6 · NPCs", "Step 3 of 3 · Result".
- Title: 18px weight 600 `text-heading`.

### Dialog footer

`border-t border-divider`, 16px top padding, `flex items-center
justify-between gap-16px`.

- Left: a 132×6px progress track (`bg-surface-inset`, `rounded-full`) with an
  emerald-600 fill at `verified / 6`, then 13px `text-body`
  "N of 6 categories synced", and under it 12px `text-faint`
  "Categories still count here even when a build has them switched off."
  (Ruling R13: the denominator is **registered** adapters, not enabled ones.)
- Right: ghost "Back"; outline "Skip this one" (only on an unfinished category
  step); primary "Continue" with a trailing `ChevronRight size={16}`. The
  primary label becomes "Start with settings" on the backup step, "Next
  category" once the current family is verified, and "Done" on the report. It is
  **disabled** until the run has a verified or resumed recovery receipt.

---

## Step 0 — Your account (read-only discovery)

Badge: `neutral`, "Reads only".
Title: "Find where this campaign will live".

1. A `Card`-equivalent panel (`border border-divider bg-surface-raised rounded-lg
   p-4`, 12px gap):
   - Row 1: 18px `ShieldCheck` in `--accent-emerald-text-muted` (#047857) +
     "Signed in on this browser" (14px/500 `text-heading`), and a `success`
     badge "Ready" on the right. Never render the account's email address.
   - `border-t border-divider`, 12px padding: the workspace line
     ("Northwatch — your campaign workspace" / before lookup: "We have not
     looked yet") 14px/500, a 13px `text-muted` sub-line ("Campaign ALPHA7 will
     move into this workspace." / "One lookup finds the workspace this campaign
     belongs to."), and on the right an outline `Button size="sm"` with
     `RefreshCw size={14}` labelled **"Find my campaigns"**.
2. A reassurance card — `border-accent-emerald-border bg-accent-emerald-bg`,
   `rounded-lg`, `p-3`, 16px `CircleCheckBig` + 13px
   `text-accent-emerald-text`: "Nothing has changed. Looking up your account does
   not move data, change what this browser reads from, or touch your campaign."

Ruling R2a: this step must write **no** selection, marker or pointer. The test
`discovery changes no authority, no marker and no selection` asserts it, and the
"Nothing has changed" line is the user-facing half of that promise.

## Step 1 — Back up this browser (one verified bundle per run)

Badge reflects receipt state: "Needed" (`warning`), "Checked" (`success`),
"Picked back up" (`success`), "Not usable" (`danger`).
Title: "Back up this browser".
Lede (14px `text-body`): "One file covers the whole run — every data category below
reuses it. Download it, then pick it back up so we can check it arrived intact."

**Pending state** — one `border border-divider bg-surface-raised rounded-lg p-4`
card with two rows separated by a divider:

- "1 — Download the file" (14px/500) with "31 entries · 2.1 MB · everything this
  browser holds for RollKeeper" beneath it in 13px `text-muted`; on the right a
  `warning` `Button` with `Download size={16}`: **"Download backup"**.
- "2 — Pick your backup file back up" as a `<label>` for the file input. The
  input is a 40px-high `border-2 border-dashed border-divider bg-input-bg
  rounded-lg` drop target with an upload glyph and either "Choose the file you
  just downloaded" or the chosen filename. Beside it, an outline button
  **"Check it"**, disabled until a file is chosen.
  The accessible name must contain "safety copy" — the Task 14 tests query
  `getByLabelText(/safety copy/i)`.

**Verified state** — emerald card: "Checked — every entry matches", then a
three-column grid of Entries / Size / Receipt (11px uppercase
`--accent-emerald-text-muted` labels over 15px/700 `--accent-emerald-text`
values), then a 12px mono line "manifest 9f3c41ab…7a1b · sha-256 checked per
entry".

**Resumed state** — emerald card with an 18px `FileCheck` icon: "Your safety copy
is ready" / "This browser's data still matches the copy you checked earlier, so
we picked that run back up instead of asking for another download." / mono
"run-1 · verified 15:41 · manifest 9f3c41ab…7a1b". No download button is
rendered — the Task 14 test asserts `initiateDeviceBackupDownload` was never
called on this path.

**Stale-file state** — `role="alert"` red card with an 18px `TriangleAlert`:
"That file does not match this browser" / "It was saved from different data, so
it could not restore this device. Download a fresh one and pick that up
instead." Continue stays disabled.

Only receipts that are **verified** may resume, and a receipt with no per-entry
vector must not resume as-is (Task 14). If you surface the "enrich a legacy
receipt" path, the control is labelled **"Check this device"**.

## Steps 2–7 — One per registered data category

Badge, by state: "On this browser" (`neutral`) → "This browser only" (`secondary`
blue) → "Synced" (`success`); "Waiting on you" / "Stopped" (`warning`);
"Needs attention" (`danger`).

Title: "Move NPCs to cloud sync", or "NPCs are done" once verified.

**Manifest card** — `border border-divider bg-surface-raised rounded-lg`,
`overflow: hidden`, a three-column grid with 1px dividers between cells, each
cell `padding: 14px 16px`: an 11px uppercase `text-muted` label over an 18px/700
`text-heading` value.

- **Items** — `manifest.recordCount`
- **Size** — `manifest.totalBytes`, humanised
- **Linked to** — a plain-English summary of `records[].references`
  ("Encounters", "NPC inventories", "Nothing")

Beneath, on `bg-surface-secondary` with a top divider, a 12px mono detail line:
`npc · fingerprint 9f3c41…7a1b · 27 documents · 421,888 bytes`. The fingerprint
shown **must** be `manifest.fingerprint` — the same value
`adapter.confirmation()` returns, per the conformance test.

**Stage chain** — four equal cards in a row, `gap: 8px`, each `border rounded-lg`
`padding: 10px 12px`, holding an 11px uppercase state word over a 13px/500 label:
**Chosen · Copied here · This browser · Cloud sync**. Done cards use the
emerald tokens, the next card uses the blue tokens, later cards are
`bg-surface-raised` with `text-faint` on both lines. This maps directly onto
`selectFamily → prepareIndexedDb → commitLocalCutover → activateCloud`.

**Typed confirmation** — `border-2 border-accent-amber-border
bg-accent-amber-bg rounded-lg p-4`:

- "This changes where NPCs are read from" (14px/600 `text-accent-amber-text`)
- "After this, this browser reads NPCs from its own durable storage instead of
  the old one. Your safety copy still covers the old data, and you can undo this
  later." (13px)
- Label: `Type <code>MIGRATE NPCS ALPHA7</code> to confirm` — the phrase in mono
  700. The label text must match `/type .* to confirm/i`; the phrase itself is
  `adapter.confirmation().requiredPhrase`, never hardcoded in the component.
- A mono text input (40px, `border-2` `--accent-amber-border-strong` #fcd34d,
  white background, `min-width: 240px`, flex 1) and a `warning` `Button` with
  `ShieldCheck size={16}` labelled **"Switch this browser over"**, disabled until
  the typed value equals the phrase. Never `window.confirm` (ruling R12).

**After the local cutover** — blue card (`border-accent-blue-border
bg-accent-blue-bg`): "In this browser only — not synced yet" / "This
browser now reads NPCs from its own durable storage. Sending them to your
account is the last step, and it is the one that makes them available on your
other devices." Then a `secondary` `Button` with `CloudCog size={16}`:
**"Turn on cloud sync"**.

**Verified** — emerald card with `CircleCheckBig`: "NPCs are synced" /
"We re-read every item back out of the cloud and compared it to what left this
device. Everything matches, and nothing is still waiting to send." / mono
`npc · postgres epoch 1 · outbox settled · 0 conflicts`. That sentence is the
plain-English form of `FamilyVerification`: `documentsMatch`,
`tombstonesMatch`, `outboxEmpty` (settled, not physically empty) and
`conflictCount === 0` (unresolved only).

### Edge states

Each is an amber or red card in place of (or above) the confirmation block. All
of them are `role="alert"`.

1. **Mid-run drift** (amber, `TriangleAlert`) — "Something changed since your
   safety copy" / "We stopped before touching anything. Your calendar changed in
   another tab, so the backup you checked would no longer restore this browser." /
   mono `changed: rollkeeper-calendar-data` / buttons **"Download a fresh
   copy"** (warning) and **"Stop here for now"** (ghost). Naming the changed key
   is required — it comes from diffing the receipt's entry vector against a
   fresh capture. No authority is touched and no exception is recorded.
2. **Blocked** (amber) — "Finish your combat first" / "An encounter is still
   running, so encounters cannot move right now. End it — or come back after the
   session — and this step will be ready." / mono
   `blocker active-encounter · "Bridge at Dusk" (isActive)`. Continue stays
   enabled so the run can move past it.
3. **Needs repair** (red) — "This category needs attention" / "An earlier attempt
   stopped halfway, so this browser's records disagree about where your NPCs
   are read from. We will not guess — we can check the data and repair it only if the
   evidence is clear." / mono `marker localStorage epoch 0 · pointer indexedDB
   epoch 1 · marker-pointer-disagreement` / buttons **"Check this browser and fix
   it"** (danger) and **"Skip for now"** (outline).
4. **Repair refused** (red) — "It could not be fixed safely" / "The records that
   survived do not prove which side is newer, so nothing was changed. Your NPCs
   are untouched and still readable. Skip this category and keep going; the rest of
   the run is unaffected." The category stays `inconsistent`; skip stays enabled.
5. **Cloud unavailable** (amber, `CloudOff`) — "Saved in this browser only" / "The
   upload to your account did not go through. Your magic items are safe and this
   device is using them, but they are not in the cloud yet. Nothing was undone —
   retry whenever you are back online." / outline **"Try cloud sync again"** with
   `RefreshCw size={14}`. Critically, category k stays on IndexedDB authority,
   category k+1 is untouched, and **nothing is rolled back**.
6. **Planned category** (neutral `bg-surface-secondary` panel) — "Not yet
   available" / "These categories still live only in this browser, and there is nothing
   to confirm here yet. They are listed so you can see what is left." No
   manifest, no confirmation input.

## Step 8 — Result

Title is the claim in plain words; the claim card below carries the plan's exact
wording so the three claims stay distinguishable:

| Condition | Title | Headline | Card tone |
|---|---|---|---|
| All six registered categories verified | "Everything is synced" | **All campaign data is synced** | emerald |
| Every *enabled* category verified, but a registered one is switched off | "Everything available is synced" | **All available campaign data is synced** | blue |
| Anything else | "Some categories are still here" | **Not finished yet** | amber |

Right of the title: an outline `Button size="sm"` with `RefreshCw size={14}`,
**"Check again"**.

Then a `border border-divider bg-surface-raised rounded-lg` list, one row per
category (six registered + three planned), each `padding: 11px 16px` with a
`border-b` of `#e2e8f0`: 14px/500 label, 12px `text-muted` note, and a status
badge — "Verified" (success) / "This device" (secondary) / "Unavailable"
(warning, for a registered-but-disabled category) / "Not moved" (neutral) /
"Later" (neutral `text-muted`, planned).

Then the cross-family check, emerald or amber:

- OK: "Everything else is untouched" / "Every other thing this browser stores
  still matches your backup exactly, so that file can still restore this
  device."
- Changed: "One unrelated thing changed while you were here" / "Your player
  roster changed during the run (rollkeeper-player-data). It was not part of
  this migration and nothing touched it — your backup is simply older than
  it now."

Finally, 12px `text-muted`: "This result is checked live every time you open it
and is never stored, so it can never claim more than what is true right now."
That is the user-facing form of R8/R14 — verification runs on entry and on
Refresh, is re-run when the report is reopened, and is never persisted.

---

## Screen 3 — DM dashboard changes (`/dm`)

`DM Dashboard.dc.html` recreates the existing page (header, three stat cards,
the DM cloud workspace card, the campaign grid) so the two changes are visible
in context.

**Launcher (Task 17).** Inside each `CampaignCard`, below the existing action
row, add a `border-t border-divider` block with 12px padding holding a
full-width outline `Button size="sm"` with `CloudCog size={15}`:

- Unmigrated campaign: "Move campaign data to cloud sync", note "Nothing is
  uploaded until you confirm each step."
- Already routed: "Review cloud sync", note "Settings, calendar and NPCs
  are synced. Banner and delete moved into the campaign."

It must be a **link** to `/dm/migrate/<code>` whose accessible name matches
`/migrate/i`, and it renders only while the wizard flag is on.

**Hardening (Task 18).** For a campaign whose `campaign_settings` marker is
currently routed (`indexedDB` or `postgres`, read **directly from
localStorage, independent of the family flag**):

- No `BannerUpload` and no legacy Delete button.
- Instead, an outline "Manage" link to `/dm/campaign/<code>`, plus a `success`
  badge with `ShieldCheck` reading **"Synced"** next to the code badge.
- A rolled-back campaign (`legacy_restored`) gets its controls back; an
  unmigrated campaign is byte-identical to today.

---

## Interactions & behaviour

- **Navigation** is linear with an escape hatch: Back, Continue, and per-family
  "Skip this one". Rail rows are also clickable. Continue is disabled until the
  run holds a verified or resumed receipt.
- **Typed confirmation** gates every local cutover. Compare case-insensitively
  after trimming; enable the button only on an exact match.
- **The recovery receipt is captured once per run** and reused by every family.
  The device bundle is **re-captured read-only before each authority
  transition** to detect drift — so the capture count grows during a run while
  the download and verification counts stay at exactly one.
- **Skipping or closing writes nothing.** A skipped category stays byte-identical
  legacy, with no selection record. Closing between steps must leave durable
  state unchanged.
- **Failure never reverses progress.** A cloud failure leaves category k on
  IndexedDB authority and category k+1 untouched, and must not call `rollback`.
- **Resume** re-derives every step's state from markers, IndexedDB pointers and
  the receipt — the wizard persists nothing of its own — and must not stage or
  cut over twice.
- **Transitions:** rely on the `Dialog`'s existing 200ms fade/zoom. Button
  `transition-all duration-200` and `active:scale-[0.98]` come from
  `buttonVariants`. Add nothing else.
- **Responsive:** the plan requires every warning to render at a **390px
  viewport without truncation**. Below `sm`, stack the rail above the step body
  (or collapse it to a "Step N of 9" summary), let the manifest grid and stage
  chain wrap, and keep the footer's buttons full-width stacked. Never clip alert
  text.
- **Loading:** use the `Button`'s own `loading` prop (it swaps the left icon for
  a spinning `Loader2`) for download, check, cutover, upload, repair and refresh.
- **Accessibility:** success/progress messages `role="status"`, failures
  `role="alert"`; the file input keeps a visible label containing "safety copy";
  the 44×44 close button comes from `DialogContent`.

## State management

Derived, not stored (ruling R6). The controller holds only view state:

- `step` — index into [account, safety copy, ...six families, result]
- `typedConfirmation` — cleared on every step change
- `pickedFile` / receipt state — `pending | verified | resumed | stale`
- a verification request **token**, so a stale `verifyCloud` response that lands
  after a newer one is discarded

Everything else is read live: `deriveFamilyStepState({ entry, enabled, authority,
selection, runRecovery, preparedState, blockers, verification })` returns
`notAvailable | legacy | selected | prepared | indexedDb | postgresUnverified |
verified | blocked | rolledBack | inconsistent`, and that is what the badge, the
stage chain and the rail dot render from. Do not mirror it into component state.

Data the UI needs per family: `previewManifest()` (counts, bytes, fingerprint,
blockers, references), `confirmation()` (labels + required phrase),
`readAuthority()`, `verifyCloud()`.

## Design tokens

All from `src/app/globals.css`. **Use the utility, not the hex.** Light-theme
values, for verification only:

| Token | Utility | Light hex |
|---|---|---|
| surface | `bg-surface` | #f8fafc |
| surface-secondary | `bg-surface-secondary` | #f1f5f9 |
| surface-raised | `bg-surface-raised` | #ffffff |
| surface-inset | `bg-surface-inset` | #e2e8f0 |
| heading | `text-heading` | #1e293b |
| body | `text-body` | #475569 |
| muted | `text-muted` | #64748b |
| faint | `text-faint` | #94a3b8 |
| divider | `border-divider` | #cbd5e1 |
| divider-strong | `border-divider-strong` | #94a3b8 |
| emerald bg / border / text / text-muted | `accent-emerald-*` | #ecfdf5 / #a7f3d0 / #065f46 / #047857 |
| blue bg / border / text / text-muted | `accent-blue-*` | #eff6ff / #bfdbfe / #1e40af / #1d4ed8 |
| amber bg / border / border-strong / text / text-muted | `accent-amber-*` | #fffbeb / #fde68a / #fcd34d / #92400e / #b45309 |
| red bg / border / text / text-muted | `accent-red-*` | #fef2f2 / #fecaca / #991b1b / #b91c1c |
| input bg / text / placeholder / border | `input-*` | #f1f5f9 / #111827 / #6b7280 / #cbd5e1 |

**Buttons** (`buttonVariants`): primary emerald-600→700 gradient, secondary
blue-600→700, success green-600→700, warning amber-600→700, danger red-600→700,
outline `border-2 border-divider bg-surface-raised text-heading`, ghost
transparent. Sizes: `xs` h-7/px-3/12px, `sm` h-9/px-4/14px, `md` h-10/px-5/14px,
`lg` h-11/px-6/16px. All `rounded-lg`, `gap-2`, weight 500, `shadow-md` on the
filled variants.

**Badges** (`badgeVariants`): `rounded-full`, `px-2.5 py-0.5`, 12px, weight 600,
1px border, accent-token fills. `size="sm"` is `px-2`.

**Cards:** `rounded-lg bg-surface-raised border border-divider`; padding scale
`sm` 12 / `md` 16 / `lg` 24 / `xl` 32. Dialog is `rounded-xl border-2` + `p-6`.

**Spacing:** the 4px Tailwind scale. Dialog gap 16, column gap 20, rail gap 2,
card padding 16, section gaps 16, footer top padding 16.

**Typography:** body `--font-body-family` (Arial/Helvetica in light and dark;
Hanken Grotesk in parchment). Sizes used: 11px eyebrows/notes, 12px mono detail
and helper text, 13px secondary body, 14px primary body and controls, 18px step
titles, 18–20px manifest values, 20px dialog title, 30px page H1. Every
fingerprint, storage key, epoch and receipt id is set in `font-mono`
(Geist Mono).

**Radii:** 6px rail rows, 8px (`rounded-lg`) cards/buttons/inputs, 12px
(`rounded-xl`) dialog, `9999px` badges, dots and the progress track.

**Shadows:** `shadow-sm` header, `shadow-md` filled buttons and stat cards,
`shadow-2xl` dialog.

## Assets

- **Icons:** `lucide-react` only, already a dependency. Used here: `ArrowLeft`,
  `CloudCog`, `Lock`, `X`, `ShieldCheck`, `CircleCheckBig`, `FileCheck`,
  `Download`, `Upload`, `RefreshCw`, `TriangleAlert`, `CloudOff`,
  `ChevronRight`, `Loader2`, plus the dashboard's `Crown`, `Users`, `Clock`,
  `Plus`, `Trash2`, `ImageIcon`. The prototype inlines the same lucide path data
  because it cannot import the package — do not port those inline SVGs.
- **Fonts:** already loaded by `src/app/layout.tsx` via `next/font/local`. The
  copies in this bundle exist only so the prototype rendered correctly.
- **Images:** none. No illustration or empty-state art is used anywhere.

## Copy

Every string in the prototype is intended as final copy. The pattern throughout
is **plain sentence first, precise detail second** — a 13–14px human sentence,
then a 12px mono line naming the family, fingerprint, epoch, storage key or
blocker. Keep that split: it is what makes the wizard readable without hiding
what actually happened. The prototype exposes a `copyTone` switch that hides the
mono lines; treat that as a design question still open, not a feature to build.

Never render an account email address, token or OTP anywhere in this flow.
